const connections = {};
let prevused = false;

// masih bisa pakai setInterval global, tanpa window.
setInterval(() => {
  prevused = !prevused;
}, 60000);

// init storage saat install / update
chrome.runtime.onInstalled.addListener(async (details) => {
  const manifest = chrome.runtime.getManifest();
  const currVersion = manifest.version;

  const data = await chrome.storage.local.get(["uid", "c_ver"]);

  if (!data.uid) {
    const uid = generateUid();
    await chrome.storage.local.set({ uid });
  }

  if (data.c_ver !== currVersion) {
    await chrome.storage.local.set({ c_ver: currVersion });
  }
});

chrome.runtime.onConnect.addListener((port) => {
  const extensionListener = (message, sender, sendResponse) => {
    if (message.name === "init") {
      connections[message.tabId] = port;
      return;
    }

    // other message handling
  };

  port.onMessage.addListener(extensionListener);

  port.onDisconnect.addListener(() => {
    port.onMessage.removeListener(extensionListener);

    const tabs = Object.keys(connections);
    for (let i = 0; i < tabs.length; i++) {
      if (connections[tabs[i]] === port) {
        delete connections[tabs[i]];
        break;
      }
    }
  });
});

// receive message from content script and relay to devtools page
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.text === "uid") {
    chrome.storage.local.get(["uid"]).then((data) => {
      sendResponse((data.uid || "") + "|" + prevused);
    });
    return true; // async response
  }

  if (sender.tab) {
    const tabId = sender.tab.id;
    if (tabId in connections) {
      connections[tabId].postMessage(request);
    } else {
      console.log("Tab not found in connection list.");
    }
  } else {
    console.log("sender.tab not defined.");
  }

  return true;
});

function generateUid() {
  const buf = new Uint8Array(16);
  crypto.getRandomValues(buf);

  let uid = "";
  for (let i = 0; i < buf.length; i++) {
    uid += (buf[i] <= 0x0f ? "0" : "") + buf[i].toString(16);
  }
  return uid;
}