#!/bin/sh
BASE="/home/vnstat"
. "$BASE/vnstat-lib.sh"

PIDFILE="$RUNTIME_TMP/vnstat-lite.pid"
LOGFILE="$RUNTIME_TMP/vnstat-lite.log"
UPDATER="$BASE/update.sh"
INTERVAL="${INTERVAL:-60}"
BACKUP_INTERVAL="${BACKUP_INTERVAL:-60}"
export BACKUP_INTERVAL

is_running() {
    [ -f "$PIDFILE" ] || return 1
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    [ -n "$pid" ] || return 1
    kill -0 "$pid" 2>/dev/null
}

start() {
    ensure_vnstat_dirs
    "$BASE/init-db.sh" >/dev/null 2>&1 || true
    if is_running; then
        echo "running (pid=$(cat "$PIDFILE"))"
        return 0
    fi
    (
        trap 'exit 0' INT TERM
        while :; do
            "$UPDATER" >/dev/null 2>&1
            sleep "$INTERVAL"
        done
    ) >>"$LOGFILE" 2>&1 &
    echo $! > "$PIDFILE"
    sleep 1
    is_running && echo "started (pid=$(cat "$PIDFILE"), interval=${INTERVAL}s)" || {
        echo "failed"
        rm -f "$PIDFILE"
        return 1
    }
}

stop() {
    if ! is_running; then
        echo "stopped"
        rm -f "$PIDFILE"
        return 0
    fi
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    kill "$pid" >/dev/null 2>&1 || true
    sleep 1
    kill -9 "$pid" >/dev/null 2>&1 || true
    rm -f "$PIDFILE"
    echo "stopped"
}

status() {
    is_running && echo "running (pid=$(cat "$PIDFILE"))" || {
        echo "stopped"
        return 1
    }
}

case "$1" in
    start) start ;;
    stop) stop ;;
    restart) stop; start ;;
    status) status ;;
    *) echo "Usage: $0 {start|stop|restart|status}"; exit 1 ;;
esac
