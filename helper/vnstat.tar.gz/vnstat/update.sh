#!/bin/sh
BASE="/home/vnstat"
. "$BASE/vnstat-lib.sh"

ensure_vnstat_dirs

vnstat_lock_acquire || exit 1
trap 'vnstat_lock_release' EXIT INT TERM HUP QUIT

# Self-heal runtime db if /tmp gets wiped.
if ! dir_has_files "$RUNTIME_DB"; then
    restore_runtime_db >/dev/null 2>&1 || true
    VNSTAT_NOLOCK=1 "$BASE/run-vnstat.sh" --create -i "$IFACE" >/dev/null 2>&1 || true
fi

VNSTAT_NOLOCK=1 "$BASE/run-vnstat.sh" -u -i "$IFACE" >/dev/null 2>&1 || true

vnstat_lock_release
trap - EXIT INT TERM HUP QUIT

if backup_due; then
    "$BASE/sync-db.sh" >/dev/null 2>&1 || true
fi
