#!/bin/sh
BASE="/home/vnstat"
. "$BASE/vnstat-lib.sh"

ensure_vnstat_dirs

vnstat_lock_acquire || exit 1
trap 'vnstat_lock_release' EXIT INT TERM HUP QUIT

restore_runtime_db >/dev/null 2>&1 || true

VNSTAT_NOLOCK=1 "$BASE/run-vnstat.sh" --create -i "$IFACE" >/dev/null 2>&1 || true
VNSTAT_NOLOCK=1 "$BASE/run-vnstat.sh" -u -i "$IFACE" >/dev/null 2>&1 || true

if ! dir_has_files "$PERSIST_DB"; then
    backup_runtime_db >/dev/null 2>&1 || true
fi
