#!/bin/sh
BASE="/home/vnstat"
IFACE="seth_lte0"
mkdir -p "$BASE/db" "$BASE/tmp"
"$BASE/run-vnstat.sh" --create -i "$IFACE"
"$BASE/run-vnstat.sh" -u -i "$IFACE"
