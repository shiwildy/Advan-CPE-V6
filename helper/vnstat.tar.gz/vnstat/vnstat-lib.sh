#!/bin/sh

BASE="${BASE:-/home/vnstat}"
IFACE="${IFACE:-seth_lte0}"

RUNTIME_BASE="${RUNTIME_BASE:-/tmp/vnstat}"
RUNTIME_DB="${RUNTIME_DB:-$RUNTIME_BASE/db}"
RUNTIME_TMP="${RUNTIME_TMP:-$RUNTIME_BASE/tmp}"

PERSIST_DB="${PERSIST_DB:-$BASE/db}"

BACKUP_INTERVAL="${BACKUP_INTERVAL:-60}"
BACKUP_STAMP_FILE="${BACKUP_STAMP_FILE:-$RUNTIME_TMP/last_backup_epoch}"

VNSTAT_LOCKDIR="${VNSTAT_LOCKDIR:-$RUNTIME_BASE/lock/vnstat.lock}"
VNSTAT_LOCK_WAIT="${VNSTAT_LOCK_WAIT:-15}"

ensure_vnstat_dirs() {
    mkdir -p "$RUNTIME_DB" "$RUNTIME_TMP" "$PERSIST_DB"
}

dir_has_files() {
    dir="$1"
    [ -d "$dir" ] || return 1

    set -- "$dir"/* "$dir"/.[!.]* "$dir"/..?*
    for entry in "$@"; do
        [ -e "$entry" ] && return 0
    done
    return 1
}

restore_runtime_db() {
    ensure_vnstat_dirs

    if dir_has_files "$RUNTIME_DB"; then
        return 0
    fi

    if ! dir_has_files "$PERSIST_DB"; then
        return 0
    fi

    cp -fpR "$PERSIST_DB"/. "$RUNTIME_DB"/ 2>/dev/null || return 1
    return 0
}

backup_runtime_db() {
    ensure_vnstat_dirs

    if ! dir_has_files "$RUNTIME_DB"; then
        return 1
    fi

    copied=0

    for src in "$RUNTIME_DB"/* "$RUNTIME_DB"/.[!.]* "$RUNTIME_DB"/..?*; do
        [ -f "$src" ] || continue
        name="${src##*/}"
        tmp="$PERSIST_DB/$name.tmp"
        dst="$PERSIST_DB/$name"

        cp -f "$src" "$tmp" 2>/dev/null || return 1
        mv -f "$tmp" "$dst" 2>/dev/null || return 1
        copied=1
    done

    [ "$copied" -eq 1 ] || return 1

    date +%s > "$BACKUP_STAMP_FILE" 2>/dev/null || true
    return 0
}

backup_due() {
    now="$(date +%s 2>/dev/null)"
    case "$now" in
        ''|*[!0-9]*) return 0 ;;
    esac

    if [ ! -f "$BACKUP_STAMP_FILE" ]; then
        return 0
    fi

    last="$(cat "$BACKUP_STAMP_FILE" 2>/dev/null)"
    case "$last" in
        ''|*[!0-9]*) return 0 ;;
    esac

    delta=$((now - last))
    [ "$delta" -lt 0 ] && return 0
    [ "$delta" -ge "$BACKUP_INTERVAL" ]
}

vnstat_lock_acquire() {
    lock_parent="${VNSTAT_LOCKDIR%/*}"
    [ -n "$lock_parent" ] || lock_parent="$RUNTIME_BASE/lock"
    mkdir -p "$lock_parent" "$RUNTIME_TMP"

    attempt=0
    while ! mkdir "$VNSTAT_LOCKDIR" 2>/dev/null; do
        if [ -f "$VNSTAT_LOCKDIR/pid" ]; then
            oldpid="$(cat "$VNSTAT_LOCKDIR/pid" 2>/dev/null)"
            if [ -n "$oldpid" ] && ! kill -0 "$oldpid" 2>/dev/null; then
                rm -rf "$VNSTAT_LOCKDIR" 2>/dev/null || true
                continue
            fi
        fi

        attempt=$((attempt + 1))
        [ "$attempt" -ge "$VNSTAT_LOCK_WAIT" ] && return 1
        sleep 1
    done

    echo "$$" > "$VNSTAT_LOCKDIR/pid"
    return 0
}

vnstat_lock_release() {
    if [ -f "$VNSTAT_LOCKDIR/pid" ]; then
        owner="$(cat "$VNSTAT_LOCKDIR/pid" 2>/dev/null)"
        [ -n "$owner" ] && [ "$owner" != "$$" ] && return 0
    fi
    rm -rf "$VNSTAT_LOCKDIR" 2>/dev/null || true
}
