#!/bin/sh
INIT="/etc/init.d/vnstat-lite"
RCS_LINK="/etc/rcS.d/S98vnstat-lite"

[ -x "$INIT" ] && "$INIT" stop >/dev/null 2>&1 || true
rm -f "$RCS_LINK" "$INIT"

echo "Autostart removed."
