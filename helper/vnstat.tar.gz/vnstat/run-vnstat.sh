#!/bin/sh
BASE="/home/vnstat"
exec "$BASE/lib/ld-linux.so.3" --library-path "$BASE/lib" "$BASE/bin/vnstat" --config "$BASE/etc/vnstat.conf" "$@"
