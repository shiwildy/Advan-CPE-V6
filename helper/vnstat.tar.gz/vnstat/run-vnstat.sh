#!/bin/sh
BASE="/home/vnstat"
. "$BASE/vnstat-lib.sh"

run_vnstat_bin() {
    "$BASE/lib/ld-linux.so.3" --library-path "$BASE/lib" \
        "$BASE/bin/vnstat" --config "$BASE/etc/vnstat.conf" "$@"
}

if [ "${VNSTAT_NOLOCK:-0}" != "1" ]; then
    vnstat_lock_acquire || exit 1
    trap 'vnstat_lock_release' EXIT INT TERM HUP QUIT
fi

run_vnstat_bin "$@"
rc=$?

if [ "${VNSTAT_NOLOCK:-0}" != "1" ]; then
    vnstat_lock_release
    trap - EXIT INT TERM HUP QUIT
fi

exit "$rc"
