#!/bin/sh
BASE="/home/vnstat"
INIT="/etc/init.d/vnstat-lite"
RCS_LINK="/etc/rcS.d/S98vnstat-lite"

if [ ! -x "$BASE/daemon-lite.sh" ]; then
    echo "Missing $BASE/daemon-lite.sh"
    exit 1
fi

mkdir -p /etc/init.d /etc/rcS.d

cat > "$INIT" << 'EOF'
#!/bin/sh
BASE="/home/vnstat"
DAEMON="$BASE/daemon-lite.sh"

case "$1" in
    start)
        [ -x "$DAEMON" ] || exit 0
        "$DAEMON" start
        ;;
    stop)
        [ -x "$DAEMON" ] || exit 0
        "$DAEMON" stop
        ;;
    restart)
        [ -x "$DAEMON" ] || exit 0
        "$DAEMON" restart
        ;;
    status)
        [ -x "$DAEMON" ] || { echo "stopped"; exit 1; }
        "$DAEMON" status
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac
EOF

chmod 755 "$INIT"
ln -sf "$INIT" "$RCS_LINK"

"$INIT" start >/dev/null 2>&1 || true

echo "Autostart installed:"
echo "  init script: $INIT"
echo "  startup link: $RCS_LINK"
