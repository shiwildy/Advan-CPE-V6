#!/bin/sh
BASE="/home/vnstat"
IFACE="seth_lte0"
"$BASE/run-vnstat.sh" -i "$IFACE" -d
"$BASE/run-vnstat.sh" -i "$IFACE" -w
"$BASE/run-vnstat.sh" -i "$IFACE" -m
