#!/bin/sh
BASE="/home/vnstat"
. "$BASE/vnstat-lib.sh"

ensure_vnstat_dirs

vnstat_lock_acquire || exit 1
trap 'vnstat_lock_release' EXIT INT TERM HUP QUIT

backup_runtime_db >/dev/null 2>&1
exit $?
