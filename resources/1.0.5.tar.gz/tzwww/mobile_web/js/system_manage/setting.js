/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-07 08:55:30
 * @,@LastEditTime: ,: 2020-12-08 15:20:49
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_manage\setting.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#sys_set",
        data(){
            return{
                title:MENU.sys.settings,
                title2:TAB.sys.changePasswd,
                title4:TAB.sys.timeSetting,
                title5:TAB.sys.restoreFactory
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            showPopup(key){
                switch (key) {
                    case 0:
                        $("#app").load("html/system_manage/set/changePass.html")
                        pageUrl = "html/system_manage/set/changePass.html"
                        sessionStorage.setItem("pageUrl",pageUrl)
                        break;
                    case 2:
                        $("#app").load("html/system_manage/set/setTime.html")
                        pageUrl = "html/system_manage/set/setTime.html"
                        sessionStorage.setItem("pageUrl",pageUrl)
                        break;
                    case 4:
                        $("#app").load("html/system_manage/set/roam.html")
                        pageUrl = "html/system_manage/set/roam.html"
                        sessionStorage.setItem("pageUrl",pageUrl)
                    default:
                        break;
                }
            },
            setFactory(){
                vant.Dialog.confirm({
                    message: PROMPT.confirm.restoreFactory,
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(() => {
                      // on confirm
                        loading();
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.RESTORE_DEFAULT,
                                method: JSONMethod.POST
                            },
                            success: function (data) {
                                if(data.message == ""){
                                    clearToast();
                                    successLoad(PROMPT.status.restoreFactorySuccess);
                                    setTimeout(() => {
                                        loading(PROMPT.status.rebooting);
                                        Page.postJSON({
                                            json: {
                                                cmd: RequestCmd.SYS_REBOOT,
                                                rebootType: 4,
                                                method: JSONMethod.POST
                                            },
                                            success: function() {
                                                
                                            },
                                            
                                        });
                                        successReboot();
                                    }, 1000);
                                }

                            }
                        });

                    })
                    .catch(() => {
                      // on cancel
                    });
            }
        }
    })
})
