/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-01-25 11:00:58
 * @,@LastEditTime: ,: 2021-06-08 10:59:23
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\js\info\sysInfo.js
 */
var loading = "-";
var values_sysInfo = new Array(21);
var vm_sysInfo = new Vue({
    el: "#net_info",
    data: {
        values_sysInfo: {},
        vnstatLastFetch: 0,
        vnstatFetchInterval: 30000,
        title: DOC.title.network,
        explanation: HELP.head.explanation,
        sysInfo: HELP.head.sysInfo,
        colon: DOC.colon,
        text: [{
            title: fourgInfohtml.helper.title2,
            item: fourgInfohtml.helper.item2
        }]
    },
    methods: {
        normalizeOperator: function (val) {
            if (val === undefined || val === null) {
                return "";
            }
            var s = $.trim(String(val));
            if (!s || s === "-" || /null/i.test(s)) {
                return "";
            }
            return s;
        },
        refreshOperatorFromAT: function () {
            $.ajax({
                type: "GET",
                url: "/cgi-bin/extra.cgi?action=operator",
                cache: false,
                dataType: "json",
                success: function (opData) {
                    var op2 = vm_sysInfo.normalizeOperator(opData ? opData.operator : "");
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.plmn, op2 || loading);
                },
                error: function () {
                    // keep previous value
                }
            });
        },
        escapeHtml: function (text) {
            return String(text || "")
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        },
        renderBlock: function (text) {
            var safe = this.escapeHtml(text || loading).replace(/\n/g, "<br>");
            return '<div style="white-space:pre-wrap;line-height:1.4;font-family:monospace;">' + safe + "</div>";
        },
        setVnstatRows: function (iface, daily, weekly, monthly) {
            vm_sysInfo.$set(vm_sysInfo.values_sysInfo, "Traffic Daily (" + iface + ")", vm_sysInfo.renderBlock(daily || loading));
            vm_sysInfo.$set(vm_sysInfo.values_sysInfo, "Traffic Weekly (" + iface + ")", vm_sysInfo.renderBlock(weekly || loading));
            vm_sysInfo.$set(vm_sysInfo.values_sysInfo, "Traffic Monthly (" + iface + ")", vm_sysInfo.renderBlock(monthly || loading));
        },
        refreshVnstatSummary: function (force) {
            var now = Date.now();
            if (!force && (now - this.vnstatLastFetch) < this.vnstatFetchInterval) {
                return;
            }
            this.vnstatLastFetch = now;
            $.ajax({
                type: "GET",
                url: "/cgi-bin/extra.cgi?action=vnstat_summary",
                cache: false,
                dataType: "json",
                success: function (resp) {
                    var iface = (resp && resp.iface) ? resp.iface : "seth_lte0";
                    if (resp && resp.success) {
                        vm_sysInfo.setVnstatRows(iface, resp.daily, resp.weekly, resp.monthly);
                    } else {
                        var msg = (resp && resp.message) ? ("vnStat error: " + resp.message) : "vnStat data unavailable";
                        vm_sysInfo.setVnstatRows(iface, msg, msg, msg);
                    }
                },
                error: function () {
                    vm_sysInfo.setVnstatRows("seth_lte0", "vnStat request failed", "vnStat request failed", "vnStat request failed");
                }
            });
        },
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SYS_INFO_NETWORK
                },
                success: function (datas) {
                    var mcs_info, pci_info, bandwidth_info, sinr_info, cell_id_info, cqi_info, currentband_info, freq_info, enodebid_info, mcs_info_5g, bandwidth_info_5g, sinr_info_5g, cqi_info_5g, currentband_info_5g, cell_id_info_5g, enodebid_info_5g, pci_info_5g, freq_info_5g;
                    mcs_info = datas.dl_mcs;
                    pci_info = datas.PCI;
                    bandwidth_info = datas.bandwidth;
                    sinr_info = datas.SINR;
                    cell_id_info = datas.CELL_ID;
                    cqi_info = datas.CQI;
                    currentband_info = datas.currentband;
                    freq_info = datas.FREQ;
                    enodebid_info = datas.ENODEBID;
                    mcs_info_5g = datas.dl_mcs_5g==0&&datas.RSSI?"-":datas.dl_mcs_5g;
                    ul_mcs_5g = datas.ul_mcs_5g==0&&datas.RSSI?"-":datas.ul_mcs_5g;
                    bandwidth_info_5g = datas.bandwidth_5g;
                    sinr_info_5g = datas.SINR_5G;
                    cqi_info_5g = datas.CQI_5G ==0&&datas.RSSI?"-":datas.CQI_5G;
                    currentband_info_5g = datas.currentband_5g;
                    cell_id_info_5g = datas.CELL_ID_5G;
                    enodebid_info_5g = datas.ENODEBID_5G;
                    pci_info_5g = datas.PCI_5G;
                    freq_info_5g = datas.FREQ_5G;
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.netMode, datas.network_type_str || loading);
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.signal, StatusUtil.formatSingalLevel(datas.signal_lvl,datas.network_type_str ));
                    var opRaw = datas.is_use_spn_set_operator=='1' ? datas.spn_network_operator : datas.network_operator;
                    var op = vm_sysInfo.normalizeOperator(opRaw);
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.plmn, op || loading);
                    // Always overwrite from AT source (more reliable than SYS_INFO_NETWORK on this firmware).
                    vm_sysInfo.refreshOperatorFromAT();
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rsrp, (datas.RSRP || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rssi, (datas.RSSI || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rsrq, (datas.RSRQ || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.sinr, (sinr_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.phyCellId, (pci_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.freqPoint, (freq_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.enodeB, (enodebid_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.cellId, (cell_id_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.cqi, (cqi_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.ULMCS, (datas.ul_mcs || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.DLMCS, (mcs_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.bandwidth, (bandwidth_info || loading));
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, "ECGI", datas.ECGI || loading);
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lockband.currentBand, (currentband_info || loading));
                    if(Page.level == "1")
                    {
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.qam64, datas.ul64qam_support == "1" ? "YES" : "NO");
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.qam256, datas.ul256qam_support == "1" ? "YES" : "NO");
                    }
                    if (Page.level != "3") {
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.maxQamUl, (datas.max_ul_qam || loading));
                        vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lbl.maxQamDl, (datas.max_dl_qam || loading));
                    }
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.rank, (datas.rank_4g || loading) );
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.DL_BLER, (datas.bler_4g || loading));
                    
                    var historyFlow = 0,currentFlow = 0;
                    if(!isNaN(datas.flow_dl)) {
                        currentFlow += Number(datas.flow_dl);
                    }
                    if(!isNaN(datas.flow_ul)) {
                        currentFlow += Number(datas.flow_ul);
                    }
                    if(!isNaN(datas.history_flow_dl)) {
                        historyFlow += Number(datas.history_flow_dl);
                    }
                    if(!isNaN(datas.history_flow_ul)) {
                        historyFlow += Number(datas.history_flow_ul);
                    }
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.flow_current, currentFlow.toFixed(2) + "MB");
                    vm_sysInfo.$set(vm_sysInfo.values_sysInfo, DOC.lte.flow_history, historyFlow.toFixed(2) + "MB");
                }
            })
        }
    },
    mounted: function () {
        this.getData();
        Page.timer = setInterval(function () {
            vm_sysInfo.getData();
        }, 10000);
    }
});
