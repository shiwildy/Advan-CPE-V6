$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "TTL Change",
            currentTtlText: "Current TTL",
            ttlInputText: "New TTL",
            submitText: "Apply",
            isClick: false,
            currentTtl: "-",
            ttlValue: ""
        },
        methods: {
            requestCgi: function (url, method, body, callback) {
                $.ajax({
                    url: url,
                    type: method || "GET",
                    data: body || "",
                    processData: false,
                    contentType: "text/plain; charset=UTF-8",
                    timeout: 8000,
                    success: function (resp) {
                        callback(null, (resp || "").toString().trim());
                    },
                    error: function (xhr, textStatus) {
                        callback(textStatus || "request_error", "");
                    }
                });
            },
            refreshCurrentTtl: function () {
                this.requestCgi("/cgi-bin/extra.cgi?action=ttl", "GET", "", function (err, text) {
                    if (err) {
                        vm.currentTtl = "-";
                        return;
                    }
                    vm.currentTtl = (/^[0-9]{1,3}$/.test(text)) ? text : "-";
                });
            },
            submitTtl: function () {
                var ttl = parseInt((this.ttlValue || "").toString().trim(), 10);
                if (isNaN(ttl) || ttl < 1 || ttl > 255) {
                    AlertUtil.alertMsg("TTL must be 1-255");
                    return;
                }

                vm.isClick = true;
                fyAlertMsgLoading();
                vm.requestCgi("/cgi-bin/extra.cgi?action=ttl", "POST", String(ttl), function (err, text) {
                    vm.isClick = false;
                    if (err) {
                        fyAlertMsgFail("Request failed");
                        return;
                    }
                    if (text.indexOf("OK") !== 0) {
                        fyAlertMsgFail(text || "Failed");
                        return;
                    }
                    fyAlertMsgSuccess();
                    vm.refreshCurrentTtl();
                });
            }
        },
        mounted: function () {
            this.refreshCurrentTtl();
        }
    });
});
