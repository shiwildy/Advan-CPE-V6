$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "Telnet",
            statusText: "Status",
            statusValue: "Checking...",
            buttonText: "Enable",
            isClick: false,
            enabled: false
        },
        methods: {
            requestCgi: function (url, method, body, callback) {
                $.ajax({
                    url: url,
                    type: method || "GET",
                    data: body || "",
                    processData: false,
                    contentType: "text/plain; charset=UTF-8",
                    timeout: 8000,
                    success: function (resp) {
                        callback(null, (resp || "").toString().trim());
                    },
                    error: function (xhr, textStatus) {
                        callback(textStatus || "request_error", "");
                    }
                });
            },
            applyRuntimeStatus: function (isRunning) {
                if (isRunning) {
                    this.enabled = true;
                    this.statusValue = "Enabled";
                    this.buttonText = "Disable";
                } else {
                    this.enabled = false;
                    this.statusValue = "Disabled";
                    this.buttonText = "Enable";
                }
            },
            refreshStatus: function () {
                this.requestCgi("/cgi-bin/extra.cgi?action=telnet", "GET", "", function (err, text) {
                    if (err) {
                        vm.statusValue = "Unknown";
                        return;
                    }
                    vm.applyRuntimeStatus(text === "1");
                });
            },
            toggleTelnet: function () {
                var action = this.enabled ? "disable" : "enable";
                vm.isClick = true;
                fyAlertMsgLoading();
                vm.requestCgi("/cgi-bin/extra.cgi?action=telnet", "POST", action, function (err, text) {
                    vm.isClick = false;
                    if (err) {
                        fyAlertMsgFail("Request failed");
                        return;
                    }
                    if (text.indexOf("OK") !== 0) {
                        fyAlertMsgFail(text || "Failed");
                        return;
                    }
                    fyAlertMsgSuccess();
                    vm.refreshStatus();
                });
            }
        },
        mounted: function () {
            this.refreshStatus();
        }
    });
});
