$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);
    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: sysathtml.head.title,
            helper: sysathtml.form1.helper,
            input: sysathtml.form1.input,
            execute: sysathtml.form1.execute,
            clear: sysathtml.form1.clear,
            result:sysathtml.form1.response,
            isClick: false,
            atCmd: '',
            atResult: '',
        },
        methods: {
            btnClear: function () {
                this.atResult = '';
            },
            renderResult: function (cmd, output) {
                var safeOutput = output || "";
                this.atResult = ">> " + cmd + "\n" + safeOutput;
            },
            sendViaLegacy: function (cmd) {
                var json = {};
                json.atInfo = Base64.encode(cmd);
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.SEND_AT;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        fyAlertDestory();
                        vm.isClick = false;
                        vm.renderResult(cmd, data && (data.flag || data.message || JSON.stringify(data)));
                    },
                    error: function () {
                        fyAlertDestory();
                        vm.isClick = false;
                        vm.renderResult(cmd, "FAILED: Unable to execute AT command");
                    }
                });
            },
            atStart: function () {
                var cmd = (this.atCmd || "").replace(/[\r\n]+/g, " ").trim();
                if (!cmd) {
                    AlertUtil.alertMsg(sysathtml.form1.requiredAT || "AT command can not be empty");
                    return;
                }
                this.atCmd = cmd;
                this.atResult = '';
                fyAlertMsgLoading();
                this.isClick = true;
                $.ajax({
                    url: "/cgi-bin/extra.cgi?action=atcmd",
                    type: "POST",
                    dataType: "json",
                    timeout: 15000,
                    contentType: "text/plain; charset=UTF-8",
                    data: cmd,
                    success: function (data) {
                        fyAlertDestory();
                        vm.isClick = false;
                        if (data && data.success) {
                            vm.renderResult(cmd, data.output || "");
                            return;
                        }
                        if (data && data.message) {
                            vm.renderResult(cmd, "ERROR: " + data.message);
                            return;
                        }
                        vm.sendViaLegacy(cmd);
                    },
                    error: function () {
                        // Fallback for firmwares that only support RequestCmd.SEND_AT.
                        vm.sendViaLegacy(cmd);
                    }
                });
            }
        }
    });
});
