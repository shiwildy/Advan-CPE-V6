$(document).ready(function() {
    Page.render('#sms_info', '#sms_template');

    function initSmsEnv(done) {
        var cmds = [
            "AT+CMEE=2",
            "AT+CMGF=1",
            "AT+CSCS=\"GSM\"",
            "AT+CPMS=\"SM\",\"SM\",\"SM\""
        ];
        var index = 0;
        function next() {
            if (index >= cmds.length) {
                if (typeof done === "function") {
                    done();
                }
                return;
            }
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SEND_AT,
                    method: JSONMethod.POST,
                    atInfo: Base64.encode(cmds[index])
                },
                success: function () {
                    index++;
                    next();
                },
                fail: function () {
                    index++;
                    next();
                }
            });
        }
        next();
    }

    // Disable SMS status-report API (cmd 125/126) to avoid session drop on this firmware.
    $('#statusReport').prop("checked", false);

    $('#sms_title').html("New SMS");
    var $phoneNo = $('#phoneNo'),
        $content = $('#content');

    var rules = {
        phoneNo: { required: true},
        content: { reallength: 1800 }
    };
    var messages = {
        phoneNo: { required: CHECK.required.phoneNo },
        content: { reallength: CHECK.max.smsLength }
    };

    var $lblSendSms = $('#lblSendSms');
    var $btnSave = $('#btnSave'), $btnSaveDraft = $('#btnSaveDraft');
    $btnSave.click(function() {
        if(!Page.connectStatus){
            AlertUtil.alertMsg(PROMPT.status.noNetwork);
            return;
        }
        $phoneNo.removeClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }
        saveSms(SmsType.SEND);
    });

    $btnSaveDraft.click(function() {
        $phoneNo.addClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }
        saveSms(SmsType.DRAFT);
    });

    function getSalt() {
        return Md5.md5(Math.random().toString()).substring(0, 3);
    }

    function saveSms(smsType) {
        var salt = getSalt();
        var content = $content.val();
        while(content.indexOf(salt) >= 0) {
            salt = getSalt();
        }

        if (smsType == SmsType.SEND) {
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.sendEmptySms)){
                    return;
                }
            }
            $lblSendSms.show();
        } else {
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.saveDraft)){
                    return;
                }
            }
        }

        $btnSave.disable();
        $btnSaveDraft.disable();

        initSmsEnv(function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SMS_SEND,
                    method: JSONMethod.POST,
                    smsType: smsType,
                    salt: salt,
                    smsId: $('#smsId').val(),
                    phoneNo: $phoneNo.val().trim(),
                    content: encodeURI(content),
                    datetime: new Date().format('yyyy-mm-dd-HH-MM-ss')
                },
                success: function(data) {
                    AlertUtil.alertMsg(data.message);
                },
                complete: function() {
                    $btnSave.enable();
                    $btnSaveDraft.enable();
                    $lblSendSms.hide();
                }
            });
        });
    }

    Page.setStripeTable();

    $phoneNo.keypress(function(e){
        if(e.keyCode == 13){
            return false;
        }
    });

    if(!$.browser.msie){
        $phoneNo.focus();
    } else {
        setTimeout(function(){
            $phoneNo.focus();
        }, 1000);
    }
});
