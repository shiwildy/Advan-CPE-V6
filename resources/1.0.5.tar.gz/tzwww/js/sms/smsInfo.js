$(document).ready(function() {
    Page.render('#sms_pager', '#smsPager_template');
    $('#sms_title').html('Read SMS');

    // Read-only: no add/edit/reply/send/draft flows.
    $('#btnAdd').hide();

    var pageIndex = 0,
        pageSize = 10,
        $pagers = $('a[id^=pager]'),
        $lblPager = $('#lblPager');

    function deleteByIndexes(indexes, cb) {
        $.ajax({
            type: 'POST',
            url: '/cgi-bin/extra.cgi?action=smsops',
            data: 'op=delete_multi&indexes=' + encodeURIComponent(indexes.join(',')),
            cache: false,
            dataType: 'json',
            success: function() {
                cb && cb(true);
            },
            error: function() {
                cb && cb(false);
            }
        });
    }

    function clearAll(cb) {
        $.ajax({
            type: 'POST',
            url: '/cgi-bin/extra.cgi?action=smsops',
            data: 'op=clear',
            cache: false,
            dataType: 'json',
            success: function() {
                cb && cb(true);
            },
            error: function() {
                cb && cb(false);
            }
        });
    }

    function getSmsList() {
        $.ajax({
            type: 'GET',
            url: '/cgi-bin/extra.cgi?action=smslist',
            cache: false,
            dataType: 'json',
            success: function(data) {
                if (!data || !data.datas) {
                    data = { datas: [] };
                }
                data.datas = $.grep(data.datas, function(item) {
                    return item.status == '0' || item.status == '1';
                });
                createTable(data);
            },
            error: function() {
                createTable({ datas: [] });
            }
        });
    }

    function createTable(data) {
        var datas = data.datas || [];
        var recordCount = datas.length;
        var pageCount = parseInt((recordCount - 1) / pageSize, 10) + 1;
        pageIndex = Math.min(Math.max(0, pageIndex), pageCount - 1);

        var pagerHtml = String.format(DOC.pager.total, recordCount);
        if (recordCount > 0) {
            pagerHtml = String.format(DOC.pager.currentPage, pagerHtml, pageIndex + 1, pageCount);
        }
        $lblPager.html(pagerHtml);

        if (recordCount == 0 || pageCount == 1) {
            $pagers.hide();
        } else {
            if (pageIndex == 0) {
                $pagers.eq(0).hide();
                $pagers.eq(1).hide();
                $pagers.eq(2).show();
                $pagers.eq(3).show();
            } else if (pageIndex == pageCount - 1) {
                $pagers.eq(0).show();
                $pagers.eq(1).show();
                $pagers.eq(2).hide();
                $pagers.eq(3).hide();
            } else {
                $pagers.show();
            }
        }

        var temp;
        for (var i = 0; i < recordCount; i++) {
            for (var j = i + 1; j < recordCount; j++) {
                if ((datas[i].datetime || '') < (datas[j].datetime || '')) {
                    temp = datas[i];
                    datas[i] = datas[j];
                    datas[j] = temp;
                }
            }
        }

        var items = [];
        var beginIndex = pageIndex * pageSize, endIndex = Math.min(beginIndex + pageSize, recordCount);
        for (var k = beginIndex; k < endIndex; k++) {
            items.push(datas[k]);
        }

        SmsUtil.createTable({
            id: '#sms_info',
            smsType: SmsType.RECEIVE,
            datas: items,
            pageIndex: pageIndex,
            pageSize: pageSize,
            edit: function() {},
            del: function(smsId, smsIndex) {
                if (!confirm(PROMPT.confirm.deleteSms)) return;
                deleteByIndexes([smsIndex], function(ok) {
                    if (!ok) {
                        AlertUtil.alertMsg('Delete SMS failed');
                        return;
                    }
                    getSmsList();
                });
            }
        });
    }

    $pagers.click(function() {
        var index = $pagers.index(this);
        switch (index) {
            case 0: pageIndex = 0; break;
            case 1: pageIndex--; break;
            case 2: pageIndex++; break;
            case 3: pageIndex = 999999; break;
        }
        getSmsList();
    });

    $('#btnDelete').click(function() {
        var indexes = [];
        $('input[id^=chkSms]').each(function() {
            if ($(this).prop('checked')) {
                var id = this.id.slice(6);
                indexes.push($('#hddSmsIndex' + id).val());
            }
        });

        if (indexes.length == 0) {
            AlertUtil.alertMsg(PROMPT.status.chooseSms);
            return;
        }
        if (!confirm(PROMPT.confirm.deleteSms)) return;

        deleteByIndexes(indexes, function(ok) {
            if (!ok) {
                AlertUtil.alertMsg('Delete selected SMS failed');
                return;
            }
            getSmsList();
        });
    });

    $('#btnDeleteAll').click(function() {
        if (!confirm(PROMPT.confirm.deleteAllSms)) return;
        clearAll(function(ok) {
            if (!ok) {
                AlertUtil.alertMsg('Clear list failed');
                return;
            }
            getSmsList();
        });
    });

    getSmsList();
});
