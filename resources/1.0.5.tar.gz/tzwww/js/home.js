//针对主界面闪动跳出，事先隐藏
$("#index_template").hide();

//检测是否处于PIN或puk锁定状态
(function checkLock(){
		Page.postJSON({
		json: {
			cmd: RequestCmd.GET_SYS_STATUS,
			method: JSONMethod.GET,
			sessionId: ""
		},
		success: function (datas){
			var pinStats = datas.lock_pin_flag;
			var pukStats = datas.lock_puk_flag;
			if (pukStats == "1"){
				$("#index_template").show();
				$mask.show();
				$("#LockBox").show();
				$("#header").hide();
				$("#main").hide();
				$("#footer").hide();
				$("#info_box").hide();
				$("#progress_box").hide();
				return ;
			}
			if (pinStats == "1"){
				$("#index_template").show();
				$("#header").hide();
				$("#main").hide();
				$("#footer").hide();
				$("#info_box").hide();
				$("#progress_box").hide();
				$mask.show();
				$("#LockBox").show();
				return;
			}
		// 没处于PIN或是puk锁定状态，页面内容显示
			$("#index_template").show();
		},
	});
})();

$(document).ready(function () {
	var menus = [];
	var infoMenu = new MenuHead("info_menu", MENU.info.head);
	infoMenu.push(new MenuBody("WAN_INFO", MENU.info.wan));
	infoMenu.push(new MenuBody("DHCP_INFO", MENU.info.dhcp));
	if (Page.iad_ready_status == "1" || Page.level == "1") {
		infoMenu.push(new MenuBody("WIFI24G_INFO", MENU.info.wifi24));
		infoMenu.push(new MenuBody("WIFI5G_INFO", MENU.info.wifi5));
	} else {
		$("#wifiInfo").detach();
		$("#wifiInfo5g").detach();
		$("#lan1").detach();
		$("#lan2").detach();
		$("#lan3").detach();
		$("#lan4").detach();
		$("#wan1").detach();
	}
	infoMenu.push(new MenuBody("DEVICE_INFO", MENU.info.version));
	infoMenu.push(new MenuBody("VNSTAT", "vnStat"));
	if(Page.level == "1"){
		infoMenu.push(new MenuBody("CALIBRATION_INFO", MENU.info.checkInfo));
	}

	menus.push(infoMenu);

	var settingwanInfoMenu = new MenuHead("wan_info", MENU.setting.wan);
	settingwanInfoMenu.push(new MenuBody("NETWORK_SET", TAB.advance.networkSet));
	settingwanInfoMenu.push(new MenuBody("APN_CONFIG", DOC.apn.setting));
	settingwanInfoMenu.push(new MenuBody("PIN_CONFIG", TAB.basic.simSet));
	if(Page.esim_show == "1" || Page.level == "1"){
		// settingwanInfoMenu.push(new MenuBody("ESIM_MANAGE", TAB.basic.esimManage));
	}

	if(Page.pageHideCheck(18))
		// settingwanInfoMenu.push(new MenuBody("DISPLAY_SOLUTION_MODE", TAB.basic.displaySolution));

	if(Page.level != "3")
	{
		settingwanInfoMenu.push(new MenuBody("SLICE_CONIFIG", TAB.basic.sliceConfiguration));
	}

	// settingwanInfoMenu.push(new MenuBody("AUTODIAL_CONFIG", DOC.lbl.autoDial));
	// settingwanInfoMenu.push(new MenuBody("ROAMING_CONFIG",  DOC.lbl.roaming));
	menus.push(settingwanInfoMenu);;

	/* WIRELESS_CONFIG */
	if (Page.iad_ready_status == "1" || Page.level == "1") {
		var settingWifiMenu = new MenuHead("wifi_menu", MENU.settingWifi.head);
		settingWifiMenu.push(new MenuBody("WIRELESS_CONFIG", MENU.settingWifi.wifi));
		settingWifiMenu.push(new MenuBody("WIRELESS_ADVANCE", MENU.settingWifi.wifiAdvance));
		settingWifiMenu.push(new MenuBody("WIRELESS5G_CONFIG", MENU.settingWifi.wifi5g));
		settingWifiMenu.push(new MenuBody("WIRELESS5G_ADVANCE", MENU.settingWifi.wifi5gAdvance));
		settingWifiMenu.push(new MenuBody("WPS_CONFIG", wirelessconfightml.tab_menu.wps));
		settingWifiMenu.push(new MenuBody("WIRELESS_MACFILTER", wirelessconfightml.tab_menu.wifiList));
		menus.push(settingWifiMenu);;
	}
	var settingMenu = new MenuHead("manage_menu", MENU.setting.head);

	// 	settingMenu.push(new MenuBody("DEMO_CONFIG", MENU.setting.quick));
	//    } else {
	//    	/* QUICK_SETTINGS */
	// 	settingMenu.push(new MenuBody("QUICK_SETTINGS", MENU.setting.wizard));
	//    }
	// settingMenu.push(new MenuBody("BASIC_CONFIG", MENU.setting.wan));

	settingMenu.push(new MenuBody("NETWORK_CONFIG", MENU.setting.dhcp));
	settingMenu.push(new MenuBody("ROUTER_TABLE", MENU.setting.route));
	settingMenu.push(new MenuBody("CHANGE_TTL", "TTL Change"));
	settingMenu.push(new MenuBody("CHANGE_IMEI", "IMEI Change"));
	settingMenu.push(new MenuBody("SEND_AT", "AT Terminal"));
	if (Page.pageHideCheck(31) || Page.pageHideCheck(45)) {
		settingMenu.push(new MenuBody("VPN_SETTING", MENU.vpn.head));
	}
	if (Page.pageHideCheck(41)) {
		settingMenu.push(new MenuBody("TR069_SETTING", TAB.advance.tr069));
	}
	if (Page.pageHideCheck(32) || Page.pageHideCheck(53) || Page.pageHideCheck(54)) {
		// settingMenu.push(new MenuBody("ONENET_SETTING", TAB.advance.exchange));
	}
	
	if(Page.pageHideCheck(29)) {
		settingMenu.push(new MenuBody("IP_PASSTHROUGH", "IP Passthrough"));
	}

	/* QoS Configure */
	// settingMenu.push(new MenuBody("QoS_CONFIG", MENU.setting.qos));


	/* ADVANCED_CONFIG */
	if(Page.pageHideCheck(49))
	{
		settingMenu.push(new MenuBody("ADVANCED_CONFIG", MENU.setting.advanced));
	}
	menus.push(settingMenu);

	/* SMS (single inbox) */
	var smsMenu = new MenuHead("sms_menu", "SMS");
	smsMenu.push(new MenuBody("SMS_RECEIVE", "Inbox"));
	menus.push(smsMenu);

	// FW BEGIN
	var fwMenu = new MenuHead("fw_menu", MENU.fw.head);
	fwMenu.push(new MenuBody("FW_DMZ", "DMZ"));
	fwMenu.push(new MenuBody("FW_PORT_MAPPING", MENU.fw.portMapping));
	fwMenu.push(new MenuBody("FW_RULE", MENU.fw.filters));
	fwMenu.push(new MenuBody("URL_FILTER", MENU.fw.urlFilter));
	fwMenu.push(new MenuBody("FW_IP_MAC_BINDING", MENU.fw.ipMacBinding));
	fwMenu.push(new MenuBody("STATIC_ARP_BINDING", MENU.sys.staticArp));
	fwMenu.push(new MenuBody("FW_ACL_FILTER", MENU.fw.aclFilter));
	fwMenu.push(new MenuBody("DDOS_PROTECTION", MENU.fw.ddosProtection));
	fwMenu.push(new MenuBody("FW_SPEED_LIMIT", MENU.fw.speedLimit));
	if(Page.pageHideCheck(39))
		fwMenu.push(new MenuBody("FW_UPNP", MENU.fw.upnp));


	menus.push(fwMenu);

	/* FW END */

	var sysMenu = new MenuHead("system_menu", MENU.sys.manage);
	sysMenu.push(new MenuBody("SYS_SET", MENU.sys.settings));
	sysMenu.push(new MenuBody("TIME_TO_RESTART", MENU.sys.timeToRestart));

	/* SYS_CHECK */
	// sysMenu.push(new MenuBody("SYS_CHECK", MENU.sys.checking));

	/* SYS_LOG */
	sysMenu.push(new MenuBody("SYS_LOG", MENU.sys.sysLog));
	sysMenu.push(new MenuBody("EXPORT_LOG", MENU.sys.exportLog));

		// if (Page.pageHideCheck(40)) {
		// 	sysMenu.push(new MenuBody("SYS_AUTO_UPGRADE", MENU.sys.sysAutoUpgrade));
		// }
  /* CONFIG_UPDATE */
  // if (Page.level != "3") {
		// sysMenu.push(new MenuBody("CONFIG_UPDATE", MENU.sys.configUpdate));
	// }
	sysMenu.push(new MenuBody("ADB_SWITCH", TAB.sys.adbSwitch));
	/* NETWORK_TOOLS */
	sysMenu.push(new MenuBody("NETWORK_TOOLS", MENU.sys.networkTools));
	sysMenu.push(new MenuBody("TELNET_MANAGE", "Telnet"));

	/* LTE_LOG_CONFIG */
	// sysMenu.push(new MenuBody("LTE_LOG_CONFIG", MENU.sys.modemLogSettings));

	/* SYS_REBOOT_PAGE */
	// sysMenu.push(new MenuBody("SYS_REBOOT_PAGE", MENU.sys.reboot));

	/* SYS_REBOOT */
	sysMenu.push(new MenuBody("SYS_REBOOT", MENU.sys.reboot));

	/* SYS_HELPER */
	// sysMenu.push(new MenuBody("SYS_HELPER", MENU.sys.helper));
	menus.push(sysMenu);
	$('#menu').html(MenuUtil.create(menus));
	if(Page.current_card_type == "0"){
		$('#ESIM_MANAGE').removeClass().addClass("not_click");
	}
	var hasHash = false;
	var fm = ["pingForm1", "index_template", "pingFormId1"];
    Page.createForm(fm);
	var vm = new Vue({
		el: "#index_template",
		data: {
			logout: DOC.link.logout,
			copyright: DOC.copyright,
			close: DOC.btn.close,
			languageSelectValue: "",
			languageSelectList: [],
			languageSelectShow: false,
			menu:menus,
			defaultIndex:"0-0",
			icon:["icon-xitong","icon-gongneng","icon-WIFI","icon-shezhi","icon-xiayidaifanghuoqiang","icon-peizhi"],
			LockBox:"",
			pinVerification: DOC.lbl.pinVerification,
			isShowPuk: false,
            isShowPin: false,
			colon: DOC.colon,
			pinCode: DOC.lbl.pinCode,
			pinSetRemind: TAB.basic.pinSetRemind,
			pinPassword:'',
			puk: CHECK.required.puk,
			newPin: CHECK.required.newPin,
            newPinConfirm: CHECK.required.newPinConfirm,
			pukPassword: '',
            pukPinPassword: '',
			pukPinPasswordConfirm: '',
			save: DOC.btn.save,
			optr:"",
			pinStats: "",
            pukStats: "",
		},
		methods: {
			lockBoxbtnClose:
			function(){
				vm.clickLogout();
			},
		// 检测是否处于PIN或puk锁定状态
		checkLock1:
			function (){
				Page.postJSON({
				json: {
					cmd: RequestCmd.QUERY_SIM_STATUS,					
				},
				success: function (datas){
					vm.pinStats = datas.lock_pin_flag;
					vm.pukStats = datas.lock_puk_flag;
					if (vm.pukStats == "1"){
						vm.LockBox = true;
						vm.isShowPuk=true;
						$("#Lock_box").css("left","45%");
						$("#Lock_box").css("border","solid 8px #fff")
						$mask.css("background","#0000004a")
						$mask.show();
					}
					if (vm.pinStats == "1"){
						vm.LockBox = true;
						vm.isShowPin=true;
						$mask.show();
						$("#Lock_box").css("left","45%");
						$("#Lock_box").css("border","solid 8px #fff")
						$mask.css("background","#0000004a")
						$mask.show();
					}
				}
			});
		},

		
		btnSave: function () {
			// $mask.hide();	
			vm.btnDis = true;
			var json = {};
			//使用pingForm1为表单名，因为屏pingForm已存在再DOM树中
			var $form = $('#pingForm1'),
				json = JSON.parmsToJSON($form);
			//PIN验证规则
			var rules1 = {
					pin: {
						required: true,
						digits: true,
						rangelength: [4, 8]
					}
				},
				messages1 = {
					pin: {
						required: CHECK.required.pinCode,
						digits: CHECK.format.digits,
						rangelength: CHECK.rangeLength.pinCode
					}
				};

			//PUK验证规则
			var rules3 = {
					pukPassword1: {
						required: true,
						digits: true,
						rangelength: [8,8]
					},
					pukPinPassword1: {
						required: true,
						digits: true,
						rangelength: [4, 8]
					},
					pukPinPasswordConfirm1: {
						required: true,
						digits: true,
						rangelength: [4, 8]
					}
				},
				messages3 = {
					pukPassword1: {
						required: CHECK.required.puk,
						digits: CHECK.format.digits,
						rangelength: CHECK.rangeLength.puk
					},
					pukPinPassword1: {
						required: CHECK.required.pinCode,
						digits: CHECK.format.digits,
						rangelength: CHECK.rangeLength.pinCode
					},
					pukPinPasswordConfirm1: {
						required: CHECK.required.pinCode,
						digits: CHECK.format.digits,
						rangelength: CHECK.rangeLength.pinCode
					}
				};
				
			// 如果处于puk锁定
			if (vm.pukStats == "1") { 
				if (vm.pukPinPassword != vm.pukPinPasswordConfirm) {
					AlertUtil.alertMsg(CHECK.required.newPinConfirm2);
					vm.btnDis = false;
					$mask.show();
					return;
				};
				if (!CheckUtil.checkForm($form, rules3, messages3)) {
					vm.btnDis = false;
					$mask.show();
					return;
				};
				json.puk = vm.pukPassword;
				json.pin = vm.pukPinPasswordConfirm;
				// json.enable = "1";
				json.subcmd = "3";
			} else {
				// 处于PIN锁定状态
				if (vm.pinStats == "1") {

					
					if (!CheckUtil.checkForm($form, rules1, messages1)) {
						vm.btnDis = false;
						$mask.show();
						return;
					};
					json.subcmd = "2";
				}
				json.pin = vm.pinPassword;
			}
			fyAlertMsgLoading();
			json.method = JSONMethod.POST;
			json.cmd = RequestCmd.MODEM_CMD;
			// 不是成功解锁
			Page.postJSON({
				json: json,
				success: function (datas) {
					if (datas.message == "0") {
						setTimeout(function () {
						//成功就刷新页面，考虑到页面性能也可选择对应的隐藏或是显现。
						location.reload();
						}, 5000);
					} else {
						setTimeout(function () {
							Page.postJSON({
								json: {
									cmd: RequestCmd.QUERY_SIM_STATUS
								},
								success: function (data){
									if(parseInt(data.pin_left_times) < 1 && data.puk_left_times == 10){
										// vm.pinBox=false;
										location.reload();
									}else{
										fyAlertMsgFail();
										setTimeout(function() {
											if(parseInt(data.pin_left_times) < 3 && data.pin_left_times != 0){
												// fyAlertMsgFail(String.format(PROMPT.status.pingTimes, data.pin_left_times));
												// fyAlert.destory();
												AlertUtil.alertMsg(String.format(PROMPT.status.pingTimes, data.pin_left_times));
											}
											if(parseInt(data.puk_left_times) < 10){
												// fyAlertMsgFail(String.format(PROMPT.status.pukTimes, data.puk_left_times));
												// fyAlert.destory();
												AlertUtil.alertMsg(String.format(PROMPT.status.pukTimes, data.puk_left_times));
											}
										}, 1000);
										vm.LockBox=true;
										$mask.show();

									}
								}
							});
							
						}, 5000);
					}
					vm.btnDis = false;
				},
				error:function(){
					setTimeout(function () {
						fyAlertMsgFail();
						vm.getData();
					}, 5000);
				}
			});
		},
			clickMenu: function(id,first,second){
				$("[id^='el-tooltip-']").remove();
				resetTime();
				if(Page.timer){
					_clearInterval();
				}
				localStorage.setItem("flag1",true)
				var currentIndex = first+'-'+second;
				localStorage.setItem("index1",currentIndex)
				var item = MenuItem[id];
				if (item != null) {
					if (item.cmd == RequestCmd.SYS_REBOOT) {
						SysUtil.rebootDevice(RENOOTTYPE.NORMAL_REBOOT, PROMPT.confirm.reboot);
					} else {
						Page.menuItem = item;
						Page.$iframe.load(item.url);
						window.location.hash = "#" + id + "#0";
						Page.setHash(window.location.hash);

					}
				}
			},
			handleOpen: function(key) {
				for(var i=0;i<this.menu.length;i++){
					if(key-1 ==i){
						this.$set(this.menu[i],"isSelect",true)
					}else{
						this.$set(this.menu[i],"isSelect",false)
					}
				}
				this.defaultIndex = key-1+'-'+'0'
				localStorage.setItem("index1",this.defaultIndex)
				var id = this.menu[key-1].bodys[0].id;
				var item = MenuItem[id];
				if (item != null) {
					if (item.cmd == RequestCmd.SYS_REBOOT) {
						SysUtil.rebootDevice(RENOOTTYPE.NORMAL_REBOOT, PROMPT.confirm.reboot);
					} else {
						Page.menuItem = item;
						Page.$iframe.load(item.url);
						window.location.hash = "#" + id + "#0";
						Page.setHash(window.location.hash);

					}
				}
			  },
			  handleClose: function(key, keyPath) {
				// console.log(key, keyPath);
			  },

			changeLanguageSelect: function () {
				Page.postJSON({
					json: {
						cmd: RequestCmd.CHANGE_LANGUAGE,
						method: JSONMethod.POST,
						sessionId: "",
						languageSelect: vm.languageSelectValue
					},
					success: function (data) {},
					complete: function () {
						localStorage.setItem("flag1",false)
						var href = location.href;
						if (href.indexOf('#') > -1) {
							href = href.substring(0, href.indexOf('#'));
						}
						if (href.indexOf('?') > -1) {
							href = href.substring(0, href.indexOf('?'));
						}
						location.href = Page.getUrl(href);
					}
				});
			},
			setMenuItem: function (itemId) {
				var $lis = $('#menu li');
				$lis.removeClass('current');
				$('#' + itemId).parent().addClass('current');
			},
			clickLogout: function () {
				if ($(".fy-alert-shadow").length > 0) {
					return false;
				}
				fyConfirmMsg(DOC.link.conifgLogout, function () {
					Page.postJSON({
						json: {
							cmd: RequestCmd.LOGOUT,
							method: JSONMethod.POST
						},
						success: function (data) {
							var option = {
								expireHours: -1,
								path: '/',
								domain: location.hostname
							};
							// localStorage.clear()
							CookieUtil.deleteCookie("sessionId", option);
							sessionStorage.clear();
							location.href = Page.getUrl(Url.LOGIN);
						}
					});
				})
			},
			btnClose: function () {
				$('#info_box').hide();
				$('#mask').hide();
				$('#progress_box').hide();
			},
			changePage:function(){
				location.reload();
			},
			firstLoad: function () {
				var hashLoad = window.location.hash.split("#");
				if (hashLoad.length >= 2 && hashLoad[1] != '') {
					var id = hashLoad[1];
					var item = MenuItem[id];
					if (item != null) {
						Page.menuItem = item;
						Page.$iframe.load(item.url);
					} else {
						this.clickMenu("WAN_INFO", 0, 0)
					}
				} else {
					this.clickMenu("WAN_INFO", 0, 0)
				}
			},
			init: function () {
				Page.$iframe = $('#right');
				Page.initPage();
				$(window).resize(function () {
					Page.initPage();
				});
				StatusUtil.getSysStatus();
				Page.postJSON({
					json: {
						cmd: RequestCmd.INIT_PAGE
					},
					success: function (data) {
						vm.languageSelectValue = data.language.toLowerCase();
						var supportLanguage = [];
						if (data.language_support) {
							supportLanguage = parseInt(data.language_support, 16).toString(2).split("").reverse();
							for (var i = 0; i < supportLanguage.length; i++) {
								if (supportLanguage[i] == "1") {
									vm.languageSelectList.push(Page.getSupportlanguageList[i])
								}
							}
						} else {
							vm.languageSelectList = Page.getSupportlanguageList;
						}
						if (data.language_show == "1") {
							vm.languageSelectShow = true;
						} else {
							vm.languageSelectShow = false;
						}
					}
				});
				$('#container').show();
				this.firstLoad();
			}
		},
		mounted: function () {
			//检测是否处于PIN或puk锁定状态
			this.checkLock1();
			//添加hash防止网页输入URL直接跳转
			if (!!window.location.hash && Page.getHash() != window.location.hash && !!Page.getHash()) {
				window.location.hash = Page.getHash();
			}
			this.init();
			setInterval(Page.getDeviceName, 7000);
			var flag = localStorage.getItem("flag1")
			var index = localStorage.getItem("index1")
			this.defaultIndex = index;
			if(index=="0-0"&&flag=="false"){
				this.clickMenu("WAN_INFO",0,0)
			}else if(flag=="false"){
				this.defaultIndex = "0-0"
				Page.$iframe.load("html/info/wan_index.html");
			}
			var selcetIndex = this.defaultIndex.slice(0,1)
			for(var i=0;i<this.menu.length;i++){
				if(selcetIndex ==i){
					this.$set(this.menu[i],"isSelect",true)
				}else{
					this.$set(this.menu[i],"isSelect",false)
				}
				this.$set(this.menu[i],"icon",this.icon[i])
			}
		}
	})
	$mask=$("#mask");
});
