$(document).ready(function () {
    var $mask = $('#mask');
    var titleArr = [DOC.table.enableRule, DOC.table.priority, DOC.net.mac, DOC.net.maxSpeed,
        DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule
    ];

    function cleanText(v) {
        if (v === undefined || v === null) {
            return "";
        }
        return String(v).replace(/[\x00-\x1F\x7F]/g, "").replace(/^\s+|\s+$/g, "");
    }

    function pickFirst(item, keys) {
        for (var i = 0; i < keys.length; i++) {
            var val = item[keys[i]];
            if (val !== undefined && val !== null && String(val) !== "") {
                return val;
            }
        }
        return "";
    }

    function normalizeMac(v) {
        var raw = cleanText(v);
        var direct = raw.match(/([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}/);
        if (direct && direct[0]) {
            return direct[0].toUpperCase().replace(/-/g, ":");
        }
        var hex = raw.replace(/[^0-9a-fA-F]/g, "");
        if (hex.length >= 12) {
            hex = hex.slice(hex.length - 12).toUpperCase();
            return hex.replace(/(..)(?=.)/g, "$1:");
        }
        return "";
    }

    function normalizeIp(v) {
        var raw = cleanText(v);
        var m = raw.match(/((\d{1,3}\.){3}\d{1,3})|(([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4})/);
        return m && m[0] ? m[0] : "";
    }

    function normalizeWifiRows(rows, fallbackSsid) {
        var out = [];
        if (!rows || !rows.length) {
            return out;
        }
        for (var i = 0; i < rows.length; i++) {
            var item = rows[i] || {};
            var mac = normalizeMac(pickFirst(item, ["mac", "macaddr", "macAddress", "addr", "sta_mac"]));
            if (!mac) {
                continue;
            }
            var host = cleanText(pickFirst(item, ["user", "host", "hostname", "name", "device", "devName"]));
            var ip = normalizeIp(pickFirst(item, ["ip", "ipaddr", "ipAddress", "sta_ip"]));
            var ssid = cleanText(pickFirst(item, ["ssid", "wifi", "wifissid"])) || fallbackSsid;
            out.push({
                mac: mac,
                hostname: host,
                ip: ip,
                ssid: ssid
            });
        }
        return out;
    }

    function buildConnectedClients(dhcpRows, wifi24Rows, wifi5Rows) {
        var map = {};

        function upsert(entry) {
            if (!entry || !entry.mac) {
                return;
            }
            var mac = entry.mac.toUpperCase();
            if (!map[mac]) {
                map[mac] = {
                    mac: mac,
                    hostname: "",
                    ip: "",
                    ssid: ""
                };
            }
            if (entry.hostname && !map[mac].hostname) {
                map[mac].hostname = entry.hostname;
            }
            if (entry.ip && !map[mac].ip) {
                map[mac].ip = entry.ip;
            }
            if (entry.ssid && (!map[mac].ssid || map[mac].ssid === "LAN/DHCP" || map[mac].ssid === "-")) {
                map[mac].ssid = entry.ssid;
            }
        }

        var dhcpList = dhcpRows || [];
        for (var i = 0; i < dhcpList.length; i++) {
            var d = dhcpList[i] || {};
            upsert({
                mac: normalizeMac(pickFirst(d, ["mac", "macaddr", "macAddress", "client_mac"])),
                ip: normalizeIp(pickFirst(d, ["ip", "ipaddr", "ipAddress", "client_ip"])),
                hostname: cleanText(pickFirst(d, ["hostname", "host", "name", "user", "client_name"])),
                ssid: "LAN/DHCP"
            });
        }

        var wifi24 = normalizeWifiRows(wifi24Rows, "Wi-Fi 2.4G");
        for (var j = 0; j < wifi24.length; j++) {
            upsert(wifi24[j]);
        }

        var wifi5 = normalizeWifiRows(wifi5Rows, "Wi-Fi 5G");
        for (var k = 0; k < wifi5.length; k++) {
            upsert(wifi5[k]);
        }

        var arr = [];
        for (var mac in map) {
            if (map.hasOwnProperty(mac)) {
                var row = map[mac];
                var hostLabel = row.hostname || "-";
                var ssidLabel = row.ssid || "-";
                var ipLabel = row.ip ? (" | " + row.ip) : "";
                row.optionLabel = "[" + ssidLabel + "] " + hostLabel + " | " + row.mac + ipLabel;
                arr.push(row);
            }
        }
        arr.sort(function (a, b) {
            var ka = (a.hostname || a.mac).toLowerCase();
            var kb = (b.hostname || b.mac).toLowerCase();
            if (ka < kb) return -1;
            if (ka > kb) return 1;
            return a.mac < b.mac ? -1 : (a.mac > b.mac ? 1 : 0);
        });
        return arr;
    }

    var vm = new Vue({
        el: "#child_container",
        data: {
            title: titleArr,
            value: [],
            addAclFiltering: DOC.title.addAclFiltering,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            clearAllRules: DOC.btn.clearAllRules,
            addSpeedLimit: DOC.title.addSpeedLimit,
            close: DOC.btn.close,
            colon: DOC.colon,
            ip: DOC.net.mac,
            example: DOC.lbl.example,
            maxSpeed: DOC.net.maxSpeed,
            kBPerSeconds: "Mbps",
            remark: DOC.lbl.remark,
            connectedDevice: DOC.lbl.connectedDevicesViaWiFi,
            refresh: DOC.btn.refresh,
            selectItem: DOC.lbl.selectItem,
            save: DOC.btn.save,
            edit_box: false,
            rowFlag: "",
            macaddr: '',
            speed: '',
            comment: '',
            selectedClientMac: "",
            connectedClients: [],
            connectedLoading: false,
            isApply: false,
            isClear: false,
            showTip: false
        },
        methods: {
            toMbps: function (kbps) {
                var n = parseFloat(kbps);
                if (isNaN(n)) return "";
                var mbps = n / 100;
                return (Math.round(mbps * 100) / 100).toString();
            },
            toKbps: function (mbps) {
                var n = parseFloat(mbps);
                if (isNaN(n)) return NaN;
                return Math.round(n * 100);
            },
            formatMbps: function (kbps) {
                var t = this.toMbps(kbps);
                return t === "" ? "-" : (t + " Mbps");
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SPEED_LIMIT,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        var list = data.datas || [];
                        if (list.length > 0) {
                            for (var i = 0; i < list.length; i++) {
                                list[i].speed = vm.toMbps(list[i].maxSpeed);
                            }
                            vm.value = list;
                            vm.fillMacFromDhcp();
                        } else {
                            vm.value = [];
                        }
                    }
                });
            },
            fetchConnectedClients: function () {
                this.connectedLoading = true;
                var dhcpRows = [];
                var wifi24Rows = [];
                var wifi5Rows = [];
                var doneCount = 0;

                function done() {
                    doneCount++;
                    if (doneCount < 3) {
                        return;
                    }
                    vm.connectedClients = buildConnectedClients(dhcpRows, wifi24Rows, wifi5Rows);
                    vm.connectedLoading = false;
                    if (vm.selectedClientMac) {
                        var found = false;
                        for (var i = 0; i < vm.connectedClients.length; i++) {
                            if (vm.connectedClients[i].mac === vm.selectedClientMac) {
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            vm.selectedClientMac = "";
                        }
                    }
                }

                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (res) {
                        dhcpRows = res.dhcp_list_info || [];
                        done();
                    },
                    error: function () {
                        done();
                    }
                });

                if (RequestCmd.WIFI24G_LIST_INFO) {
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.WIFI24G_LIST_INFO,
                            method: JSONMethod.GET
                        },
                        success: function (res) {
                            wifi24Rows = res.wlan24g_wifi_info || [];
                            done();
                        },
                        error: function () {
                            done();
                        }
                    });
                } else {
                    done();
                }

                if (RequestCmd.WIFI5G_LIST_INFO) {
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.WIFI5G_LIST_INFO,
                            method: JSONMethod.GET
                        },
                        success: function (res) {
                            wifi5Rows = res.wlan5g_wifi_info || [];
                            done();
                        },
                        error: function () {
                            done();
                        }
                    });
                } else {
                    done();
                }
            },
            refreshConnectedClients: function () {
                this.fetchConnectedClients();
            },
            useSelectedClient: function () {
                if (!this.selectedClientMac) {
                    AlertUtil.alertMsg(this.selectItem || "Please select");
                    return;
                }
                for (var i = 0; i < this.connectedClients.length; i++) {
                    var item = this.connectedClients[i];
                    if (item.mac === this.selectedClientMac) {
                        this.macaddr = item.mac;
                        this.comment = item.hostname || item.ssid || "";
                        break;
                    }
                }
            },
            onConnectedClientChange: function (mac) {
                if (!mac) {
                    return;
                }
                this.useSelectedClient();
            },
            fillMacFromDhcp: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (res) {
                        var mapByIp = {};
                        var list = res.dhcp_list_info || [];
                        for (var i = 0; i < list.length; i++) {
                            if (list[i].ip && list[i].mac) {
                                mapByIp[list[i].ip] = list[i].mac.toUpperCase();
                            }
                        }
                        for (var j = 0; j < vm.value.length; j++) {
                            var row = vm.value[j];
                            if (!row.mac && row.ip && mapByIp[row.ip]) {
                                vm.$set(row, "mac", mapByIp[row.ip]);
                            }
                        }
                    }
                });
            },
            editAcl: function (index) {
                this.edit_box = true;
                $mask.show();
                this.macaddr = this.value[index].mac || "";
                this.speed = this.toMbps(this.value[index].maxSpeed);
                this.comment = this.value[index].remark;
                this.selectedClientMac = this.macaddr || "";
                this.rowFlag = index;
                this.fetchConnectedClients();
            },
            delAcl: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function(){
                        vm.showTip = true;
                    });
                })
            },
            btnCloseRule: function () {
                this.edit_box = false;
                $mask.hide();
                this.rowFlag = "";
                this.selectedClientMac = "";
            },
            addRuleClick: function () {
                this.edit_box = true;
                $mask.show();
                this.macaddr = '';
                this.speed = '';
                this.comment = '';
                this.rowFlag = "";
                this.selectedClientMac = "";
                this.fetchConnectedClients();
            },
            btnSave: function () {
                var speedCheck = /^([0-9]+)(\.[0-9]+)?$/;
                if (this.macaddr == "") {
                    AlertUtil.alertMsg(CHECK.required.mac);
                    return false;
                }
                if (!CheckUtil.checkMac(this.macaddr)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                if (this.speed == "") {
                    AlertUtil.alertMsg(CHECK.required.maxSpeed);
                    return false;
                }
                if (!(speedCheck.test(String(this.speed)))) {
                    AlertUtil.alertMsg(CHECK.format.maxSpeed);
                    return false;
                }
                var speedKbps = this.toKbps(this.speed);
                if (isNaN(speedKbps) || speedKbps <= 0) {
                    AlertUtil.alertMsg(CHECK.format.maxSpeed);
                    return false;
                }
                var macNorm = this.macaddr.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                this.selectedClientMac = macNorm;
                var temp = {
                    ip: "",
                    mac: macNorm,
                    maxSpeed: String(speedKbps),
                    remark: this.comment,
                    ippro: "IPV4"

                };
                for(var i=0;i<this.value.length;i++){
                    if((this.value[i].mac || "").toUpperCase() == temp.mac){
                        if(this.rowFlag === i && (this.value[i].remark != temp.remark || this.value[i].maxSpeed != temp.maxSpeed) ){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.rowFlag === "number"){
                    temp.enableRule = this.value[this.rowFlag].enableRule;
                    this.value[this.rowFlag] = temp;
                } else {
                    temp.enableRule = true;
                    this.value.push(temp);
                }
                this.showTip = false;
                this.$nextTick(function(){
                    this.showTip = true;
                });
                this.btnCloseRule();
            },
            applyRulesClick: function () {
                this.isApply = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (res) {
                        var mapByMac = {};
                        var list = res.dhcp_list_info || [];
                        for (var i = 0; i < list.length; i++) {
                            if (list[i].mac && list[i].ip) {
                                mapByMac[list[i].mac.toUpperCase()] = list[i].ip;
                            }
                        }
                        var connectedMapByMac = {};
                        for (var c = 0; c < vm.connectedClients.length; c++) {
                            var connected = vm.connectedClients[c];
                            if (connected.mac && connected.ip) {
                                connectedMapByMac[connected.mac.toUpperCase()] = connected.ip;
                            }
                        }
                        var payload = [];
                        for (var j = 0; j < vm.value.length; j++) {
                            var row = vm.value[j];
                            var mac = (row.mac || "").toUpperCase();
                            var ip = mapByMac[mac] || connectedMapByMac[mac] || row.ip || "";
                            if (!ip) {
                                vm.isApply = false;
                                fyAlertMsgFail("IP aktif tidak ditemukan untuk MAC: " + mac);
                                return;
                            }
                            payload.push({
                                enableRule: !!row.enableRule,
                                ippro: "IPV4",
                                ip: ip,
                                maxSpeed: row.maxSpeed,
                                remark: row.remark || "",
                                mac: mac
                            });
                        }
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.SPEED_LIMIT,
                                method: JSONMethod.POST,
                                success: true,
                                datas: payload
                            },
                            success: function (data) {
                                vm.isApply = false;
                                vm.showTip = false;
                                if (data.success == true) {
                                    for (var k = 0; k < vm.value.length; k++) {
                                        vm.value[k].ip = payload[k].ip;
                                    }
                                    Page.applyFilter();
                                } else {
                                    fyAlertMsgFail();
                                }
                            },
                            error: function () {
                                vm.isApply = false;
                                fyAlertMsgFail();
                            }
                        });
                    },
                    error: function () {
                        vm.isApply = false;
                        fyAlertMsgFail("Gagal ambil DHCP list");
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    vm.isClear = true;
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.SPEED_LIMIT,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.isClear = false;
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            }
        },
        mounted:function(){
            this.getData();
            this.fetchConnectedClients();
        }
    });
    
});
