#!/bin/sh

PATH="/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
export PATH

read_body() {
    if [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
        dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null
    else
        cat
    fi
}

urldecode() {
    encoded="$(printf "%s" "$1" | sed 's/+/ /g; s/%/\\x/g')"
    printf '%b' "$encoded"
}

get_param_raw() {
    key="$1"
    src="$2"
    value="$(printf "%s" "$src" | sed -n "s/^${key}=\([^&]*\).*$/\1/p")"
    if [ -z "$value" ]; then
        value="$(printf "%s" "$src" | sed -n "s/.*&${key}=\([^&]*\).*/\1/p")"
    fi
    printf "%s" "$value"
}

get_param() {
    key="$1"
    src="$2"
    urldecode "$(get_param_raw "$key" "$src")"
}

header_json() {
    printf "Status: 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\n\r\n"
}

header_text() {
    printf "Status: 200 OK\r\nContent-Type: text/plain\r\nCache-Control: no-store\r\n\r\n"
}

json_escape() {
    printf "%s" "$1" | tr '\t' ' ' | sed ':a;N;$!ba;s/\\/\\\\/g;s/"/\\"/g;s/\r//g;s/\n/\\n/g'
}

send_json_error() {
    msg="$1"
    header_json
    printf '{"success":false,"message":"%s"}\n' "$(json_escape "$msg")"
    exit 0
}

ACTION_QUERY="$QUERY_STRING"
BODY=""
if [ "$REQUEST_METHOD" = "POST" ]; then
    BODY="$(read_body)"
fi

ACTION="$(get_param action "$ACTION_QUERY")"
if [ -z "$ACTION" ] && printf "%s" "$BODY" | grep -q '^action='; then
    ACTION="$(get_param action "$BODY")"
fi

[ -n "$ACTION" ] || send_json_error "Missing action"

MOD_HOME="/home/mod"
TELNET_STARTUP_FLAG="$MOD_HOME/telnet"
TTL_STARTUP_FLAG="$MOD_HOME/ttl"
MOD_WEB_INIT="/etc/init.d/modwebextra"

ensure_mod_home() {
    mkdir -p "$MOD_HOME" >/dev/null 2>&1
}

get_telnet_startup_flag() {
    if [ ! -f "$TELNET_STARTUP_FLAG" ]; then
        printf "0"
        return
    fi
    val="$(tr -d '\r\n\t ' < "$TELNET_STARTUP_FLAG" 2>/dev/null)"
    [ "$val" = "1" ] && printf "1" || printf "0"
}

set_telnet_startup_flag() {
    ensure_mod_home || return 1
    case "$1" in
        1) printf "1" > "$TELNET_STARTUP_FLAG" 2>/dev/null ;;
        *) printf "0" > "$TELNET_STARTUP_FLAG" 2>/dev/null ;;
    esac
}

get_ttl_startup_flag() {
    if [ ! -f "$TTL_STARTUP_FLAG" ]; then
        printf ""
        return
    fi
    tr -d '\r\n\t ' < "$TTL_STARTUP_FLAG" 2>/dev/null
}

set_ttl_startup_flag() {
    ensure_mod_home || return 1
    printf "%s" "$1" > "$TTL_STARTUP_FLAG" 2>/dev/null
}

clear_ttl_startup_flag() {
    ensure_mod_home || return 1
    : > "$TTL_STARTUP_FLAG" 2>/dev/null
}

is_valid_ttl() {
    val="$1"
    case "$val" in ''|*[!0-9]*) return 1 ;; esac
    [ "$val" -ge 1 ] && [ "$val" -le 255 ]
}

clear_ttl_rules() {
    while :; do
        cur="$(iptables -t mangle -S POSTROUTING 2>/dev/null | awk '/--ttl-set/{print $NF}' | tail -n 1)"
        [ -z "$cur" ] && break
        iptables -t mangle -D POSTROUTING -j TTL --ttl-set "$cur" >/dev/null 2>&1 || break
    done
}

apply_ttl_now() {
    ttl="$1"
    is_valid_ttl "$ttl" || return 1
    clear_ttl_rules
    iptables -t mangle -A POSTROUTING -j TTL --ttl-set "$ttl" >/dev/null 2>&1
}

reload_modweb_daemon() {
    cmd="$1"
    if [ -x "$MOD_WEB_INIT" ]; then
        "$MOD_WEB_INIT" "$cmd" >/dev/null 2>&1 || true
    fi
}

is_telnet_enabled() {
    pgrep -x telnetd >/dev/null 2>&1 || ps | grep '[t]elnetd' >/dev/null 2>&1
}

json_bool() {
    if [ "$1" = "1" ]; then
        printf "true"
    else
        printf "false"
    fi
}

telnet_start_now() {
    killall telnetd >/dev/null 2>&1
    telnetd -l /bin/sh -p 23 >/dev/null 2>&1
    sleep 1
    is_telnet_enabled
}

telnet_stop_now() {
    killall telnetd >/dev/null 2>&1
    sleep 1
    ! is_telnet_enabled
}

telnet_print_json_state() {
    running="0"
    startup="0"
    is_telnet_enabled && running="1"
    [ "$(get_telnet_startup_flag)" = "1" ] && startup="1"
    printf '{"success":true,"running":%s,"startup_enabled":%s}\n' \
        "$(json_bool "$running")" "$(json_bool "$startup")"
}

VNSTAT_IFACE="seth_lte0"

run_with_timeout() {
    if command -v timeout >/dev/null 2>&1; then
        timeout 12 "$@"
    else
        "$@"
    fi
}

run_vnstat_cmd() {
    mode="$1"

    if [ -x /home/vnstat/run-vnstat.sh ]; then
        if [ -n "$mode" ]; then
            run_with_timeout /home/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout /home/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    if [ -f /home/vnstat/run-vnstat.sh ]; then
        if [ -n "$mode" ]; then
            run_with_timeout sh /home/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout sh /home/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    if [ -x /home/mod/vnstat/run-vnstat.sh ]; then
        if [ -n "$mode" ]; then
            run_with_timeout /home/mod/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout /home/mod/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    if [ -f /home/mod/vnstat/run-vnstat.sh ]; then
        if [ -n "$mode" ]; then
            run_with_timeout sh /home/mod/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout sh /home/mod/vnstat/run-vnstat.sh -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    if [ -x /usr/bin/vnstat ]; then
        if [ -n "$mode" ]; then
            run_with_timeout /usr/bin/vnstat -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout /usr/bin/vnstat -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    if [ -x /home/vnstat/lib/ld-linux.so.3 ] && [ -x /home/vnstat/bin/vnstat ]; then
        if [ -n "$mode" ]; then
            run_with_timeout /home/vnstat/lib/ld-linux.so.3 --library-path /home/vnstat/lib /home/vnstat/bin/vnstat -i "$VNSTAT_IFACE" "$mode"
        else
            run_with_timeout /home/vnstat/lib/ld-linux.so.3 --library-path /home/vnstat/lib /home/vnstat/bin/vnstat -i "$VNSTAT_IFACE"
        fi
        return $?
    fi

    return 127
}

run_vnstat_init() {
    if [ -x /home/vnstat/init-db.sh ]; then
        run_with_timeout /home/vnstat/init-db.sh
        return $?
    fi

    if [ -f /home/vnstat/init-db.sh ]; then
        run_with_timeout sh /home/vnstat/init-db.sh
        return $?
    fi

    return 127
}

reset_vnstat_db() {
    rm -rf /tmp/vnstat/db >/dev/null 2>&1 || return 1
    rm -rf /home/vnstat/db >/dev/null 2>&1 || return 1

    run_vnstat_init >/dev/null 2>&1
    return $?
}

get_ttl() {
    iptables -t mangle -S POSTROUTING 2>/dev/null | awk '/--ttl-set/{print $NF}' | tail -n 1
}

ttl_print_json_state() {
    current="$(get_ttl | tr -d '\r\n\t ')"
    startup="$(get_ttl_startup_flag)"
    startup_enabled="0"
    if is_valid_ttl "$startup"; then
        startup_enabled="1"
    else
        startup=""
    fi
    [ -n "$current" ] || current="-"
    printf '{"success":true,"current_ttl":"%s","startup_ttl":"%s","startup_enabled":%s}\n' \
        "$(json_escape "$current")" "$(json_escape "$startup")" "$(json_bool "$startup_enabled")"
}

extract_imei() {
    raw="$1"
    case "$raw" in
        ''|*[!0-9]*)
            echo "$raw" | sed -n 's/.*AT+SPIMEI=0,"\([0-9]\{15\}\)".*/\1/p' | head -n 1
            ;;
        *)
            if [ "${#raw}" -eq 15 ]; then
                echo "$raw"
            fi
            ;;
    esac
}

get_current_imei() {
    atcmd 'AT+CGSN' 2>/dev/null | tr -d '\r' | sed -n 's/^\([0-9]\{15\}\)$/\1/p' | head -n 1
}

normalize_phone() {
    raw="$1"
    clean="$(printf "%s" "$raw" | sed 's/[^0-9+]//g')"
    if [ -n "$clean" ]; then
        printf "%s" "$clean"
    else
        printf "%s" "$raw"
    fi
}

map_sms_status() {
    case "$1" in
        "0") printf "0" ;;
        "1") printf "1" ;;
        "2") printf "2" ;;
        "3") printf "3" ;;
        "REC UNREAD") printf "0" ;;
        "REC READ") printf "1" ;;
        "STO UNSENT") printf "2" ;;
        "STO SENT") printf "3" ;;
        *) printf "1" ;;
    esac
}

append_sms_row() {
    sms_id="$1"
    sms_idx="$2"
    sms_status="$3"
    sms_phone="$4"
    sms_content="$5"
    sms_dt="$6"
    [ "$SMS_FIRST" -eq 1 ] || SMS_JSON="$SMS_JSON,"
    SMS_FIRST=0
    SMS_FOUND=$((SMS_FOUND + 1))
    [ "$sms_phone" = "recv:" ] && sms_phone=""
    [ "$sms_content" = "recv:" ] && sms_content=""
    SMS_JSON="$SMS_JSON{\"smsId\":\"$sms_id\",\"smsIndex\":\"$sms_idx\",\"status\":\"$sms_status\",\"phoneNo\":\"$(json_escape "$sms_phone")\",\"content\":\"$(json_escape "$sms_content")\",\"datetime\":\"$(json_escape "$sms_dt")\"}"
}

sms_collect() {
    mode="$1"
    i=1
    while [ "$i" -le "$SMS_MAX_IDX" ]; do
        out="$(atcmd "AT+CMGR=$i" 2>/dev/null | tr -d '\r')"
        header="$(printf "%s\n" "$out" | sed -n '/^[+]CMGR: /{p;q}')"
        if [ -n "$header" ]; then
            status_txt="$(printf "%s\n" "$header" | sed -n 's/^[+]CMGR: *\([0-9]\+\).*/\1/p')"
            [ -z "$status_txt" ] && status_txt="$(printf "%s\n" "$header" | sed -n 's/^[+]CMGR: *"\([^"]*\)".*/\1/p')"
            status_num="$(map_sms_status "$status_txt")"

            if [ "$mode" = "pdu" ]; then
                body_line="$(printf "%s\n" "$out" | sed 's/\r$//' | sed 's/^[[:space:]]*//' | grep -E '^[0-9A-Fa-f]{20,}$' | head -n 1)"
                append_sms_row "$i" "$i" "$status_num" "" "$body_line" ""
            else
                body_line="$(printf "%s\n" "$out" | sed 's/\r$//' | sed 's/^[[:space:]]*//' | sed '/^recv:$/d; /^[+]CMGR:/d; /^OK$/d; /^$/d; /^AT[+]CMGR=/d' | head -n 1)"
                phone="$(printf "%s\n" "$header" | sed -n 's/^[+]CMGR: "[^"]*","\([^"]*\)".*/\1/p')"
                phone="$(normalize_phone "$phone")"
                datetime="$(printf "%s\n" "$header" | sed -n 's/.*,"\([0-9][0-9]\/[0-9][0-9]\/[0-9][0-9],[^"]*\)".*/\1/p' | head -n 1)"
                append_sms_row "$i" "$i" "$status_num" "$phone" "$body_line" "$datetime"
            fi
        fi
        i=$((i + 1))
    done
}

case "$ACTION" in
    operator)
        header_json
        atcmd "AT+COPS=3,0" >/dev/null 2>&1
        sleep 1
        out="$(atcmd "AT+COPS?" 2>/dev/null | tr -d '\r')"
        line="$(printf "%s\n" "$out" | sed -n '/[+]COPS:/{s/^[[:space:]]*//;p;q}')"
        operator="$(printf "%s\n" "$line" | awk -F'"' 'NF>=2 {print $2; exit}')"
        format="$(printf "%s\n" "$line" | awk -F',' 'NF>=2 {gsub(/[[:space:]]/, "", $2); print $2; exit}')"
        if [ -z "$operator" ]; then
            operator="$(printf "%s\n" "$line" | sed -n 's/^[+]COPS:[[:space:]]*[^,]*,[[:space:]]*[^,]*,[[:space:]]*\([^,]*\).*/\1/p' | tr -d '" ' | head -n 1)"
        fi
        case "$operator" in ""|"null"|"NULL"|"(null)"|"(NULL)"|"-") operator="-" ;; esac
        [ -z "$format" ] && format="-"
        printf '{"success":true,"operator":"%s","format":"%s"}\n' "$(json_escape "$operator")" "$(json_escape "$format")"
        ;;

    arp_clients)
        header_json
        append_item() {
            ip="$1"; mac="$2"; dev="$3"; host="$4"
            [ "$ARP_FIRST" -eq 1 ] || ARP_JSON="$ARP_JSON,"
            ARP_FIRST=0
            ARP_JSON="$ARP_JSON{\"ip\":\"$(json_escape "$ip")\",\"mac\":\"$(json_escape "$mac")\",\"dev\":\"$(json_escape "$dev")\",\"host\":\"$(json_escape "$host")\"}"
        }
        lookup_host() {
            req_ip="$1"
            req_mac="$(printf "%s" "$2" | tr 'A-Z' 'a-z')"
            host=""
            for lease in /tmp/dhcp.leases /var/lib/misc/dnsmasq.leases; do
                [ -f "$lease" ] || continue
                host="$(awk -v ip="$req_ip" -v mac="$req_mac" '
                    BEGIN { host="" }
                    { lmac=tolower($2); if (($3 == ip || lmac == mac) && $4 != "*" && $4 != "") { print $4; exit; } }
                ' "$lease" 2>/dev/null)"
                [ -n "$host" ] && break
            done
            printf "%s" "$host"
        }
        ARP_JSON='{"success":true,"clients":['
        ARP_FIRST=1
        if [ -f /proc/net/arp ]; then
            while read -r ip htype flags mac mask dev; do
                [ "$ip" = "IP" ] && continue
                [ -n "$ip" ] || continue
                [ "$mac" = "00:00:00:00:00:00" ] && continue
                host="$(lookup_host "$ip" "$mac")"
                append_item "$ip" "$(printf "%s" "$mac" | tr 'A-Z' 'a-z')" "$dev" "$host"
            done < /proc/net/arp
        fi
        ARP_JSON="$ARP_JSON]}"
        printf "%s\n" "$ARP_JSON"
        ;;

    telnet)
        if [ "$REQUEST_METHOD" = "POST" ]; then
            action="$(printf "%s" "$BODY" | tr -d '\r\n\t ')"
            case "$action" in
                enable)
                    header_text
                    if ! set_telnet_startup_flag "1"; then
                        printf "FAILED_WRITE_FLAG\n"
                    elif telnet_start_now; then
                        reload_modweb_daemon telnet_reload
                        printf "OK ENABLED\n"
                    else
                        printf "FAILED_START\n"
                    fi
                    ;;
                disable)
                    header_text
                    if ! set_telnet_startup_flag "0"; then
                        printf "FAILED_WRITE_FLAG\n"
                    elif telnet_stop_now; then
                        reload_modweb_daemon telnet_reload
                        printf "OK DISABLED\n"
                    else
                        printf "FAILED\n"
                    fi
                    ;;
                startup_enable)
                    header_text
                    if ! set_telnet_startup_flag "1"; then
                        printf "FAILED_WRITE_FLAG\n"
                    else
                        reload_modweb_daemon telnet_reload
                        printf "OK STARTUP_ENABLED\n"
                    fi
                    ;;
                startup_disable)
                    header_text
                    if ! set_telnet_startup_flag "0"; then
                        printf "FAILED_WRITE_FLAG\n"
                    else
                        reload_modweb_daemon telnet_reload
                        printf "OK STARTUP_DISABLED\n"
                    fi
                    ;;
                startup_status)
                    header_text
                    if [ "$(get_telnet_startup_flag)" = "1" ]; then
                        printf "1\n"
                    else
                        printf "0\n"
                    fi
                    ;;
                status_json)
                    header_json
                    telnet_print_json_state
                    ;;
                *)
                    header_text
                    printf "INVALID_ACTION\n"
                    ;;
            esac
        else
            detail="$(get_param detail "$ACTION_QUERY")"
            case "$detail" in
                1|true|yes|on)
                    header_json
                    telnet_print_json_state
                    ;;
                *)
                    header_text
                    if is_telnet_enabled; then
                        printf "1\n"
                    else
                        printf "0\n"
                    fi
                    ;;
            esac
        fi
        ;;

    ttl)
        if [ "$REQUEST_METHOD" = "POST" ]; then
            header_text
            payload="$(printf "%s" "$BODY" | tr -d '\r\n\t ')"
            case "$payload" in
                disable_startup)
                    if ! clear_ttl_startup_flag; then
                        printf "FAILED_WRITE_FLAG\n"
                    else
                        clear_ttl_rules
                        reload_modweb_daemon ttl_reload
                        printf "OK STARTUP_DISABLED\n"
                    fi
                    ;;
                startup_status)
                    startup_ttl="$(get_ttl_startup_flag)"
                    if is_valid_ttl "$startup_ttl"; then
                        printf "%s\n" "$startup_ttl"
                    else
                        printf "\n"
                    fi
                    ;;
                *)
                    ttl="$payload"
                    if ! is_valid_ttl "$ttl"; then
                        printf "INVALID_TTL\n"
                        exit 0
                    fi
                    if apply_ttl_now "$ttl"; then
                        if set_ttl_startup_flag "$ttl"; then
                            reload_modweb_daemon ttl_reload
                            printf "OK %s PERSISTENT\n" "$ttl"
                        else
                            printf "OK %s RUNTIME_ONLY\n" "$ttl"
                        fi
                    else
                        printf "FAILED\n"
                    fi
                    ;;
            esac
        else
            detail="$(get_param detail "$ACTION_QUERY")"
            case "$detail" in
                1|true|yes|on)
                    header_json
                    ttl_print_json_state
                    ;;
                *)
                    header_text
                    cur="$(get_ttl | tr -d '\r\n')"
                    [ -z "$cur" ] && cur="-"
                    printf "%s\n" "$cur"
                    ;;
            esac
        fi
        ;;

    imei)
        header_text
        if [ "$REQUEST_METHOD" = "POST" ]; then
            payload="$(printf "%s" "$BODY" | tr -d '\r\n\t ')"
            imei="$(extract_imei "$payload")"
            if [ -z "$imei" ]; then
                printf "INVALID_IMEI\n"
                exit 0
            fi
            result="$(atcmd "AT+SPIMEI=0,\"$imei\"" 2>&1)"
            if echo "$result" | grep -q "OK"; then
                printf "OK %s\n" "$imei"
            else
                printf "FAILED\n"
            fi
        else
            cur="$(get_current_imei | tr -d '\r\n')"
            [ -z "$cur" ] && cur="-"
            printf "%s\n" "$cur"
        fi
        ;;

    atcmd)
        header_json
        cmd="$BODY"
        case "$cmd" in
            cmd=*) cmd="$(urldecode "${cmd#cmd=}")" ;;
        esac
        cmd="$(printf "%s" "$cmd" | tr -d '\r' | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g; s/^ *//; s/ *$//')"
        [ -n "$cmd" ] || { printf '{"success":false,"message":"AT command is empty"}\n'; exit 0; }
        if [ "${#cmd}" -gt 256 ] 2>/dev/null; then
            printf '{"success":false,"message":"AT command is too long"}\n'
            exit 0
        fi
        upper_cmd="$(printf "%s" "$cmd" | tr '[:lower:]' '[:upper:]')"
        case "$upper_cmd" in AT*) ;; *) printf '{"success":false,"message":"AT command must start with AT"}\n'; exit 0;; esac
        ATCMD_BIN="$(command -v atcmd 2>/dev/null)"
        [ -n "$ATCMD_BIN" ] || { printf '{"success":false,"message":"atcmd binary not found"}\n'; exit 0; }
        if command -v timeout >/dev/null 2>&1; then
            output="$(timeout 12 "$ATCMD_BIN" "$cmd" 2>&1)"
            code=$?
        else
            output="$("$ATCMD_BIN" "$cmd" 2>&1)"
            code=$?
        fi
        output="$(printf "%s" "$output" | tr -d '\r')"
        if [ -z "$output" ]; then
            if [ "$code" -eq 0 ] 2>/dev/null; then output="OK"; else output="FAILED (exit=$code)"; fi
        fi
        if [ "$code" -eq 0 ] 2>/dev/null; then ok=true; else ok=false; fi
        printf '{"success":%s,"command":"%s","output":"%s","code":%s}\n' "$ok" "$(json_escape "$cmd")" "$(json_escape "$output")" "$code"
        ;;

    vnstat)
        header_json
        output="$(run_vnstat_cmd "" 2>&1)"
        code=$?
        output="$(printf "%s" "$output" | tr -d '\r')"
        [ -n "$output" ] || output="No output"
        if [ "$code" -eq 0 ] 2>/dev/null; then
            ok=true
            msg=""
        else
            ok=false
            if [ "$code" -eq 127 ] 2>/dev/null; then
                msg="vnstat binary/runtime not found"
            else
                msg="vnstat command failed"
            fi
        fi
        printf '{"success":%s,"iface":"%s","output":"%s","code":%s,"message":"%s"}\n' \
            "$ok" "$VNSTAT_IFACE" "$(json_escape "$output")" "$code" "$(json_escape "$msg")"
        ;;

    vnstat_summary)
        header_json
        # Keep database fresh even on slim setup without vnstatd daemon.
        run_vnstat_cmd "-u" >/dev/null 2>&1 || true

        run_vnstat_mode() {
            mode="$1"
            out="$(run_vnstat_cmd "$mode" 2>&1)"
            code=$?
            out="$(printf "%s" "$out" | tr -d '\r' | sed '/^[[:space:]]*$/d' | tail -n 12)"
            [ -n "$out" ] || out="No data"
            printf "%s" "$out"
            return "$code"
        }

        daily="$(run_vnstat_mode -d)"; daily_code=$?
        weekly="$(run_vnstat_mode -w)"; weekly_code=$?
        monthly="$(run_vnstat_mode -m)"; monthly_code=$?

        ok=true
        if [ "$daily_code" -ne 0 ] || [ "$weekly_code" -ne 0 ] || [ "$monthly_code" -ne 0 ]; then
            ok=false
            if [ "$daily_code" -eq 127 ] || [ "$weekly_code" -eq 127 ] || [ "$monthly_code" -eq 127 ]; then
                msg="vnstat binary/runtime not found"
            else
                msg="one or more vnstat commands failed"
            fi
        else
            msg=""
        fi

        printf '{"success":%s,"iface":"%s","daily":"%s","weekly":"%s","monthly":"%s","daily_code":%s,"weekly_code":%s,"monthly_code":%s,"message":"%s"}\n' \
            "$ok" "$VNSTAT_IFACE" "$(json_escape "$daily")" "$(json_escape "$weekly")" "$(json_escape "$monthly")" \
            "$daily_code" "$weekly_code" "$monthly_code" "$(json_escape "$msg")"
        ;;

    vnstat_reset)
        header_json
        if [ "$REQUEST_METHOD" != "POST" ]; then
            printf '{"success":false,"iface":"%s","code":405,"message":"Method not allowed"}\n' "$VNSTAT_IFACE"
            exit 0
        fi

        reset_vnstat_db
        code=$?
        if [ "$code" -eq 0 ] 2>/dev/null; then
            ok=true
            msg="vnStat database reset completed"
        else
            ok=false
            if [ "$code" -eq 127 ] 2>/dev/null; then
                msg="init-db.sh not found at /home/vnstat/init-db.sh"
            else
                msg="failed to reset vnStat database"
            fi
        fi

        printf '{"success":%s,"iface":"%s","code":%s,"message":"%s"}\n' \
            "$ok" "$VNSTAT_IFACE" "$code" "$(json_escape "$msg")"
        ;;

    smslist)
        header_json
        atcmd "AT+CMEE=2" >/dev/null 2>&1
        cpms="$(atcmd "AT+CPMS=\"SM\",\"SM\",\"SM\"" 2>/dev/null | tr -d '\r')"
        SMS_MAX_IDX="$(printf "%s\n" "$cpms" | sed -n 's/.*+CPMS: [0-9]\+,\([0-9]\+\),.*/\1/p' | head -n 1)"
        [ -z "$SMS_MAX_IDX" ] && SMS_MAX_IDX=30

        SMS_JSON='{"success":true,"datas":['
        SMS_FIRST=1
        SMS_FOUND=0

        atcmd "AT+CMGF=0" >/dev/null 2>&1
        sms_collect "pdu"

        if [ "$SMS_FOUND" -eq 0 ]; then
            atcmd "AT+CMGF=1" >/dev/null 2>&1
            atcmd "AT+CSDH=1" >/dev/null 2>&1
            atcmd "AT+CSCS=\"IRA\"" >/dev/null 2>&1
            sms_collect "text"
        fi

        SMS_JSON="$SMS_JSON],\"message\":\"OK\"}"
        printf "%s\n" "$SMS_JSON"
        ;;

    smsops)
        header_json
        q="$QUERY_STRING"
        [ -n "$BODY" ] && q="$BODY"
        op="$(get_param op "$q")"
        indexes="$(get_param indexes "$q")"

        atcmd "AT+CMEE=2" >/dev/null 2>&1
        atcmd "AT+CMGF=0" >/dev/null 2>&1
        atcmd "AT+CPMS=\"SM\",\"SM\",\"SM\"" >/dev/null 2>&1

        ok=1
        case "$op" in
            clear)
                atcmd "AT+CMGD=1,4" >/dev/null 2>&1 || ok=0
                ;;
            delete_multi|delete)
                oldifs="$IFS"
                IFS=','
                for idx in $indexes; do
                    idx="$(printf "%s" "$idx" | sed 's/[^0-9]//g')"
                    [ -z "$idx" ] && continue
                    atcmd "AT+CMGD=$idx" >/dev/null 2>&1 || ok=0
                done
                IFS="$oldifs"
                ;;
            *)
                ok=0
                ;;
        esac

        if [ "$ok" -eq 1 ]; then
            printf '{"success":true,"message":"OK"}\n'
        else
            printf '{"success":false,"message":"SMS operation failed"}\n'
        fi
        ;;

    *)
        send_json_error "Unknown action"
        ;;
esac
