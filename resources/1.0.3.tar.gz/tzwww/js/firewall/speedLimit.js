$(document).ready(function () {
    var $mask = $('#mask');
    var titleArr = [DOC.table.enableRule, DOC.table.priority, DOC.net.mac, DOC.net.maxSpeed,
        DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule
    ];
    var vm = new Vue({
        el: "#child_container",
        data: {
            title: titleArr,
            value: [],
            addAclFiltering: DOC.title.addAclFiltering,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            clearAllRules: DOC.btn.clearAllRules,
            addSpeedLimit: DOC.title.addSpeedLimit,
            close: DOC.btn.close,
            colon: DOC.colon,
            ip: DOC.net.mac,
            example: DOC.lbl.example,
            maxSpeed: DOC.net.maxSpeed,
            kBPerSeconds: "Mbps",
            remark: DOC.lbl.remark,
            save: DOC.btn.save,
            edit_box: false,
            rowFlag: "",
            macaddr: '',
            speed: '',
            comment: '',
            isApply: false,
            isClear: false,
            showTip: false
        },
        methods: {
            toMbps: function (kbps) {
                var n = parseFloat(kbps);
                if (isNaN(n)) return "";
                var mbps = n / 100;
                return (Math.round(mbps * 100) / 100).toString();
            },
            toKbps: function (mbps) {
                var n = parseFloat(mbps);
                if (isNaN(n)) return NaN;
                return Math.round(n * 100);
            },
            formatMbps: function (kbps) {
                var t = this.toMbps(kbps);
                return t === "" ? "-" : (t + " Mbps");
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SPEED_LIMIT,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            for (var i = 0; i < data.datas.length; i++) {
                                data.datas[i].speed = vm.toMbps(data.datas[i].maxSpeed);
                            }
                            vm.value = data.datas;
                            vm.fillMacFromDhcp();
                        }
                    }
                });
            },
            fillMacFromDhcp: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (res) {
                        var mapByIp = {};
                        var list = res.dhcp_list_info || [];
                        for (var i = 0; i < list.length; i++) {
                            if (list[i].ip && list[i].mac) {
                                mapByIp[list[i].ip] = list[i].mac.toUpperCase();
                            }
                        }
                        for (var j = 0; j < vm.value.length; j++) {
                            var row = vm.value[j];
                            if (!row.mac && row.ip && mapByIp[row.ip]) {
                                vm.$set(row, "mac", mapByIp[row.ip]);
                            }
                        }
                    }
                });
            },
            editAcl: function (index) {
                this.edit_box = true;
                $mask.show();
                this.macaddr = this.value[index].mac || "";
                this.speed = this.toMbps(this.value[index].maxSpeed);
                this.comment = this.value[index].remark;
                this.rowFlag = index;
            },
            delAcl: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function(){
                        vm.showTip = true;
                    });
                })
            },
            btnCloseRule: function () {
                this.edit_box = false;
                $mask.hide();
                this.rowFlag = "";
            },
            addRuleClick: function () {
                this.edit_box = true;
                $mask.show();
                this.macaddr = '';
                this.speed = '';
                this.comment = '';
            },
            btnSave: function () {
                var speedCheck = /^([0-9]+)(\.[0-9]+)?$/;
                if (this.macaddr == "") {
                    AlertUtil.alertMsg(CHECK.required.mac);
                    return false;
                }
                if (!CheckUtil.checkMac(this.macaddr)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                if (this.speed == "") {
                    AlertUtil.alertMsg(CHECK.required.maxSpeed);
                    return false;
                }
                if (!(speedCheck.test(String(this.speed)))) {
                    AlertUtil.alertMsg(CHECK.format.maxSpeed);
                    return false;
                }
                var speedKbps = this.toKbps(this.speed);
                if (isNaN(speedKbps) || speedKbps <= 0) {
                    AlertUtil.alertMsg(CHECK.format.maxSpeed);
                    return false;
                }
                var macNorm = this.macaddr.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                var temp = {
                    ip: "",
                    mac: macNorm,
                    maxSpeed: String(speedKbps),
                    remark: this.comment,
                    ippro: "IPV4"

                };
                for(var i=0;i<this.value.length;i++){
                    if((this.value[i].mac || "").toUpperCase() == temp.mac){
                        if(this.rowFlag === i && (this.value[i].remark != temp.remark || this.value[i].maxSpeed != temp.maxSpeed) ){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.rowFlag === "number"){
                    temp.enableRule = this.value[this.rowFlag].enableRule;
                    this.value[this.rowFlag] = temp;
                } else {
                    temp.enableRule = true;
                    this.value.push(temp);
                }
                this.showTip = false;
                this.$nextTick(function(){
                    this.showTip = true;
                });
                this.btnCloseRule();
            },
            applyRulesClick: function () {
                this.isApply = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (res) {
                        var mapByMac = {};
                        var list = res.dhcp_list_info || [];
                        for (var i = 0; i < list.length; i++) {
                            if (list[i].mac && list[i].ip) {
                                mapByMac[list[i].mac.toUpperCase()] = list[i].ip;
                            }
                        }
                        var payload = [];
                        for (var j = 0; j < vm.value.length; j++) {
                            var row = vm.value[j];
                            var mac = (row.mac || "").toUpperCase();
                            var ip = mapByMac[mac] || row.ip || "";
                            if (!ip) {
                                vm.isApply = false;
                                fyAlertMsgFail("IP aktif tidak ditemukan untuk MAC: " + mac);
                                return;
                            }
                            payload.push({
                                enableRule: !!row.enableRule,
                                ippro: "IPV4",
                                ip: ip,
                                maxSpeed: row.maxSpeed,
                                remark: row.remark || "",
                                mac: mac
                            });
                        }
                        Page.postJSON({
                            json: {
                                cmd: RequestCmd.SPEED_LIMIT,
                                method: JSONMethod.POST,
                                success: true,
                                datas: payload
                            },
                            success: function (data) {
                                vm.isApply = false;
                                vm.showTip = false;
                                if (data.success == true) {
                                    for (var k = 0; k < vm.value.length; k++) {
                                        vm.value[k].ip = payload[k].ip;
                                    }
                                    Page.applyFilter();
                                } else {
                                    fyAlertMsgFail();
                                }
                            },
                            error: function () {
                                vm.isApply = false;
                                fyAlertMsgFail();
                            }
                        });
                    },
                    error: function () {
                        vm.isApply = false;
                        fyAlertMsgFail("Gagal ambil DHCP list");
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    vm.isClear = true;
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.SPEED_LIMIT,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.isClear = false;
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            }
        },
        mounted:function(){
            this.getData();
        }
    });
    
});
