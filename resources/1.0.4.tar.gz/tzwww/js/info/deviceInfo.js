var loading = "-"
var runStatusName = [DOC.lbl.runtime, DOC.lbl.loadAvg, DOC.lbl.memoryTotal, DOC.lbl.memoryFree, DOC.lbl.memoryCache];
// var runStatusName = [DOC.lbl.runtime, DOC.lbl.loadAvg, DOC.lbl.memoryTotal, DOC.lbl.memoryFree, DOC.lbl.memoryCache,"AP CPU0 "+DOC.lbl.temperature,"AP CPU1 "+DOC.lbl.temperature,"Sensor "+DOC.lbl.temperature,
// "NRCP "+DOC.lbl.temperature,"AP CPU0(2) "+DOC.lbl.temperature,"AP CPU1(2) "+DOC.lbl.temperature,"AP CPU TOP "+DOC.lbl.temperature];
var deviceName = [DOC.device.model, DOC.device.softwarVersion, DOC.device.hardwareVersion, DOC.device.configVersion, DOC.device.buildTime, DOC.device.gitBranch, DOC.device.gitCommit, "SN", DOC.device.realVersion, DOC.info.simStatus,DOC.device.idu_git_branch, DOC.device.idu_git_sha, "Mod Version"];
var lteInfoName = [DOC.device.modemVersion, DOC.device.modsoftversion, DOC.device.modhardwareversion, "IMEI", "IMSI", DOC.lbl.plmn, "ICCID", "SN"];
var runStatusValues = new Array(12);
var deviceValues = new Array(17);
deviceValues[12] = "1.0.4 [24-04-2026]";
var lteInfoValues = new Array(8);
function normalizeOpText(val) {
    if (val === undefined || val === null) return "";
    var s = $.trim(String(val));
    if (!s || s === "-" || /null/i.test(s)) return "";
    return s;
}
var vm_deviceInfo = new Vue({
    el: "#deviceInfo",
    data: {
        runStatus: DOC.title.run,
        device: DOC.title.device,
        lteInfo: DOC.title.lte,
        runStatusValues: runStatusValues,
        deviceValues: deviceValues,
        lteInfoValues: lteInfoValues,
        runStatusName: runStatusName,
        deviceName: deviceName,
        lteInfoName: lteInfoName,
        lteInfoNameTable: true
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.DEVICE_INFO
                },
                success: function (data) {
                    vm_deviceInfo.$set(runStatusValues, 0, ConvertUtil.parseUptime2(data.uptime) || loading);
                    vm_deviceInfo.$set(runStatusValues, 1, data.cpuload || loading);
                    var memory = data.memory;

                    var memoryArr = memory.split(",");
                    vm_deviceInfo.$set(runStatusValues, 2, memoryArr[0] || loading);
                    vm_deviceInfo.$set(runStatusValues, 3, memoryArr[1] || loading);
                    vm_deviceInfo.$set(runStatusValues, 4, memoryArr[2] || loading);
                    if(!!data.temp_list && data.temp_list[0])
                    {
                        if(Page.level == "1")
                    {
                        vm_deviceInfo.$set(runStatusValues, 8, parseInt(data.temp_list[0]["nrcp-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 7, parseInt(data.temp_list[0]["soc-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 9, parseInt(data.temp_list[0]["ank0-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 10,parseInt(data.temp_list[0]["ank1-thmzone"])/1000+"℃" || loading);
                        vm_deviceInfo.$set(runStatusValues, 11,parseInt(data.temp_list[0]["cluster0-thmzone"])/1000+"℃" || loading);

                    }
                       vm_deviceInfo.$set(runStatusValues, 5, parseInt(data.temp_list[0]["apcpu0-thmzone"])/1000+"℃" || loading);
                       vm_deviceInfo.$set(runStatusValues, 6, parseInt(data.temp_list[0]["apcpu1-thmzone"])/1000+"℃" || loading);

                   }else
                   {
                      if(Page.level == "1")
                    {
                        vm_deviceInfo.$set(runStatusValues, 8,loading);
                        vm_deviceInfo.$set(runStatusValues, 7,loading);
                        vm_deviceInfo.$set(runStatusValues, 9,loading);
                        vm_deviceInfo.$set(runStatusValues, 10,loading);
                        vm_deviceInfo.$set(runStatusValues, 11,loading);

                    }
                       vm_deviceInfo.$set(runStatusValues, 5,loading);
                       vm_deviceInfo.$set(runStatusValues, 6,loading);
                   }
                    
                    vm_deviceInfo.$set(deviceValues, 0, data.board_type || loading);
                    vm_deviceInfo.$set(deviceValues, 1, data.fake_version || loading);
                    vm_deviceInfo.$set(deviceValues, 2, data.hwversion || loading);
                    vm_deviceInfo.$set(deviceValues, 7, data.device_sn || loading);

                    if (Page.level != "3") {
                        vm_deviceInfo.$set(deviceValues, 3, data.config_version || loading);
                    }
                    if (Page.level == "1") {    
                        vm_deviceInfo.$set(deviceValues, 4, data.build_date || loading);
                        vm_deviceInfo.$set(deviceValues, 5, data.git_branch || loading);
                        vm_deviceInfo.$set(deviceValues, 6, data.git_sha || loading);
                        vm_deviceInfo.$set(deviceValues, 8, data.real_fwversion || loading);
                        vm_deviceInfo.$set(deviceValues, 9, data.sim_slot || loading);
                        vm_deviceInfo.$set(deviceValues, 10, data.idu_git_branch || loading);
                        vm_deviceInfo.$set(deviceValues, 11, data.idu_git_sha || loading);
                        // vm_deviceInfo.$set(deviceValues, 13, data.idu_firmware_version || loading);
                        // vm_deviceInfo.$set(deviceValues, 14, data.idu_config_version || loading);
                        // vm_deviceInfo.$set(deviceValues, 12, data.idu_dev_type || loading);
                        // vm_deviceInfo.$set(deviceValues, 15, data.idu_build_time || loading);
                        // vm_deviceInfo.$set(deviceValues, 16, data.verify_status || loading);
                    }
                    

                    vm_deviceInfo.$set(lteInfoValues, 0, data.module_type || loading);
                    vm_deviceInfo.$set(lteInfoValues, 1, data.module_softver || loading);
                    vm_deviceInfo.$set(lteInfoValues, 2, data.module_hardver || loading);
                    vm_deviceInfo.$set(lteInfoValues, 3, data.module_imei || loading);
                    vm_deviceInfo.$set(lteInfoValues, 4, data.IMSI || loading);
                    vm_deviceInfo.$set(lteInfoValues, 5, loading);
                    vm_deviceInfo.$set(lteInfoValues, 6, data.ICCID || loading);
                    vm_deviceInfo.$set(lteInfoValues, 7, data.module_sn || loading);
                    vm_deviceInfo.$set(deviceValues, 12, "1.0.4 [24-04-2026]");

                    // Operator from AT directly; force COPS format to 3,0 each read.
                    $.ajax({
                        type: "GET",
                        url: "/cgi-bin/extra.cgi?action=operator",
                        cache: false,
                        dataType: "json",
                        success: function (opData) {
                            var op = normalizeOpText(opData ? opData.operator : "");
                            vm_deviceInfo.$set(lteInfoValues, 5, op || loading);
                        },
                        error: function () {
                            vm_deviceInfo.$set(lteInfoValues, 5, loading);
                        }
                    });

                }
            })
        },
        runStatusNameShow: function (index) {
            if (Page.level != "1" && (index == "7" || index == "8" || index == "9" || index == "10" || index == "11")) {
                return false;
            } else {
                return true;
            }
        },
        deviceArrShow: function (index) {
            if (Page.level != "1" && (index == "4" || index == "5" || index == "6" || index == "8" || index == "9" || index == "10" || index == "11" || index == "13" || index == "14" || index == "15" || index == "16")
                ||  ((index == "3")&& Page.level == "3")) {
                return false;
            } else {
                return true;
            }
        },
        lteInfoNameShow: function (index) {
            if (Page.level == "1") {
                return true;
            } else {
                if (index == "3" || index == "4" || index == "5" || index == "6") {
                    return true;
                } else {
                    return false;
                }
            }
        }
    },
    mounted: function () {
        this.getData();
        this.lteInfoNameTable = Page.level;
        Page.timer = setInterval(function () {
            vm_deviceInfo.getData();
        }, 3000);
    }
});
