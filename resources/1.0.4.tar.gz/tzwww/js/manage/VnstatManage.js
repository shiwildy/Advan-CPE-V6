$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "vnStat",
            iface: "seth_lte0",
            lastUpdate: "-",
            isLoading: false,
            errorMsg: "",
            timerId: null,
            dailyRows: [],
            weeklyRows: [],
            monthlyRows: []
        },
        methods: {
            normalizeLines: function (text) {
                var lines = String(text || "").split(/\n+/);
                var out = [];
                for (var i = 0; i < lines.length; i++) {
                    var line = $.trim(lines[i]);
                    if (!line) {
                        continue;
                    }
                    if (/^[\-\+=| ]+$/.test(line)) {
                        continue;
                    }
                    out.push(line);
                }
                return out;
            },
            parseTableRows: function (text) {
                var lines = this.normalizeLines(text);
                var rows = [];
                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    if (line.indexOf("|") === -1) {
                        continue;
                    }
                    var parts = line.split("|");
                    if (parts.length < 4) {
                        continue;
                    }
                    var p0 = $.trim(parts[0]);
                    var p1 = $.trim(parts[1]);
                    var p2 = $.trim(parts[2]);
                    var p3 = $.trim(parts.slice(3).join("|"));
                    if (!p0) {
                        continue;
                    }
                    if (/^day$/i.test(p0) || /^week$/i.test(p0) || /^month$/i.test(p0)) {
                        continue;
                    }
                    if (/rx/i.test(p0) && /tx/i.test(p1)) {
                        continue;
                    }
                    rows.push({
                        period: p0,
                        tx: p1 || "-",
                        total: p2 || "-",
                        rate: p3 || "-"
                    });
                }

                if (rows.length === 0) {
                    var fallback = this.normalizeLines(text);
                    if (fallback.length === 0) {
                        fallback = ["No data"];
                    }
                    for (var j = 0; j < fallback.length; j++) {
                        rows.push({
                            period: fallback[j],
                            tx: "-",
                            total: "-",
                            rate: "-"
                        });
                    }
                }
                return rows;
            },
            refreshData: function () {
                if (this.isLoading) {
                    return;
                }
                this.isLoading = true;
                $.ajax({
                    type: "GET",
                    url: "/cgi-bin/extra.cgi?action=vnstat_summary",
                    cache: false,
                    dataType: "json",
                    timeout: 12000,
                    success: function (resp) {
                        vm.isLoading = false;
                        vm.lastUpdate = new Date().toLocaleString();
                        vm.iface = (resp && resp.iface) ? resp.iface : "seth_lte0";
                        vm.dailyRows = vm.parseTableRows(resp ? resp.daily : "");
                        vm.weeklyRows = vm.parseTableRows(resp ? resp.weekly : "");
                        vm.monthlyRows = vm.parseTableRows(resp ? resp.monthly : "");
                        if (resp && resp.success) {
                            vm.errorMsg = "";
                        } else {
                            vm.errorMsg = (resp && resp.message) ? ("vnStat error: " + resp.message) : "vnStat data unavailable";
                        }
                    },
                    error: function () {
                        vm.isLoading = false;
                        vm.lastUpdate = new Date().toLocaleString();
                        vm.errorMsg = "vnStat request failed";
                        vm.dailyRows = vm.parseTableRows("No data");
                        vm.weeklyRows = vm.parseTableRows("No data");
                        vm.monthlyRows = vm.parseTableRows("No data");
                    }
                });
            }
        },
        mounted: function () {
            this.refreshData();
            this.timerId = setInterval(function () {
                vm.refreshData();
            }, 30000);
        }
    });
});
