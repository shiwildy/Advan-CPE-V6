$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);
    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: sysathtml.head.title,
            helper: sysathtml.form1.helper,
            input: sysathtml.form1.input,
            execute: sysathtml.form1.execute,
            clear: sysathtml.form1.clear,
            result:sysathtml.form1.response,
            isClick: false,
            atCmd: '',
            atResult: '',
        },
        methods: {
            btnClear: function () {
                this.atResult = '';
            },
            atStart: function () {
                this.atResult = '';
                fyAlertMsgLoading();
                this.isClick = true;
                var json = {};
                json.atInfo = Base64.encode(this.atCmd);
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.SEND_AT;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        fyAlertDestory();
                        vm.atResult = data.flag;
                        vm.isClick = false;
                    }
                });
            }
        }
    });
});