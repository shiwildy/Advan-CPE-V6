$(document).ready(function () {
    var fm1 = ["form1", "form1Parent", "form1Id"];
    Page.createForm(fm1);

    var vm = new Vue({
        el: "#detail_box",
        data: {
            title: "TTL Change",
            currentTtlText: "Current TTL",
            ttlInputText: "New TTL",
            submitText: "Submit",
            isClick: false,
            currentTtl: "-",
            ttlValue: ""
        },
        methods: {
            parseOutput: function (data) {
                if (typeof data === "string") {
                    return data;
                }
                if (data && typeof data === "object") {
                    if (typeof data.flag !== "undefined") {
                        return String(data.flag);
                    }
                    if (typeof data.message !== "undefined") {
                        return String(data.message);
                    }
                    return JSON.stringify(data);
                }
                return "";
            },
            runCommand: function (command, callback) {
                var cmd = (command || "").trim();
                if (cmd === "") {
                    return;
                }

                this.isClick = true;
                fyAlertMsgLoading();

                Page.postJSON({
                    json: {
                        cmd: RequestCmd.EXE_CMD,
                        method: JSONMethod.POST,
                        subcmd: 0,
                        innercmd: cmd,
                        command: cmd,
                        cmdStr: cmd
                    },
                    success: function (data) {
                        fyAlertDestory();
                        vm.isClick = false;
                        if (typeof callback === "function") {
                            callback(vm.parseOutput(data), null);
                        }
                    },
                    fail: function (data) {
                        fyAlertDestory();
                        vm.isClick = false;
                        if (typeof callback === "function") {
                            callback("", vm.parseOutput(data) || "Failed");
                        }
                    }
                });
            },
            parseCurrentTtl: function (text) {
                var matchList = [];
                var regex = /--ttl-set\s+([0-9]+)/g;
                var match = null;
                while ((match = regex.exec(text)) !== null) {
                    matchList.push(match[1]);
                }
                if (matchList.length === 0) {
                    return "-";
                }
                return matchList[matchList.length - 1];
            },
            refreshCurrentTtl: function () {
                this.runCommand("iptables -t mangle -S POSTROUTING", function (output, error) {
                    if (error) {
                        vm.currentTtl = "-";
                        return;
                    }
                    vm.currentTtl = vm.parseCurrentTtl(output);
                });
            },
            submitTtl: function () {
                var ttl = parseInt((this.ttlValue || "").toString().trim(), 10);
                if (isNaN(ttl) || ttl < 1 || ttl > 255) {
                    AlertUtil.alertMsg("TTL must be 1-255");
                    return;
                }

                var cmd = "iptables -t mangle -A POSTROUTING -j TTL --ttl-set " + ttl;
                this.runCommand(cmd, function (output, error) {
                    if (error) {
                        AlertUtil.alertMsg(error);
                        return;
                    }
                    vm.refreshCurrentTtl();
                });
            }
        },
        mounted: function () {
            this.refreshCurrentTtl();
        }
    });
});
