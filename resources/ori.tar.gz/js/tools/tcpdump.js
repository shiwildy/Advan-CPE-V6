$(document).ready(function () {
    var SUB_CMD = 1;
    var fm = ["childForm", "child_container", "child_template"];
    Page.createForm(fm);
    var currentId = Page.currentId;
    var isFirst = true;
    var vm_tcpdump = new Vue({
        el: "#child_container",
        data: {
            ifName: DOC.lbl.ifName,
            colon: DOC.colon,
            ifDefault: DOC.lbl.ifDefault,
            start: DOC.btn.start,
            stop: DOC.btn.stop,
            fileSize: DOC.lbl.fileSize,
            txtIfValue: "",
            spanFileSizeText: "",
            exportDelegateShow: false,
            exportDelegateText: "",
            exportDelegateUrl: "",
            count: 0,
            hasStop: false,
            btnStartDis: false,
            btnStopDis: true
        },
        methods: {
            btnStartClick: function () {
                vm_tcpdump.btnStartDis = true;
                vm_tcpdump.btnStopDis = false;
                vm_tcpdump.hasStop = false;
                vm_tcpdump.spanFileSizeText = "";
                vm_tcpdump.exportDelegateShow = false;
                vm_tcpdump.sendCmd(false);

                var option = {
                    expireHours: 24,
                    path: "/",
                    domain: location.hostname
                };
                CookieUtil.setCookie("ifName", vm_tcpdump.txtIfValue, option);

                currentId = Page.currentId;
                vm_tcpdump.count = 0;
                setTimeout(vm_tcpdump.loop, 3000);
            },
            btnStopClick: function () {
                Page.currentId++;
                vm_tcpdump.hasStop = true;
                vm_tcpdump.btnStartDis = false;
                vm_tcpdump.btnStopDis = true;
                vm_tcpdump.sendCmd(true);
            },
            sendCmd: function (stopped, hasError) {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_TOOLS,
                        method: JSONMethod.POST,
                        subcmd: SUB_CMD,
                        stopped: stopped ? "1" : "0",
                        "if": vm_tcpdump.txtIfValue
                    },
                    success: function (data) {
                        if (!hasError && stopped) {
                            vm_tcpdump.showLink();
                        }
                    },
                    fail: function (data) {
                        if (data.success) {} else {
                            alert(data.message);
                        }
                    }
                });
            },
            getStatus: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_TOOLS,
                        method: JSONMethod.GET,
                        subcmd: SUB_CMD,
                        "if": vm_tcpdump.txtIfValue
                    },
                    success: function (data) {
                        var items = data.message.split(',');
                        if (items.length < 2) return;
                        var wan_interfaces = items[2];
                        wan_interfaces = wan_interfaces.replace(/\s+/g, ",");

                        var isRunning = (parseInt(items[0], 10) == 1);
                        var fileSize = parseInt(items[1], 10);
                        if (fileSize < 0) {
                            if (isRunning) {
                                vm_tcpdump.spanFileSizeText = PROMPT.status.ifErrorAutoStopCapture;
                                vm_tcpdump.sendCmd(true, true);
                            }
                        } else {
                            if (fileSize < 1024) {
                                vm_tcpdump.spanFileSizeText = fileSize + " B" + " ( all network interfaces:" + wan_interfaces + " )"
                            } else {
                                vm_tcpdump.spanFileSizeText = Math.floor(fileSize / 1024) + " KB" + " ( all network interfaces:" + wan_interfaces + " )";
                            }
                        }

                        if (isFirst) {
                            isFirst = false;
                            if (isRunning) {
                                vm_tcpdump.loop();
                            } else {
                                if (fileSize > 0) {
                                    vm_tcpdump.showLink();
                                }
                            }
                            return;
                        }
                    }
                });
            },
            showLink: function () {
                var url = '/tcpdump_log.tar';
                vm_tcpdump.exportDelegateText = DOC.link.clickMeCapture;
                vm_tcpdump.exportDelegateUrl = url;
                vm_tcpdump.exportDelegateShow = true;
            },
            loop: function () {
                if (currentId != Page.currentId || vm_tcpdump.hasStop) return;

                vm_tcpdump.getStatus();

                vm_tcpdump.count++;
                setTimeout(vm_tcpdump.loop, 3000);
            }
        }

    })
    vm_tcpdump.txtIfValue = CookieUtil.getCookie("ifName")!="undefined"&&CookieUtil.getCookie("ifName")!="default"?CookieUtil.getCookie("ifName"):"";
    vm_tcpdump.getStatus();
    Page.postJSON({
        json: {
            cmd: RequestCmd.NETWORK_TOOLS,
            method: JSONMethod.POST,
            subcmd: SUB_CMD,
            stopped: "1",
            "if": vm_tcpdump.txtIfValue
        },
        success: function (data) {}
    });
});