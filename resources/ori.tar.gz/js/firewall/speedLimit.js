$(document).ready(function () {
    var $mask = $('#mask');
    var titleArr = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, DOC.net.targeAddr, DOC.net.maxSpeed,
        DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule
    ];
    var vm = new Vue({
        el: "#child_container",
        data: {
            title: titleArr,
            value: [],
            addAclFiltering: DOC.title.addAclFiltering,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            clearAllRules: DOC.btn.clearAllRules,
            addSpeedLimit: DOC.title.addSpeedLimit,
            close: DOC.btn.close,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            ip: DOC.net.ip,
            example: DOC.lbl.example,
            maxSpeed: DOC.net.maxSpeed,
            kBPerSeconds: DOC.unit.kBPerSeconds,
            remark: DOC.lbl.remark,
            save: DOC.btn.save,
            edit_box: false,
            rowFlag: "",
            ipaddr: '',
            speed: '',
            comment: '',
            isApply: false,
            isClear: false,
            ipproValue: "IPV4",
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SPEED_LIMIT,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            for (var i = 0; i < data.datas.length; i++) {
                                data.datas[i].speed = parseInt(data.datas[i].maxSpeed);
                            }
                            vm.value = data.datas;
                        }
                    }
                });
            },
            editAcl: function (index) {
                this.edit_box = true;
                $mask.show();
                this.ipaddr = this.value[index].ip;
                this.speed = this.value[index].maxSpeed;
                this.comment = this.value[index].remark;
                this.ipproValue = this.value[index].ippro;
                this.rowFlag = index;
            },
            delAcl: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function(){
                        vm.showTip = true;
                    });
                })
            },
            btnCloseRule: function () {
                this.edit_box = false;
                $mask.hide();
                this.rowFlag = "";
            },
            addRuleClick: function () {
                this.edit_box = true;
                $mask.show();
                this.ipaddr = '';
                this.speed = '';
                this.comment = '';
                this.ipproValue = "IPV4";
            },
            btnSave: function () {
                var portCheck = /^[0-9]+$/;
                if (this.ipaddr == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.ipaddr,this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (this.speed == "") {
                    AlertUtil.alertMsg(CHECK.required.maxSpeed);
                    return false;
                }
                if (!(portCheck.test(this.speed))) {
                    AlertUtil.alertMsg(CHECK.format.maxSpeed);
                    return false;
                }
                var temp = {
                    ip: this.ipaddr,
                    maxSpeed: this.speed,
                    remark: this.comment,
                    ippro: this.ipproValue

                };
                for(var i=0;i<this.value.length;i++){
                    var flag = 0;
                    if(this.value[i].ippro == temp.ippro){
                        flag+=1;
                    }
                    if(this.value[i].ip == temp.ip){
                        flag+=1;
                    }
                    if(flag == 2){
                        if(this.rowFlag === i && (this.value[i].remark != temp.remark || this.value[i].maxSpeed != temp.maxSpeed) ){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.rowFlag === "number"){
                    temp.enableRule = this.value[this.rowFlag].enableRule;
                    this.value[this.rowFlag] = temp;
                } else {
                    temp.enableRule = true;
                    this.value.push(temp);
                }
                this.showTip = false;
                this.$nextTick(function(){
                    this.showTip = true;
                });
                this.btnCloseRule();
            },
            applyRulesClick: function () {
                this.isApply = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SPEED_LIMIT,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isApply = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    vm.isClear = true;
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.SPEED_LIMIT,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.isClear = false;
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            }
        },
        mounted:function(){
            this.getData();
        }
    });
    
});