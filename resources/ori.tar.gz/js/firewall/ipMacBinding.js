$(document).ready(function () {
    Page.render();
    var title = [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, DOC.net.targeAddr, wifiInfohtml.helper.title5, DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule];
    var htmlData = []
    var vm = new Vue({
        el: "#portFilter",
        data: {
            title: title,
            value: [],
            edit: DOC.table.edit,
            del: dialconfightml.lnsTable.del,
            ipv46: DOC.net.ipv46,
            colon: DOC.colon,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            filterMode: DOC.table.filterMode,
            accept: DOC.status.accept,
            reject: DOC.status.reject,
            example: DOC.lbl.example,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            save: DOC.btn.save,
            close: DOC.btn.close,
            addIpMacBinding: DOC.title.addIpMacBinding,
            urlKeyword: DOC.lbl.urlKeyword,
            advancedOptions: DOC.lbl.advancedOptions,
            mac: wifiInfohtml.helper.title5,
            ipAddress: DOC.net.targeAddr,
            commentValue: "",
            flag: "",
            isWork: false,
            lanDiv: false,
            macValue: "",
            ipAddressValue: "",
            ipproValue: "IPV4",
            isApply: false,
            showTip: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_MAC_BINDING,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
            },
            applyRulesClick: function () {
                this.isApply = true;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_MAC_BINDING,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.isApply = false;
                        vm.showTip = false;
                        if (data.success == true) {
                            fyAlertDestory();
                            Page.applyFilter(1);
                            setTimeout(() => {
                              fyConfirmMsg(PROMPT.tips.rebootMessage, function () {
                                SysUtil.reboot2();
                              })
                            }, 500);
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.IP_MAC_BINDING,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                fyAlertDestory();
                                Page.applyFilter(1);
                                setTimeout(() => {
                                  fyConfirmMsg(PROMPT.tips.rebootMessage, function () {
                                    SysUtil.reboot2();
                                  })
                                }, 500);
                                
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })

            },
            btnSave: function () {
                if (!CheckUtil.checkIp(this.ipAddressValue,this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (!CheckUtil.checkMac(this.macValue)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                var arr = {
                    remark: this.commentValue,
                    ip: this.ipAddressValue,
                    ippro: this.ipproValue,
                    mac: this.macValue.match(/[0-9a-f]{2}/ig).join(":").toUpperCase()
                }
                for(var i = 0;i<this.value.length;i++){
                    var flag = 0;
                    if(this.value[i].ip == this.ipAddressValue){
                        flag += 1;
                    }
                    if(this.value[i].ippro == this.ipproValue){
                        flag += 1;
                    }
                    if(this.value[i].mac == arr.mac){
                        flag += 1;
                    }
                    if(flag == 3){
                        if(this.flag === i && this.value[i].remark != arr.remark){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if(typeof this.flag === "number"){
                    arr.enableRule = this.value[this.flag].enableRule;
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true;
                    this.value.push(arr);
                }
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
                this.btnCloseClick();
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.macValue = "";
                this.commentValue = "";
                this.ipAddressValue = "";
            },
            editClick: function (event, index) {
                this.flag = index;
                this.commentValue = event.remark;
                this.macValue = event.mac;
                this.ipAddressValue = event.ip;
                this.ipproValue = event.ippro;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                })
            }
        },
        mounted: function(){
            this.getData();
        }
    })
    var $box = $('#edit_box'),
        $mask = $('#mask');
});