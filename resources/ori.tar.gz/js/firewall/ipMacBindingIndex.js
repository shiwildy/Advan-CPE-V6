$(document).ready(function () {
    
    var tabs = TAB.advance;
    var id ="FW_IP_MAC_BINDING";
    var items = [];

    items.push({ title: MENU.fw.ipMacBinding, url: 'html/firewall/ipMacBinding.html' })

    secondMenuClick(items,id);
});
