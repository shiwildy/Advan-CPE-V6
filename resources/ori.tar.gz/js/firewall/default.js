$(document).ready(function () {
    Page.render();
    var vm = new Vue({
        el: "#default_box",
        data: {
            ipv6FilterRule: DOC.lbl.ipv6FilterRule,
            acceptAllIPv4: "",
            disabled: false,
            isWork: false,
            valueMac: [],
            valuePort: [],
            valueIp: [],
            currentFlag: ''
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DEFAULT_FILTER,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if(!!data.datas){
                            vm.acceptAllIPv4 = data.datas[0].acceptAll ? "1" : "0";
                        } else {
                            vm.acceptAllIPv4 = "1";
                        }
                        vm.currentFlag = vm.acceptAllIPv4;
                    }
                });
            },
            btnSave: function () {
                if(vm.currentFlag === vm.acceptAllIPv4){
                    AlertUtil.alertMsg(CHECK.format.defaultDate);
                    return ;
                }
                this.disabled = true;
                fyAlertMsgLoading();
                var acceptAllIPv4 = this.acceptAllIPv4 == "1" ? true : false;
                var datas=[{"enableRule":true,"acceptAll":acceptAllIPv4,"ippro":"IPV4"},{"enableRule":true,"acceptAll":acceptAllIPv4,"ippro":"IPV6"}];
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DEFAULT_FILTER,
                        method: JSONMethod.POST,
                        success:true,
                        datas: datas
                    },
                    success: function (data) {
                        vm.currentFlag = vm.acceptAllIPv4;
                        if (data.success == true) {
                            vm.MACDefualtSave(datas);
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            MACDefualtSave: function(datas){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_DEFAULT_FILTER,
                        method: JSONMethod.POST,
                        success:true,
                        datas: datas
                    },
                    success: function (data) {
                        if (data.success == true) {
                            vm.saveMac();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            saveMac: function(){
                if (this.valueMac.length === 0) {
                    this.saveIp();
                    return
                }
                for(var i=0;i<this.valueMac.length;i++){
                    this.valueMac[i].enableLink = this.acceptAllIPv4 == "1" ? false : true;
                }
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MAC_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.valueMac
                    },
                    success: function (data) {
                        if (data.success == true) {
                            vm.saveIp();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            saveIp: function(){
                if (this.valueIp.length === 0) {
                    this.savePort();
                    return
                }
                for(var i=0;i<this.valueIp.length;i++){
                    this.valueIp[i].enableLink = this.acceptAllIPv4 == "1" ? false : true;
                }
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.IP_PORT_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.valueIp
                    },
                    success: function (data) {
                        if (data.success == true) {
                            vm.savePort();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            savePort: function(){
                if (this.valuePort.length === 0) {
                    Page.applyFilter();
                    vm.disabled = false;
                    return
                }
                for(var i=0;i<this.valuePort.length;i++){
                    this.valuePort[i].enableLink = this.acceptAllIPv4 == "1" ? false : true;
                }
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.PORT_FILTER,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.valuePort
                    },
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
        },
        mounted: function(){
            Page.postJSON({
                json: {
                    cmd: RequestCmd.PORT_FILTER,
                    method: JSONMethod.GET,
                    getfun: true
                },
                success: function (data) {
                    if (data.datas.length > 0) {
                        vm.valuePort = data.datas;
                    }

                }
            });
            Page.postJSON({
                json: {
                    cmd: RequestCmd.IP_PORT_FILTER,
                    method: JSONMethod.GET,
                    getfun: true
                },
                success: function (data) {
                    if (data.datas.length > 0) {
                        vm.valueIp = data.datas;
                    }
                }
            });
            Page.postJSON({
                json: {
                    cmd: RequestCmd.MAC_FILTER,
                    method: JSONMethod.GET,
                    getfun: true
                },
                success: function (data) {
                    if (data.datas.length > 0) {
                        vm.valueMac = data.datas;
                    }
                }
            });
            this.getData();
        }
    })

});