$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            dmzSwitch: CHECK.required.dmzSwitch,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            ip: DOC.net.ip,
            save: DOC.btn.save,
            dmzIpValue: "",
            dmzSwich: false,
            disabled: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORK_SERVICE,
                        method: JSONMethod.GET,
                        subcmd: 6,
                        success: true
                    },
                    success: function (data) {
                        vm.dmzSwich = data.enabled == "1" ? true : false;
                        vm.dmzIpValue = data.ip
                    }

                });
            },
            setData: function () {
                this.disabled = true;
                var json = new Object();
                json.enabled = this.dmzSwich ? "1" : "0";

                if (json.enabled == "1") {
                    if (this.dmzIpValue == "") {
                        AlertUtil.alertMsg(CHECK.required.ip);
                        this.disabled = false;
                        return false;
                    }
                    if (!CheckUtil.checkIp(this.dmzIpValue)) {
                        AlertUtil.alertMsg(CHECK.format.ip);
                        this.disabled = false;
                        return false;
                    }
                }
                fyAlertMsgLoading();
                json.ip = this.dmzIpValue;
                json.cmd = RequestCmd.NETWORK_SERVICE;
                json.method = JSONMethod.POST;
                json.success = true;
                json.subcmd = 6;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted:function(){
            this.getData();
        }
    })
   
});