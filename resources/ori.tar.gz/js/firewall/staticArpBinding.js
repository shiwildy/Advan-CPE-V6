$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            title: [DOC.table.enableRule, DOC.table.priority, DOC.net.ipv46, DOC.net.targeAddr, wifiInfohtml.helper.title5, DOC.lbl.remark, DOC.table.editRule, DOC.table.delRule],
            value: [],
            edit: DOC.table.edit,
            ipv46: DOC.net.ipv46,
            ipv4: DOC.net.ipv4,
            ipv6: DOC.net.ipv6,
            del: dialconfightml.lnsTable.del,
            pinCode: DOC.lbl.pinCode,
            close: DOC.btn.close,
            AddroutingTable: TAB.route.AddroutingTable,
            btnSetting: networktoolhtml.form5.btnSetting,
            isWork: DOC.apn.isWork,
            ip: DOC.net.ip,
            example: DOC.lbl.example,
            colon: DOC.colon,
            savePinOk: DOC.btn.savePinOk,
            mac: DOC.net.mac,
            remark: DOC.lbl.remark,
            addRule: DOC.btn.addRule,
            applyRules: DOC.btn.applyRules,
            clearAllRules: DOC.btn.clearAllRules,
            editBoxShow: false,
            savePinOkShow: true,
            networktoolhtmlValue: "true",
            macListIpValue: "",
            macListValue: "",
            flag: "",
            Addrouting2Show: true,
            ipproValue: "IPV4",
            commentValue: "",
            showTip: false
        },
        methods: {
            createTable: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ARP_BINDING,
                        method: JSONMethod.GET,
                        getfun: true
                    },
                    success: function (data) {
                        if (data.datas.length > 0) {
                            vm.value = data.datas;
                        }
                    }
                });
            },
            addRuleClick: function () {
                $box.addClass('edit_box').show();
                $mask.show();
                this.commentValue = "";
                this.macListValue = "";
                this.macListIpValue = "";
                this.ipproValue = "IPV4";
            },
            btnCloseClick: function () {
                $box.removeClass('edit_box').hide();
                $mask.hide();
                this.flag = "";
            },
            btnSave: function () {
                if (this.macListIpValue == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return;
                }
                if (!CheckUtil.checkIp(this.macListIpValue,this.ipproValue)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return;
                }
                if (this.macListValue == "") {
                    AlertUtil.alertMsg(CHECK.required.mac);
                    return;
                }
                if (!CheckUtil.checkMac(this.macListValue)) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return;
                }
                var arr = {
                    ip: this.macListIpValue,
                    remark: this.commentValue,
                    mac: this.macListValue.match(/[0-9a-f]{2}/ig).join(":").toUpperCase(),
                    ippro: this.ipproValue
                };
                for(var i=0;i<this.value.length;i++){
                    var flag = 0 ;
                    if(this.value[i].ippro == arr.ippro){
                        flag += 1;
                    }
                    if(this.value[i].mac == arr.mac){
                        flag += 1;
                    }
                    if(this.value[i].ip == arr.ip){
                        flag += 1;
                    }
                    if(flag == 3){
                        if(this.flag === i && this.value[i].remark != arr.remark ){
                            break;
                        } else {
                            AlertUtil.alertMsg(CHECK.tip.filterRlueSame);
                            return false;
                        }
                    }
                }
                if (typeof this.flag === "number") {
                    arr.enableRule = this.value[this.flag].enableRule;
                    this.value[this.flag] = arr;
                } else {
                    arr.enableRule = true;
                    this.value.push(arr);
                }
                this.btnCloseClick();
                this.showTip = false;
                this.$nextTick(function(){
                    this.showTip = true;
                });
            },
            applyRulesClick: function () {
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ARP_BINDING,
                        method: JSONMethod.POST,
                        success: true,
                        datas: vm.value
                    },
                    success: function (data) {
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clearAllRulesClick: function () {
                if (this.value.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    fyAlertMsgLoading();
                    vm.value = [];
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.ARP_BINDING,
                            method: JSONMethod.POST,
                            success: true,
                            datas: vm.value
                        },
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                            } else {
                                fyAlertMsgFail();
                            }
                        }
                    });
                })
            },
            editClick: function (event, index) {
                this.flag = index;
                this.commentValue = event.remark;
                this.macListValue = event.mac;
                this.macListIpValue = event.ip;
                this.ipproValue = event.ippro;
                $box.addClass('edit_box').show();
                $mask.show();
            },
            delClick: function (index) {
                fyConfirmMsg(PROMPT.confirm.delRules, function () {
                    vm.value.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function(){
                        vm.showTip = true;
                    });
                })
            }
        },
        mounted: function () {
            this.createTable();
        }
    })
    var $box = $('#edit_box'),
        $mask = $('#mask');
});