$(document).ready(function () {
    var fm1 = ["form1", "child_container", "child_template"];
    var vm = new Vue({
        el: "#child_container",
        data: {
            configUpdate: MENU.sys.configUpdate,
            selectUpdateFile: DOC.sys.selectUpdateFile,
            colon: DOC.colon,
            browse: DOC.btn.browse,
            upload: DOC.btn.upload,
            update: DOC.btn.update,
            theUpdateFileName: "",
            isZip: false
        },
        methods: {
            btnUploadClick: function () {
                SysUtil.upload($('#form1'), $('#fp'), "config", function (fileName) {
                    vm.theUpdateFileName = fileName;

                    if (/\.zip$/.test(fileName)) {
                        vm.isZip = true;
                    }

                    closeBox();
                });
            },
            btnUpdateClick: function () {
                var errMsg = '';
                var isOk = false;
                var requiredReboot = false;

                if (vm.theUpdateFileName == "") {
                    AlertUtil.alertMsg(CHECK.required.uploadFile);
                    return false;
                }
                SysUtil.showProgress(60, PROMPT.status.updating,
                    function () {
                        return isOk;
                    },
                    function () {
                        closeBox();
                        if (requiredReboot) {
                            SysUtil.reboot2({
                                rebootType: RENOOTTYPE.RESTORE_SETTING,
                                msg: PROMPT.status.updateSuccess
                            });
                        } else {
                            AlertUtil.alertMsg(errMsg);
                        }
                    }
                );

                Page.postJSON({
                    json: {
                        cmd: RequestCmd.CONFIG_UPDATE,
                        method: JSONMethod.POST,
                        fileName: vm.theUpdateFileName,
                        isZip: vm.isZip
                    },
                    success: function (datas) {
                        Page.writeTime(1);
                        requiredReboot = true;

                        if (vm.isZip) {
                            isOk = true;
                        } else {
                            Page.postJSON({
                                json: {
                                    cmd: RequestCmd.RESTORE_DEFAULT
                                },
                                success: function (data) {},
                                complete: function () {
                                    isOk = true;
                                }
                            });
                        }
                    },
                    fail: function (datas) {
                        isOk = true;
                        errMsg = datas.message;
                    },
                    error: function (responseText, statusText) {
                        isOk = true;
                        errMsg = responseText;
                    }
                });
            }
        },
        mounted: function(){
            Page.createForm(fm1);
            $('#form1').attr({
                "enctype": "multipart/form-data",
                "method": "post"
            });
        }
    })

});