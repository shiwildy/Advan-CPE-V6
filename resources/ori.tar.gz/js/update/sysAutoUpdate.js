$(document).ready(function () {
    var fm1 = ["form1", "child_container2", "child_template2"];
    Page.createForm(fm1);
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            newVersion: DOC.sys.newVersion,
            detection: DOC.sys.detection,
            nowUpgrage: DOC.sys.nowUpgra,
            detectionResult: DOC.sys.detectionResult,
            hasResult: DOC.sys.hasResult,
            resultShow: true,
            upButtonShow: true,
            resultText: DOC.sys.notResult,
            realVersio: DOC.device.realVersion,
            realVersion: "",
            versionPath: DOC.sys.versionPath,
            pathText: "",
            autoUpdate: DOC.sys.autoUpdate,
            autoUpdateVersion: DOC.sys.autoUpdateVersion,
            autoValue: false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            save: DOC.btn.save,
            isShowSuper: false,
            disabled: false,
            deviceInfo: {},
            timesDownload: 0,
            timesUpgrade: 0,
            tr069Enabld: '0'
        },
        methods: {
            detectionVersion: function () {
                if (sessionStorage["sim_info"] == 0) {
                    fyAlertMsgWarn(PROMPT.tips.simStatus);
                    return false;
                }
                if (sessionStorage["signal_lvl"] < 1) {
                    fyAlertMsgWarn(PROMPT.tips.networkStatus);
                    return false;
                }
                if (this.tr069Enabld == '0') {
                    fyAlertMsgWarn(PROMPT.tips.tr069Disabled);
                    return false;
                }
                this.upButtonShow = false;
                this.resultShow = false;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DETECTION_VERSION_INFO
                    },
                    success: function (data) {
                        if (!!data && data.get_version == "true") {
                            var flag;
                            if (!!data.ver) {
                                flag = vm.versionStringCompare(data.ver, sessionStorage['fake_version']);
                                if (flag === 1) {
                                    vm.upButtonShow = true;
                                    vm.resultShow = true;
                                    vm.resultText = DOC.sys.hasResult + data.ver;
                                    vm.realVersion = data.realver;
                                    vm.pathText = data.url;
                                } else {
                                    flag = vm.versionStringCompare(data.realver, sessionStorage['real_fwversion']);
                                    if (flag === 1) {
                                        vm.upButtonShow = true;
                                        vm.resultShow = true;
                                        vm.resultText = DOC.sys.hasResult + data.ver;
                                        vm.realVersion = data.realver;
                                        vm.pathText = data.url;
                                    } else {
                                        vm.resultText = DOC.sys.notResult;
                                        vm.resultShow = true;
                                        vm.upButtonShow = false;
                                    }
                                }
                            } else {
                                vm.resultText = DOC.sys.errorResult;
                                vm.resultShow = true;
                                vm.upButtonShow = false;
                            }
                            fyAlertMsgSuccess();
                        } else if (data.get_version == "false") {
                            fyAlertMsgFail(DOC.lbl.readFail);
                        } else if (data.get_version == "timeout") {
                            fyAlertMsgFail(PROMPT.status.requestTimeout);
                        }
                    },
                    error: function (xhr, textStatus, error) {
                        fyAlertMsgFail(PROMPT.status.requestTimeout);
                    }
                }, 4000);
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.SYS_AUTO_UPGRADE
                    },
                    success: function (data) {
                        vm.autoValue = data.autoValue == "1" ? true : false;
                        vm.tr069Enabld = data.tr069Enabld == "1" ? "1" : "0";
                    }
                });
            },
            rightAway: function () {
                if (sessionStorage["signal_lvl"] < 1) {
                    fyAlertMsgWarn(PROMPT.tips.networkStatus);
                    return false;
                }
                fyAlertMsgLoading();
                this.timesDownload = 0;
                this.timesUpgrade = 0;
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.UPGRADE_IMMEDIATELY,
                        subcmd: 1
                    },
                    success: function (data) {
                        setTimeout(vm.loop, 3000);
                    }
                });
            },
            loop: function () {
                if (this.timesDownload > 300) {
                    fyAlertMsgFail(PROMPT.status.linkTimeout);
                    location.reload();
                    return;
                }
                if (this.timesUpgrade > 300) {
                    fyAlertMsgFail(DOC.sys.failUpgrade);
                    location.reload();
                    return;
                }
                setTimeout(function () {
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.UPGRADE_IMMEDIATELY
                        },
                        success: function (data) {
                            var flag = data.upgrade_from_web;
                            switch (flag) {
                                case "2":
                                    vm.timesDownload++;
                                    vm.timesUpgrade = 0;
                                    $(".fy-alert-header").text(DOC.sys.startDownload);
                                    vm.loop();
                                    break;
                                case "3":
                                    vm.timesDownload = 0;
                                    vm.timesUpgrade++;
                                    $(".fy-alert-header").text(DOC.sys.startUpgrade);
                                    vm.loop();
                                    break;
                                case "4":
                                    fyAlertMsgFail(DOC.sys.downloadFail);
                                    vm.timesDownload = 0;
                                    vm.timesUpgrade = 0;
                                    break;
                                case "5":
                                    fyAlertDestory();
                                    vm.timesDownload = 0;
                                    vm.timesUpgrade = 0;
                                    var isOk = false;
                                    var timeoutCtl = setTimeout(function () {
                                        isOk = true;
                                    }, 1000 * 200);
                                    SysUtil.showProgress(ProgressTime.REBOOT, PROMPT.status.rebooting,
                                        function () {
                                            return isOk;
                                        },
                                        function () {
                                            clearTimeout(timeoutCtl);
                                            location.reload();
                                        }
                                    );
                                    break;
                                default:
                                    fyAlertMsgFail(DOC.sys.failUpgrade);
                                    break;
                            }
                        },
                        error: function () {
                            location.reload();
                        }
                    }, 1000 * 180);
                }, 1000);
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                this.disabled = true;
                json.autoValue = this.autoValue ? "1" : "0";
                json.cmd = RequestCmd.SYS_AUTO_UPGRADE;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            versionStringCompare: function (preVersion, lastVersion) {
                var sources = preVersion.split('.');
                var dests = lastVersion.split('.');
                var maxL = Math.max(sources.length, dests.length);
                var result = 0;
                for (var i = 0; i < maxL; i++) {
                    var preValue = sources.length > i ? sources[i] : 0;
                    var preNum = isNaN(Number(preValue)) ? preValue.charCodeAt() : Number(preValue);
                    var lastValue = dests.length > i ? dests[i] : 0;
                    var lastNum = isNaN(Number(lastValue)) ? lastValue.charCodeAt() : Number(lastValue);
                    if (preNum < lastNum) {
                        result = -1;
                        break;
                    } else if (preNum > lastNum) {
                        result = 1;
                        break;
                    }
                }
                return result;
            },
        },
        mounted: function () {
            if (Page.level == "1") {
                this.isShowSuper = true;
            }
            this.upButtonShow = false;
            this.resultShow = false;
            this.getData();
        }
    })
});