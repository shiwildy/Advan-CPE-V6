$(document).ready(function() {
	Page.render('#sms_info', '#sms_template');

    var statusReport = false;
    // 获取是否索取短信回执
    Page.postJSON({
        json: {
            cmd: RequestCmd.GET_SMS_STATUS_REPORT,
            method: JSONMethod.POST
        },
        success: function(data) {
            if(data.statusReport == "1"){
            	statusReport = true;
            } else {
            	statusReport = false;
            }
            $('#statusReport').prop("checked", statusReport);
        }
    });

    $('#sms_title').html(Page.menuItem.title);
    var $phoneNo = $('#phoneNo'),
        $content = $('#content');

    var rules = {
        phoneNo: { required: true},
        content: { reallength: 1800 }
    };
    var messages = {
        phoneNo: { required: CHECK.required.phoneNo },
        content: { reallength: CHECK.max.smsLength }
    };

    var $lblSendSms = $('#lblSendSms');
    var $btnSave = $('#btnSave'), $btnSaveDraft = $('#btnSaveDraft');
    $btnSave.click(function() {
        if(!Page.connectStatus){
            AlertUtil.alertMsg(PROMPT.status.noNetwork);
            return;
        }
        $phoneNo.removeClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }

        var newStatusReport = $('#statusReport').prop("checked");
        if (newStatusReport != statusReport) {
            statusReport = newStatusReport;

        	Page.postJSON({
                json: {
                    cmd: RequestCmd.SET_SMS_STATUS_REPORT,
                    method: JSONMethod.POST,
                    statusReport: statusReport ? "1" : "0"
                },
                success: function(data) {
                    saveSms(SmsType.SEND);
                }
            });
        } else {
            saveSms(SmsType.SEND);
        }
    });

    $btnSaveDraft.click(function() {
        $phoneNo.addClass("ignore");
        if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
            return false;
        }
        saveSms(SmsType.DRAFT);
    });

    function getSalt() {
        return Md5.md5(Math.random().toString()).substring(0, 3);
    }

    function saveSms(smsType) {

        var salt = getSalt();
        var content = $content.val();
        // content里面不能包含字符串salt
        while(content.indexOf(salt) >= 0) {
            salt = getSalt();
        }

        if (smsType == SmsType.SEND) {
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.sendEmptySms)){
                    return;
                }
            }
            $lblSendSms.show();
        } else{
            if(!content){
                if(!AlertUtil.confirm(PROMPT.confirm.saveDraft)){
                    return;
                }
            }
        }

        $btnSave.disable();
        $btnSaveDraft.disable();

        Page.postJSON({
            json: {
                cmd: RequestCmd.SMS_SEND,
                method: JSONMethod.POST,
                smsType: smsType,
                salt: salt,
                smsId: $('#smsId').val(),
                phoneNo: $phoneNo.val().trim(),
                content: encodeURI(content),
                datetime: new Date().format('yyyy-mm-dd-HH-MM-ss')
            },
            success: function(data) {
                AlertUtil.alertMsg(data.message);
            },
            complete: function() {
                $btnSave.enable();
                $btnSaveDraft.enable();
                $lblSendSms.hide();
            }
        });
    }

    Page.setStripeTable();

    //IE7不加延迟会出现无法获得焦点，无法输入的问题

    $phoneNo.keypress(function(e){
        if(e.keyCode == 13){
            return false;
        }
    });

    if(!$.browser.msie){
        $phoneNo.focus();
    } else {
        setTimeout(function(){
            $phoneNo.focus();
        }, 1000);
    }
});