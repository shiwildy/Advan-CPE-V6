$(document).ready(function () {
    Page.render();

    $('#statusReport').prop("checked", Page.statusReport);

    $('#btnCloseSms').click(function () {
        var $box = $('#edit_box'),
            $mask = $('#mask');
        $box.hide();
        $mask.hide();
    });

    $('#phoneNo').keypress(function (e) {
        if (e.keyCode == 13) {
            return false;
        }
    });
});