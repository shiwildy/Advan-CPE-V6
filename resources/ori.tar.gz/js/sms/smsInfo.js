$(document).ready(function() {
	Page.render('#sms_pager', '#smsPager_template');
    $('#sms_title').html(Page.menuItem.title);

    var item_count = 10;
    Page.statusReport = false;
    // 获取是否索取短信回执
    Page.postJSON({
        json: {
            cmd: RequestCmd.GET_SMS_STATUS_REPORT,
            method: JSONMethod.POST
        },
        success: function(data) {
            if(data.statusReport == "1"){
            	Page.statusReport = true;
            } else {
            	Page.statusReport = false;
            }
        }
    });

    var pageIndex = 0,
    	pageSize = 10,
    	$box = $('#edit_box'),
    	$mask = $('#mask'),
  		$pagers = $('a[id^=pager]'),
  		$lblPager = $('#lblPager');

    function filterSms(smses, smsType){
    	if(!smses || !smses.datas){
    		return smses;
    	}

    	var retval = [], datas = smses.datas, len = datas.length, i, item;
    	for(i = 0; i < len; i++){
    		item = datas[i];
    		if(smsType == SmsType.RECEIVE ){
    			if(item.status == "0" || item.status == "1"){
    				retval.push(item);
    			}
    		} else if(smsType == SmsType.SEND){
    			if(item.status == "3"){
    				item.status = "1";
    				retval.push(item);
    			}
    		} else {
    			if(item.status == "2"){
    				//item.status = "1";
    				retval.push(item);
    			}
    		}
    	}

    	smses.datas = retval;

    	return smses;
    }

    function getSmsList() {
    	var url = String.format("{0}?cmd={1}&method=POST&smsType={2}&sessionId={3}&callback=?", Url.DEFAULT_CGI,
    			RequestCmd.SMS_INFO, Page.menuItem.smsType, Page.sessionId);

    	$.ajax({
			type: 'POST',
			url: url,
			cache: false,
            data: JSON.stringify({ cmd: RequestCmd.SMS_INFO, smsType: Page.menuItem.smsType }),
			dataType: 'jsonp',
			contentType: 'multipart/form-data',
			success: function(data) {
				if(Page.menuItem.smsType !=  SmsType.RECEIVE){
					var url_receive = String.format("{0}?cmd={1}&method=POST&smsType={2}&sessionId={3}&callback=?", Url.DEFAULT_CGI,
			    			RequestCmd.SMS_INFO, SmsType.RECEIVE, Page.sessionId);

					$.ajax({
						type: 'POST',
						url: url_receive,
						cache: false,
			            data: JSON.stringify({ cmd: RequestCmd.SMS_INFO, smsType: SmsType.RECEIVE }),
						dataType: 'jsonp',
						contentType: 'multipart/form-data',
						success: function(data_receive){

							data_receive = filterSms(data_receive, Page.menuItem.smsType);

							if(data_receive || data_receive.datas){
								var datas = data_receive.datas;
								for(var i = 0, length = datas.length; i < length; i++){
									data.datas.push(datas[i]);
								}
								item_count = datas.length;
							}

							createTable(data);
						},
						error: function(){}
					});
				} else {
					data = filterSms(data, SmsType.RECEIVE);
					createTable(data);
				}
			},
			error : function() {
			}
		});
        /*Page.postJSON({
            json: {
                cmd: RequestCmd.SMS_INFO,
                smsType: Page.menuItem.smsType
            },
            success: function(data) {
                createTable(data);
            },
            fail: function(data) {
                createTable(data);
            }
        });*/
    }

    function createTable(data) {
        var datas = data.datas;
        var recordCount = datas.length;
        var pageCount = parseInt((recordCount - 1) / pageSize, 10) + 1;
        pageIndex = Math.min(Math.max(0, pageIndex), pageCount - 1);

        var pagerHtml = String.format(DOC.pager.total, recordCount);
        if (recordCount > 0) {
        	pagerHtml = String.format(DOC.pager.currentPage, pagerHtml, pageIndex + 1, pageCount);
        }
        $lblPager.html(pagerHtml);

        if (recordCount == 0 || pageCount == 1) {
            $pagers.hide();
        } else {
            if (pageIndex == 0) {
            	$pagers.eq(0).hide();
                $pagers.eq(1).hide();
                $pagers.eq(2).show();
                $pagers.eq(3).show();
            } else if (pageIndex == pageCount - 1) {
                $pagers.eq(0).show();
                $pagers.eq(1).show();
                $pagers.eq(2).hide();
                $pagers.eq(3).hide();
            } else {
            	$pagers.show();
            }
        }

        var temp;
        for (var i = 0; i < recordCount; i++) {
            for (var j = i + 1; j < recordCount; j++) {
                if (datas[i].datetime < datas[j].datetime) {
                    temp = datas[i];
                    datas[i] = datas[j];
                    datas[j] = temp;
                }
            }
        }

        var items = [];
        var beginIndex = pageIndex * pageSize, endIndex = Math.min(beginIndex + pageSize, recordCount);
        for (var i = beginIndex; i < endIndex; i++) {
            items.push(datas[i]);
        }

    	SmsUtil.createTable({
            id: '#sms_info',
            smsType: Page.menuItem.smsType,
            datas: items,
            pageIndex: pageIndex,
            pageSize: pageSize,
            edit: function(id, phoneNo, content) {
                editSms(id, phoneNo, content);
            },
            del: function(smsId, smsIndex) {
                if (!confirm(PROMPT.confirm.deleteSms)) return;

            	Page.postJSON({
                    json: {
                        cmd: RequestCmd.SMS_DELETE,
                        method: JSONMethod.POST,
                        smsType: Page.menuItem.smsType,
                        smsId: smsId,
                        smsIndex: smsIndex
                    },
                    success: function(data) {
                    	getSmsList();
                    }
                });
            }
        });
    }

    $('#btnAdd').click(function() {
    	editSms(-1);
    });

    function editSms(id, phoneNo, content) {
    	Page.getHtml('html/sms/smsEdit.html', RequestCmd.SMS_SEND, function(data) {
            $mask.show();
            $box.show();
    		$box.html(data);
    		$box.css({
                width: 800,
                height: 300
            });
            SysUtil.setBoxStyle($box);

    		Page.setStripeTable('#edit_box table');
    		var $phoneNo = $('#phoneNo'),
    			$content = $('#content');
    		if(id == "-1" && phoneNo){
    			$('#edit_title').html(DOC.sms.reply);

    			if(!$.browser.msie){
    				$content.focus();
    			} else {
    				setTimeout(function(){
    					$content.focus();
        			}, 1000);
    			}
    		} else {
    			if(!$.browser.msie){
    				$('#edit_box input[type=text]:first').focus();
    			} else {
    				setTimeout(function(){
    					$('#edit_box input[type=text]:first').focus();
        			}, 1000);
    			}
    		}
            $('#smsId').val(id);
            $phoneNo.val(phoneNo || "");
            $content.val(content || "");

            var rules = {
                phoneNo: { required: true },
                content: { reallength: 1800 }
            };
            var messages = {
                phoneNo: { required: CHECK.required.phoneNo },
                content: { reallength: CHECK.max.smsLength }
            };

            var $lblSendSms = $('#lblSendSms');
            var $btnSave = $('#btnSave'), $btnSaveDraft = $('#btnSaveDraft');
            $btnSave.click(function() {
            	if(!Page.connectStatus){
            		AlertUtil.alertMsg(PROMPT.status.noNetwork);
            		return;
            	}
            	$phoneNo.removeClass("ignore");
            	if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
                    return false;
                }

                var newStatusReport = $('#statusReport').prop("checked");
                if (newStatusReport != Page.statusReport) {
                	Page.statusReport = newStatusReport;

                	Page.postJSON({
                        json: {
                            cmd: RequestCmd.SET_SMS_STATUS_REPORT,
                            method: JSONMethod.POST,
                            statusReport: Page.statusReport ? "1" : "0"
                        },
                        success: function(data) {
                            saveSms(SmsType.SEND);
                        }
                    });
                } else {
                    saveSms(SmsType.SEND);
                }
            });

            $btnSaveDraft.click(function() {
            	$phoneNo.addClass("ignore");
                if(!CheckUtil.checkForm($('#form1'), rules, messages)) {
                    return false;
                }
                saveSms(SmsType.DRAFT);
            });

            function getSalt() {
                return Md5.md5(Math.random().toString()).substring(0, 3);
            }

            function saveSms(smsType) {

                var salt = getSalt();
                var content = $content.val();
                // content里面不能包含字符串salt
                while(content.indexOf(salt) >= 0) {
                    salt = getSalt();
                }

                if (smsType == SmsType.SEND) {
                	if(!content) {
                		if(!AlertUtil.confirm(PROMPT.confirm.sendEmptySms)) {
                    		return;
                    	}
                	}
                	$lblSendSms.show();
                } else{
                	if(!content) {
                		if(!AlertUtil.confirm(PROMPT.confirm.saveDraft)) {
                    		return;
                    	}
                	}

                }
                $btnSave.disable();
            	$btnSaveDraft.disable();

            	Page.postJSON({
            		json: {
                        cmd: RequestCmd.SMS_SEND,
                        method: JSONMethod.POST,
                        smsType: smsType,
                        salt: salt,
                        smsId: $('#smsId').val(),
                        phoneNo: $phoneNo.val().trim(),
                        content: encodeURI(content),
                        datetime: new Date().format('yyyy-mm-dd-HH-MM-ss')
                    },
                    success: function(data) {
                    	AlertUtil.alertMsg(data.message);
                    },
                    complete: function() {
                        getSmsList();
                        $btnSave.enable();
                        $btnSaveDraft.enable();
                        $lblSendSms.hide();
                        /*
                        if(smsType == SmsType.SEND) {
                            $mask.hide();
                            $box.hide();
                        }
                        */
                    }
                });
            }
        });
    }

    $pagers.click(function() {
        var index = $pagers.index(this);
        switch(index) {
        case 0:
        	pageIndex = 0;
            break;
        case 1:
        	pageIndex--;
            break;
        case 2:
        	pageIndex++;
            break;
        case 3:
        	pageIndex = 999999;
            break;
        }
        getSmsList();
    });

    $('#btnDelete').click(function() {
        var ids = [], smdIndexes = [];
        $('input[id^=chkSms]').each(function() {
            if ($(this).prop("checked")) {
            	var id = this.id.slice(6);
            	ids.push($('#hddSmsId' + id).val());
            	smdIndexes.push($('#hddSmsIndex' + id).val());
            }
        });
        var length = ids.length;
        if (length == 0) {
            AlertUtil.alertMsg(PROMPT.status.chooseSms);
            return;
        }

        if (!confirm(PROMPT.confirm.deleteSms)) return;

        var ids_index = 0, last_ids_index = 0, count = 0,
            step_max = parseInt(100 / length, 10),
            step = parseInt(10 / length, 10);

        delSingleSms();
        SysUtil.showProgress_2(PROMPT.status.deletingSms, checkDelSmsStatus, processComplete);

        var stopped = false;
        function checkDelSmsStatus() {
        	if (stopped) return 100;

            if (last_ids_index < ids_index) {
                count = 0;
                last_ids_index = ids_index;
            }

            if (count < (step_max - step)) {
                count += step;
            }

        	var ret = parseInt((100 * ids_index) / length, 10) + count;
            if (ret > 100) {
                ret = 100;
            }

            return ret;
        }

        function delSingleSms() {
        	Page.postJSON({
                json: {
                    cmd: RequestCmd.SMS_DELETE,
                    method: JSONMethod.POST,
                    smsType: Page.menuItem.smsType,
                    smsId: ids[ids_index],
                    smsIndex: smdIndexes[ids_index]
                },
                success: function(data) {
                    ids_index++;
                    if (ids_index < length) {
                        if (Page.menuItem.smsType != SmsType.RECEIVE) {
                            // 非收件箱的短信删除时延时
                        	setTimeout(delSingleSms, 200);
                        } else {
                        	delSingleSms();
                        }
                    }
                },
                fail: function(data) {
                	stopped = true;
					AlertUtil.alertMsg(data.message);
                }
            });
        }
    });

    function processComplete() {
        $('#mask').hide();
        $('#progress_box').hide();
        getSmsList();
    }

    $('#btnDeleteAll').click(function() {
    	if (!confirm(PROMPT.confirm.deleteAllSms)) return;

    	var ids_index = 0;
        loop();

        var stopped = false;
        function loop() {
        	if (stopped) {
        		ids_index = 100;
        		return;
        	}

            if (ids_index < 99) {
            	ids_index++;
            }
            if (Page.menuItem.smsType != SmsType.RECEIVE) {
                setTimeout(loop, 50);
            } else {
                setTimeout(loop, 20 * item_count);
            }
        }

    	Page.postJSON({
            json: {
                cmd: RequestCmd.SMS_DELETE_ALL,
                method: JSONMethod.POST,
                smsType: Page.menuItem.smsType
            },
            success: function(data) {
            	setTimeout(function() {
                    ids_index = 100;
            	}, 500);
            },
            fail: function(data) {
                stopped = true;
				AlertUtil.alertMsg(data.message);
            }
        });

        SysUtil.showProgress_2(PROMPT.status.deletingSms, checkDelAllSmsStatus, processComplete);

        function checkDelAllSmsStatus() {
            return ids_index;
        }
    });

    getSmsList();
});
