$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "WIRELESS5G_ADVANCE";
    items.push({ title: MENU.settingWifi.wifi5gAdvance, url: 'html/config/wlan5gAdvance.html' });
    if(Page.level == "1"){
        items.push({ title: "WiFi-5G TPC", url: 'html/config/wlan5gTpc.html' });
    }
   	secondMenuClick(items,id);
});