/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2021-05-27 09:44:01
 * @,@LastEditTime: ,: 2021-05-27 09:45:40
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \S50_war\js\config\wirelessWpsSettingIndex.js
 */
$(document).ready(function () {

    var tabs = TAB.advance;
    var items = [];
    var id = "WPS_CONFIG";
    items.push({ title: wirelessconfightml.tab_menu.wps_24, url: 'html/config/wirelessWpsSetting.html' });
    items.push({ title: wirelessconfightml.tab_menu.wps_5, url: 'html/config/wireless5gWpsSetting.html' });
   	secondMenuClick(items,id);
});