$(document).ready(function () {
    var $mask = $('#mask');
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            disabled: false,
            editBox: false,
            macfilter: '',
            maclist: [],
            mac: '',
            remarks: '',
            flag: '',
            maclist24g: {}
        },
        methods: {
            btnSave: function (list) {
                var json = {};
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WIRELESS_MACFILTER;
                json.subcmd = '0';
                json.success = true;
                var datas = {};
                if (list) {
                    datas = list
                } else {
                    datas = {
                        macfilter: vm.macfilter,
                        maclist: vm.maclist
                    }
                }
                json.datas = datas;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            Sync24g: function () {
                fyConfirmMsg(PROMPT.confirm.SyncData, function () {
                    vm.btnSave(vm.maclist24g);
                    vm.maclist = vm.maclist24g.maclist;
                    vm.macfilter = vm.maclist24g.macfilter;
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS_MACFILTER,
                        method: JSONMethod.GET,
                        subcmd: '0'
                    },
                    success: function (data) {
                        if (data.hasOwnProperty("datas")) {
                            var data = data.datas;
                            vm.macfilter = data.macfilter;
                            vm.maclist = data.maclist || [];
                        } else {
                            vm.macfilter = 'close';
                            vm.maclist =  [];
                        }
                    }
                });
            },
            clearAll: function() {
                fyConfirmMsg(PROMPT.confirm.clearRules1, function () {
                    vm.maclist = [];
                });
            },
            addMac: function () {
                $mask.show();
                this.editBox = true;
                this.mac = '';
                this.remarks = '';
            },
            btnClose: function () {
                $mask.hide();
                this.editBox = false;
                this.flag = '';
            },
            isAddSave: function () {
                if (!CheckUtil.checkMac(this.mac.trim())) {
                    AlertUtil.alertMsg(CHECK.format.mac);
                    return false;
                }
                this.mac = this.mac.match(/[0-9a-f]{2}/ig).join(":").toUpperCase();
                for (var i=0;i<this.maclist.length;i++) {
                    if (this.maclist[i].mac == this.mac && i !== this.flag) {
                        AlertUtil.alertMsg(CHECK.format.sameMac);
                        return false;
                    }
                }
                if (this.flag !== "") {
                    this.maclist[this.flag].mac = this.mac
                    this.maclist[this.flag].remarks = this.remarks
                } else {
                    this.maclist.push({
                        mac: vm.mac,
                        remarks: vm.remarks
                    });
                }
                this.btnClose();
            },
            clickEdit: function (index) {
                this.flag = index;
                this.mac = this.maclist[index].mac;
                this.remarks = this.maclist[index].remarks;
                this.editBox = true;
                $mask.show();
            },
            clickDel: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.maclist.splice(index, 1);
                });
            },
        },
        mounted: function () {
            this.getData();
            Page.postJSON({
                json: {
                    cmd: RequestCmd.WIRELESS_MACFILTER,
                    method: JSONMethod.GET,
                    subcmd: '1'
                },
                success: function (data) {
                    if (data.hasOwnProperty("datas")) {
                        var data = data.datas;
                        vm.maclist24g = data;
                    } else {
                        vm.maclist24g = {
                            macfilter: 'close',
                            maclist: []
                        };
                    }
                }
            });
        }
    });
});
