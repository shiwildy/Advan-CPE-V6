$(document).ready(function () {
    var fm = ["childForm", "apnSetting_template", "childFormId"];
    $("#childForm").addClass("setting_apn_form");
    var rules = {
            apnMTU: {
                required: true,
                range: [600, 1500],
                digits: true
            },
        },
        messages = {
            apnMTU: {
                required: CHECK.required.mtu,
                range: CHECK.format.mtu,
                digits:CHECK.format.digits
            },
        };
    var vm = new Vue({
        el: "#apnSetting_template",
        data: {
            apn_nat: DOC.apn.nat,
            colon: DOC.colon,
            status_enable: DOC.status.enable,
            status_disable: DOC.status.disable,
            apn_natLookBack: DOC.apn.natLookBack,
            basic_apn: TAB.basic.apn,
            apn_mtu: DOC.apn.mtu,
            apn_type: DOC.apn.type,
            apn_authentication: DOC.apn.authentication,
            apn_user: DOC.apn.user,
            apn_password: DOC.apn.password,
            form5_btnSetting: networktoolhtml.form5.btnSetting,
            help: [{
                    title: DOC.apnHelper.title1,
                    name: DOC.apnHelper.name1
                },
                {
                    title: DOC.apnHelper.title3,
                    name: DOC.apnHelper.name3
                },
                {
                    title: DOC.apnHelper.title4,
                    name: DOC.apnHelper.name4
                },
                {
                    title: DOC.apnHelper.title5,
                    name: DOC.apnHelper.name5
                },
                {
                    title: DOC.apnHelper.title8,
                    name: DOC.apnHelper.name8
                },
                {
                    title: DOC.apnHelper.title6,
                    name: DOC.apnHelper.name6
                },
                {
                    title: DOC.apnHelper.title7,
                    name: DOC.apnHelper.name7
                }
            ],
            select_authentication:[
                {
                    name:"NONE",
                    value:"0"
                },
                {
                    name:"PAP",
                    value:"1"
                },
                {
                    name:"CHAP",
                    value:"2"
                },
                {
                    name:"PAP&CHAP",
                    value:"3"
                }

            ],
            select_type: [{
                    value: "IP",
                    name: "IPV4"
                },
                {
                    value: "IPV6",
                    name: "IPV6"
                },
                {
                    value: "IPV4V6",
                    name: "IPV4&V6"
                }
            ],
            apnNat: false,
            apnName: '',
            apnMTU: '',
            selectType: '',
            selectAuth: '',
            apnUserName: '',
            apnUserPassword: '',
            butAble: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_CONFIG,
                        methods: JSONMethod.GET,
                        subcmd: 1
                    },
                    success: function (data) {
                        vm.apnNat = data.apnNatName == "1" ? true : false;
                        vm.apnName = data.apnName;
                        vm.apnMTU = data.apnMTU;
                        vm.selectType = data.selectType;
                        vm.selectAuth = data.selectAuthtication;
                        vm.apnUserName = data.apnUserName;
                        vm.apnUserPassword = data.apnUserPassword;
                    }
                })
            },
            btnSave: function () {
                this.butAble = true;
                var $form = $("#childForm");
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    this.butAble = false;
                    return;
                }
                fyAlertMsgLoading();
                var json = {};
                json.selectAuthtication = parseInt(this.selectAuth, 10);
                json.apnUserName = this.apnUserName;
                json.apnName = this.apnName;
                json.selectType = this.selectType;
                json.apnMTU = this.apnMTU;
                json.apnUserPassword = this.apnUserPassword;
                json.apnNatName = this.apnNat ? "1" : "0";
                json.method = JSONMethod.POST;
                json.subcmd = 1;
                json.cmd = RequestCmd.APN_CONFIG;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.butAble = false;
                        if (data.message == "0") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                })
            }
        },
        mounted: function () {
            Page.createForm2(fm);
            this.getData()
        }
    });
});