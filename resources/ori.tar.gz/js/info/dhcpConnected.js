$(document).ready(function () {
    var vm = new Vue({
        el: "#networkList_template",
        data: {
            ipBinds: networkconfightml.ipMacEdit.ipBinds,
            tableTitle: [DOC.table.rowNo, DOC.net.host, DOC.net.mac, DOC.net.ip], //, DOC.net.leaseTime
            dhcpList: [],
            helpList: [{
                    title: networkconfig2html.helper.title1,
                    item: networkconfig2html.helper.item1
                },
                {
                    title: networkconfig2html.helper.title2,
                    item: networkconfig2html.helper.item2
                },
                {
                    title: networkconfig2html.helper.title3,
                    item: networkconfig2html.helper.item3
                }
            ]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DHCPCLIENT_INFO,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.dhcpList = datas.dhcp_list_info;

                    }
                });
            },
            leaseTimeText: function (event) {
                function formatDate(date) {
                    var year = date.getFullYear();
                    var month = date.getMonth() + 1;
                    var day = date.getDate();
                    var hour = date.getHours();
                    var minute = date.getMinutes();
                    var second = date.getSeconds();
                    //  return year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second; 
                    return year + '-' + (String(month).length > 1 ? month : '0' + month) + '-' +
                        (String(day).length > 1 ? day : '0' + day) + ' ' + (String(hour).length > 1 ? hour : '0' + hour) + ':' + (String(minute).length > 1 ? minute : '0' + minute) +
                        ':' + (String(second).length > 1 ? second : '0' + second)
                }
                var time = parseInt(event, 10) * 1000;
                if (isNaN(time)) {
                    return "-"
                }
                var d = new Date(time)
                return formatDate(d)
            }
        },
        mounted: function () {
            this.getData();
            Page.timer = setInterval(function () {
                vm.getData();
            }, 3000);
        }
    });

});