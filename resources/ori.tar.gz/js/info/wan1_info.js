var loading = "-";
var wan_names = [TAB.basic.apn, DOC.net.ip, DOC.net.mask, DOC.net.dns1, DOC.net.dns2,
    DOC.net.ipv6, DOC.net.dns3, DOC.net.dns4, DOC.net.rxPackets, DOC.net.txPackets, DOC.net.rxBytes, DOC.net.txBytes, DOC.lbl.ifName
];
var wan_values = new Array(13);
var vm_wan = new Vue({
    el: "#wan_content",
    data: {
        title_wan: DOC.title.apn,
        wan_names: wan_names,
        wan_values: wan_values,
        text: [{
                title: wanInfohtml.helper.title1,
                item: wanInfohtml.helper.item1
            },
            {
                title: wanInfohtml.helper.title2,
                item: wanInfohtml.helper.item2
            }
        ]
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.ROUTER_INFO
                },
                success: function (data) {
                    vm_wan.$set(wan_values, 0, data.apn_name || loading);
                    vm_wan.$set(wan_values, 1, data.wan_ip || loading);
                    vm_wan.$set(wan_values, 2, data.wan_netmask || loading);
                    vm_wan.$set(wan_values, 3, data.wan_dns || loading);
                    vm_wan.$set(wan_values, 4, data.wan_dns2 || loading);
                    vm_wan.$set(wan_values, 5, data.wan_ipv6_ip || loading);
                    vm_wan.$set(wan_values, 6, data.wan_ipv6_dns || loading);
                    vm_wan.$set(wan_values, 7, data.wan_ipv6_dns2 || loading);
                    vm_wan.$set(wan_values, 8, data.wan_rx_packets || loading);
                    vm_wan.$set(wan_values, 9, data.wan_tx_packets || loading);
                    vm_wan.$set(wan_values, 10, data.wan_rx_bytes || loading);
                    vm_wan.$set(wan_values, 11, data.wan_tx_bytes || loading);
                    vm_wan.$set(wan_values, 12, data.wan_real_iface || loading);
                }
            })

        }
    },
    mounted: function () {
        this.getData();
        Page.timer = setInterval(function () {
            vm_wan.getData();
        }, 3000);
    }
});