$(document).ready(function () {
    var text = wirelessconfightml.prompt;
    var vm = new Vue({
        el: "#macInfoContainer",
        data: {
            macInfo: wirelessconfightml.macInfoContainer.macInfos,
            tableTitle: [text.no, DOC.net.host, "MAC", DOC.net.ip, "SSID",DOC.lte.signalLeveldBm],
            usrInfos: '',
            macInfos: '',
            firstRequest: true,
            tableContent: []
        },
        methods: {
            getData:function(){
                 Page.postJSON({
                        json: { cmd: RequestCmd.WIFI5G_LIST_INFO,method:JSONMethod.GET},
                        success: function (datas) {
                          vm.tableContent = datas.wlan5g_wifi_info;

                        }
                });
            }
        },
        mounted:function(){
            this.getData();
             Page.timer = setInterval(function(){
                vm.getData();
        },3000);
        }
    });
});