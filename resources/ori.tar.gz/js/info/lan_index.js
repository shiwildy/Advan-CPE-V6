$(document).ready(function () {
    
    var tabs = TAB.advance;
    var id = "DHCP_INFO";
    var items = [];

    items.push({ title: "DHCP", url: 'html/info/lan_info.html' });
    if(Page.pageHideCheck(4))
        items.push({ title: "DHCP1", url: 'html/info/lan_info1.html' });
    if(Page.pageHideCheck(5))
        items.push({ title: "DHCP2", url: 'html/info/lan_info2.html' });
    
    items.push({ title: networkconfightml.tab_menu.item5, url: 'html/info/dhcpConnected.html' });
        

    secondMenuClick(items,id);
});

