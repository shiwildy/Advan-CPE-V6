var loading = "-";
var lan_names = [DOC.lan.lannet, DOC.net.dhcpServer, DOC.lan.netmask, DOC.lan.beginip, DOC.lan.endip, DOC.lan.intermac, DOC.lan.intername];
var lan_values = new Array(6);
var vm_lan = new Vue({
    el: "#lan_content",
    data: {
        title_lan: "LAN",
        lan_names: lan_names,
        lan_values: lan_values,
        text: [{
                title: lanInfohtml.helper.title1,
                item: lanInfohtml.helper.item1
            },
            {
                title: lanInfohtml.helper.title2,
                item: lanInfohtml.helper.item2
            },
            {
                title: lanInfohtml.helper.title3,
                item: lanInfohtml.helper.item3
            },
            {
                title: wifiInfohtml.helper.title5 ,
                item: wifiInfohtml.helper.item5  
            }
        ]
    },
    methods: {
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.LAN_INFO
                },
                success: function (data) {
                    vm_lan.$set(lan_values, 0, data.lan_ip || loading);
                    vm_lan.$set(lan_values, 1, data.lan_dhcp_enable == "1" ? DOC.status.enable : DOC.status.disable);
                    vm_lan.$set(lan_values, 2, data.lan_netmask || loading);
                    vm_lan.$set(lan_values, 3, data.dhcp_start_ip || loading);
                    vm_lan.$set(lan_values, 4, data.dhcp_end_ip || loading);
                    vm_lan.$set(lan_values, 5, data.lan_mac || loading);
                    vm_lan.$set(lan_values, 6, data.lan_real_iface || loading);


                }
            })

        }
    },
    mounted: function () {
        this.getData();
        Page.timer = setInterval(function () {
            vm_lan.getData();
        }, 3000);
    }
})