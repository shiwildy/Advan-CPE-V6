$(document).ready(function () {
  var vm = new Vue({
      el: "#child_container",
      data: {
          colon: DOC.colon,
          dialogFormVisible: false,
          formLabelWidth: '180px',
          l2tpv3Switch: false, //L2TPV3开关
          datas: [], //L2TPV3设备连接列表
          flag: -1, //标记当前是插入新数据还是编辑数据
          editForm: {  //表单数据对象
              localIP: "", //本端IP地址
              peerIP: "", //对端IP地址
              tunnelID: "", //本端端口ID
              peertunnelID: "", //对端端口ID
              sessionID: "", //本端会话ID
              peersessionID: "", //对端会话ID
              name: "",  //隧道名称
              state: "0" // 连接状态
          },
          rules: {   // 参数校验规则集
              localIP: [
                  { required: true, message: wirelessconfightml.prompt.ipCheckMsg1, trigger: 'blur' },
                  { pattern: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/, message: CHECK.format.ip, trigger: ['blur', 'change'] }
              ],
              peerIP: [
                  { required: true, message: wirelessconfightml.prompt.ipCheckMsg1, trigger: 'blur' },
                  { pattern: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/, message: CHECK.format.ip, trigger: ['blur', 'change'] }
              ],
              tunnelID: [
                  { required: true, message: "ID" + wirelessconfightml.prompt.noEmpty, trigger: 'blur' },
                  { type: 'integer', message: CHECK.format.digits, trigger: ['blur', 'change'] },
                  { type: 'number', min: 1, max: 65536, message: CHECK.range.l2tpv3ID, trigger: ['blur', 'change'] }
              ],
              peertunnelID: [
                  { required: true, message: "ID" + wirelessconfightml.prompt.noEmpty, trigger: 'blur' },
                  { type: 'integer', message: CHECK.format.digits, trigger: ['blur', 'change'] },
                  { type: 'number', min: 1, max: 65536, message: CHECK.range.l2tpv3ID, trigger: ['blur', 'change'] }
              ],
              sessionID: [
                  { required: true, message: "ID" + wirelessconfightml.prompt.noEmpty, trigger: 'blur' },
                  { type: 'integer', message: CHECK.format.digits, trigger: ['blur', 'change'] },
                  { type: 'number', min: 1, max: 65536, message: CHECK.range.l2tpv3ID, trigger: ['blur', 'change'] }
              ],
              peersessionID: [
                  { required: true, message: "ID" + wirelessconfightml.prompt.noEmpty, trigger: 'blur' },
                  { type: 'integer', message: CHECK.format.digits, trigger: ['blur', 'change'] },
                  { type: 'number', min: 1, max: 65536, message: CHECK.range.l2tpv3ID, trigger: ['blur', 'change'] }
              ],
              name: { required: true, message: dialconfightml.lnsTable.tunnelName + wirelessconfightml.prompt.noEmpty, trigger: ['blur', 'change'] }
          }
      },
      methods: {
          getData: function () {
              Page.postJSON({
                  json: { cmd: RequestCmd.L2TPV3_CONFIG },
                  success: function (data) {
                      vm.datas = data.datas;
                      vm.l2tpv3Switch = data.l2tpv3Switch == "1" ? true : false;
                  }
              })
          },
          clickBtnSave: function () {
              var json = {};
              json.cmd = RequestCmd.L2TPV3_CONFIG;
              json.method = JSONMethod.POST;
              json.l2tpv3Switch = this.l2tpv3Switch ? "1" : "0";
              if (this.l2tpv3Switch) {
                  json.datas = this.datas;
              }
              fyAlertMsgLoading();
              Page.postJSON({
                  json: json,
                  success: function (data) {
                      if (data.success) {
                          fyAlertMsgSuccess();
                      } else {
                          fyAlertMsgFail();
                      }
                  }
              });
          },
          editDatas: function (flag) {
              if(flag == -1 &&this.datas.length>7){
                this.$alert(CHECK.format.maxRuleNum, '', {
                  confirmButtonText: DOC.lbl.confirm,
                });
                return;
              }
              this.dialogFormVisible = true;
              this.flag = flag;
              if (flag > -1) {
                  this.editForm.localIP = this.datas[flag].localIP;
                  this.editForm.peerIP = this.datas[flag].peerIP;
                  this.editForm.tunnelID = Number(this.datas[flag].tunnelID);
                  this.editForm.peertunnelID = Number(this.datas[flag].peertunnelID);
                  this.editForm.sessionID = Number(this.datas[flag].sessionID);
                  this.editForm.peersessionID = Number(this.datas[flag].peersessionID);
                  this.editForm.name = this.datas[flag].name;
                  this.editForm.state = this.datas[flag].state;
              }
          },
          changeDatas: function () {
              this.$refs["editForm"].validate(function(valid){
                  if (valid) {
                      for (var i = 0; i < vm.datas.length; i++) {
                          if (vm.flag === i)
                              continue
                          if (vm.datas[i].localIP == vm.editForm.localIP && vm.datas[i].peerIP == vm.editForm.peerIP) {
                              fyAlertMsgWarn(CHECK.format.vpnSameTunnel);
                              return false;
                          }
                          if (vm.datas[i].name == vm.editForm.name) {
                              fyAlertMsgWarn(CHECK.format.vpnTunnelName);
                              return false;
                          }
                          if (vm.datas[i].tunnelID ==vm.editForm.tunnelID || vm.datas[i].peertunnelID == vm.editForm.tunnelID) {
                              fyAlertMsgWarn(CHECK.format.vpnPortId);
                              return false;
                          }
                          if (vm.datas[i].peertunnelID ==vm.editForm.peertunnelID || vm.datas[i].tunnelID == vm.editForm.peertunnelID) {
                              fyAlertMsgWarn(CHECK.format.vpnPortId);
                              return false;
                          }
                      }
                      vm.dialogFormVisible = false;
                      if (vm.flag > -1) {
                          vm.datas[vm.flag].localIP = vm.editForm.localIP;
                          vm.datas[vm.flag].peerIP = vm.editForm.peerIP;
                          vm.datas[vm.flag].tunnelID = vm.editForm.tunnelID;
                          vm.datas[vm.flag].peertunnelID = vm.editForm.peertunnelID;
                          vm.datas[vm.flag].sessionID = vm.editForm.sessionID;
                          vm.datas[vm.flag].peersessionID = vm.editForm.peersessionID;
                          vm.datas[vm.flag].name = vm.editForm.name;
                      } else {
                          vm.datas.push($.extend(true, {}, vm.editForm));
                      }
                  } else {
                      return false;
                  }
              });
          },
          deleteDats: function (flag) {
              fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                  vm.datas.splice(flag, 1);
              });
          }
      },
      watch: {
          dialogFormVisible: function (val) {
              if (!val) {
                  this.$refs["editForm"].resetFields();
                  this.editForm.localIP = "";
                  this.editForm.peerIP = "";
                  this.editForm.tunnelID = "";
                  this.editForm.peertunnelID = "";
                  this.editForm.sessionID = "";
                  this.editForm.peersessionID = "";
                  this.editForm.name = "";
                  this.editForm.state = "0";
              }
          }
      },
      mounted: function () {
          this.getData();
      }
  });
});
