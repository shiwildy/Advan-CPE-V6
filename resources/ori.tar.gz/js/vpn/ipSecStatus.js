$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            ipsecPolicyName: '-',
            localAddress: '-',
            peerAddress: '-',
            dataFlow: '-',
            IkeAlgorithm: '-',
            espAlgorithm: '-',
            duration: '-',
            ipsecStatus: '-',
            rxData: '-',
            txData: '-',
            refresh: false,
            timeout: ''
        },
        methods: {
            getData: function () {
                this.refresh = true;
                var json = {
                    cmd: RequestCmd.IPSEC_CONFIG,
                    subcmd: 1
                };
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.hasOwnProperty("message")) {
                            vm.ipsecPolicyName = '-';
                            vm.localAddress = '-';
                            vm.peerAddress = '-';
                            vm.dataFlow = '-';
                            vm.IkeAlgorithm = '-';
                            vm.espAlgorithm = '-';
                            vm.duration = '-';
                            vm.ipsecStatus = '-';
                            vm.rxData = '-';
                            vm.txData = '-';
                        } else {
                            vm.ipsecPolicyName = data.ipsec_policy_name || '-';
                            vm.localAddress = data.left || '-';
                            vm.peerAddress = data.right || '-';
                            vm.dataFlow = data.data_stream || '-';
                            vm.IkeAlgorithm = data.ike || '-';
                            vm.espAlgorithm = data.esp || '-';
                            vm.duration = data.ipsec_uptime || '-';
                            vm.ipsecStatus = data.ipsec_status == "1" ? '<span>'+DOC.status.connected+'</span>':'<span style="color:red">'+DOC.status.disconnected+'</span>';;
                            vm.rxData = data.ipsec_rx_data || '-';
                            vm.txData = data.ipsec_tx_data || '-';
                        }
                        if (!!vm.timeout) {
                            clearTimeout(vm.timeout)
                        }
                        vm.timeout = setTimeout ( function(){
                            vm.refresh = false;
                        }, 1000);
                    }
                });
            }
        },
        mounted: function () {
            this.getData()
        }
    });
});