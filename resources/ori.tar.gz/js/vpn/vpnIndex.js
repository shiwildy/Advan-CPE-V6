$(document).ready(function () {

    var id = "VPN_SETTING";
    var items = [];

    if(Page.pageHideCheck(31)){
        items.push({ title: MENU.vpn.head, url: 'html/vpn/vpn.html' });
    }
    if(Page.pageHideCheck(45)){
        items.push({ title: MENU.vpn.gre, url: 'html/vpn/gre.html' });
    }
    if(Page.pageHideCheck(57)){
        items.push({ title: MENU.vpn.l2tpv3, url: 'html/vpn/l2tpv3.html' });
    }
    items.push({ title: MENU.vpn.ipSec, url: 'html/vpn/ipSec.html' });

    items.push({ title: MENU.vpn.ipSecStatus, url: 'html/vpn/ipSecStatus.html' });

    secondMenuClick(items,id);
});