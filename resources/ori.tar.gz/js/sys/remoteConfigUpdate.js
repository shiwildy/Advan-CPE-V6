$(document).ready(function () {
	Page.render();
	Page.setStripeTable();

	Page.postJSON({
		json: {
			cmd: RequestCmd.ONLINE_UPGRADE_AUTO,
			method: JSONMethod.GET
		},
		success: function (data) {
			var onlineUpgradeAuto = data.onlineUpgradeAuto;
			if (onlineUpgradeAuto == "yes") {
				$('#onlineUpgradeAuto').prop('checked', true);
			} else {
				$('#onlineUpgradeAuto').prop('checked', false);
			}
		}
	});

	var $btnSave = $('#btnSave');
	$btnSave.bind('click', function () {
		var $form = $('#form1');
		var json = JSON.parmsToJSON($form);
		json.cmd = RequestCmd.ONLINE_UPGRADE_AUTO;
		json.method = JSONMethod.POST;
		json.onlineUpgradeAuto = json.onlineUpgradeAuto ? "yes" : "no";

		Page.postJSON({
			$id: $btnSave,
			json: json,
			success: function (data) {
				SysUtil.rebootDevice();
			}
		});
	});

});