var vm = new Vue({
    el: "#child_container",
    data: {
        colon: DOC.colon,
        save: DOC.btn.save,
        timeToSwitch: false,
        time: "",
        weekdayList: [{
                name: DOC.week.item1,
                value: "1"
            },
            {
                name: DOC.week.item2,
                value: "2"
            },
            {
                name: DOC.week.item3,
                value: "3"
            },
            {
                name: DOC.week.item4,
                value: "4"
            },
            {
                name: DOC.week.item5,
                value: "5"
            },
            {
                name: DOC.week.item6,
                value: "6"
            },
            {
                name: DOC.week.item,
                value: "7"
            },
        ],
        checkedWeek: []
    },
    methods: {
        getDateTime: function () {
            return new Date().format('yyyy-mm-dd HH:MM');
        },
        getData: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.TIME_TO_RESTART,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    vm.timeToSwitch = data.timrRestartSwitch == "1" ? true : false;
                    var newDate = new Date().toString()
                    var reg = /([0-1][0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])/
                    vm.time = data.restartHour + ':' + data.restartMinute + ':' + data.restartSecond
                    vm.time = newDate.replace(reg, vm.time);
                    vm.checkedWeek = data.restartWeek ? data.restartWeek.split("") : [];
                }
            });
        },
        getTime: function () {
            Page.postJSON({
                json: {
                    cmd: RequestCmd.SET_DATETIME,
                    method: JSONMethod.GET
                },
                success: function (data) {
                    vm.lblTimeText = data.systime;
                }
            });
        },
        btnSave: function () {
            var JSONParms = {};
            if(this.timeToSwitch){
                if(this.checkedWeek.length == 0){
                    this.$message({
                        type: "error",
                        offset: 200,
                        message: CHECK.required.restartWeek,
                        showClose: true,
                        duration: 1500
                    });
                    return false;
                }
                this.time = new Date(this.time)
                var hour = this.time.getHours()
                var minute = this.time.getMinutes()
                var second = this.time.getSeconds()
                hour = hour < 10 ? '0' + hour : hour
                minute = minute < 10 ? '0' + minute : minute
                second = second < 10 ? '0' + second : second
                JSONParms = {
                    timrRestartSwitch: '1',
                    restartHour: hour,
                    restartMinute: minute,
                    restartSecond: second,
                    cmd: RequestCmd.TIME_TO_RESTART,
                    method: JSONMethod.POST,
                    restartWeek: this.checkedWeek.join("")
                }
            } else {
                JSONParms = {
                    timrRestartSwitch: '0',
                    cmd: RequestCmd.TIME_TO_RESTART,
                    method: JSONMethod.POST
                }
            }
            fyAlertMsgLoading();
            Page.postJSON({
                json: JSONParms,
                success: function (data) {
                    if (data.success == true) {
                        fyAlertMsgSuccess();
                    } else {
                        fyAlertMsgFail();
                    }
                }

            });
        },
        handleCheckAllChange: function(val) {
            this.checkedWeek = val ? ["1","2","3","4","5","6","7"] : [];
        }
    },
    mounted: function () {
        this.getData();
        var chars = '0123456789';
        var maxPos = chars.length;
        var code = '';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * maxPos));
        }
        $.getScript("js/element.js?"+(+code));
    },
    computed:{
        isIndeterminate: function(){
            return this.checkedWeek.length > 0 && this.checkedWeek.length < this.weekdayList.length;
        },
        checkAll: function(){
            return this.checkedWeek.length == this.weekdayList.length
        }
    }
});