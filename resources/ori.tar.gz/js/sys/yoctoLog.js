$(document).ready(function () {
    var vm = new Vue({
        el: "#child_container",
        data: {
            yoctoSwitch: false,
            disabled: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.YOCTO_LOG_SWITCH
                    },
                    success: function (data) {
                        vm.yoctoSwitch = data.syslogSwich == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.syslogSwich = this.yoctoSwitch ? "1" : "0";
                json.cmd = RequestCmd.YOCTO_LOG_SWITCH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.flag == '1') {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })

});