$(document).ready(function() {
	var fm = ["form1", "child_container", "childFormId"];
    Page.createForm(fm);
    var $btnSave = $('#btnSave');
 	var vm = new Vue({
 		el:"#child_container",
 		data:{
 			oldPasswd:DOC.sys.oldPasswd,
 			newPasswd:DOC.sys.newPasswd,
 			colon:DOC.colon,
 			duplicateNewPasswd:DOC.sys.duplicateNewPasswd,
 			btnSave:DOC.btn.save,
 			userText:false,
 			adminText:false,
 			superText:false,
 			oldPasswdValue:"",
 			newPasswdValue:"",
 			newPasswd2Value:"",
 			userLevelValue:"3",
 			setPasswdValue:"",
 			confirmSetPasswdValue:"",
 			resetUserPasswd:DOC.sys.resetUserPasswd,
			 resetNewPasswd:DOC.sys.resetNewPasswd,
			 list:[
				{
					name:DOC.sys.adminUser,
					value:"2"
				},
				{
					name:DOC.sys.username,
					value:"3"
				}
			]
 		},
 		methods:{
 			btnSaveClick:function(){
 				var $form = $('#form1');
		    	if(!CheckUtil.checkForm($form, rules, messages)){
		    		return false;
				}
				var pattern  = /^[\u4E00-\u9FA5\uF900-\uFA2D\u0020]*$/;
				var reg = new RegExp(/\s/)
				if(pattern.test(this.newPasswdValue)||reg.test(this.newPasswdValue)){
					fyConfirmMsg2(CHECK.format.loginPass);
					return false;
				}
		    	var json = {};
		    	if(vm.newPasswdValue != vm.newPasswd2Value)
 				{
 					fyConfirmMsg2(CHECK.format.passwdNotSame);
 					return false;
 				}
		    	json.cmd = RequestCmd.CHANGE_PASSWD;
		    	json.method = JSONMethod.POST;
		    	json.newPasswd = Base64.encode(this.newPasswdValue);
		    	json.old_passwd = Base64.encode(this.oldPasswdValue);
		    	json.subcmd = 0;
		    	fyAlertMsgLoading();
		        Page.postJSON({
			        $id: $btnSave,
		        	json: json,
			        success: function(data) {
			        	if(data.message == "success"){
			        		vm.oldPasswdValue = "";
				        	vm.newPasswdValue = "";
				        	vm.newPasswd2Value = "";
			                fyAlertMsgSuccess();
									Page.postJSON({
										json: {
											cmd: RequestCmd.LOGOUT,
											method: JSONMethod.POST
										},
										success: function (data) {
											var option = {
												expireHours: -1,
												path: "/",
												domain: location.hostname
											};
											CookieUtil.deleteCookie("sessionId", option);
											sessionStorage.clear();
											location.href = Page.getUrl(Url.LOGIN);
										}
									});
			        	}else if(data.message == "passwd error"){
			        		fyConfirmMsg2(PROMPT.saving.previousPasswd,true);
			        	}else{
			        		fyAlertMsgFail();
			        	}
			        	
			        }
		        });
 			},
 			btnSaveClick2:function(){
 				var $form = $('#form1');
		    	if(!CheckUtil.checkForm($form, rules, messages)){
		    		return false;
				}
				var pattern  = /^[\u4E00-\u9FA5\uF900-\uFA2D\u0020]*$/;
				var reg = new RegExp(/\s/)
				if(pattern.test(this.setPasswdValue)||reg.test(this.setPasswdValue)){
					fyConfirmMsg2(CHECK.format.loginPass);
					return false;
				}
		    	var json = {};
		    	if(vm.setPasswdValue != vm.confirmSetPasswdValue)
 				{
 					fyConfirmMsg2(CHECK.format.passwdNotSame);
 					return false;
 				}
		    	json.cmd = RequestCmd.CHANGE_PASSWD;
		    	json.method = JSONMethod.POST;
		    	json.setPasswd = Base64.encode(this.setPasswdValue);
		    	if(Page.level == "2"){
		    		json.subcmd = 1;
		    	}else if(Page.level == "1"){
		    		json.subcmd = 2;
		    		json.tz_account = Base64.encode(this.userLevelValue);
		    	}
		    	fyAlertMsgLoading();
		        Page.postJSON({
			        $id: $btnSave,
		        	json: json,
			        success: function(data) {
			        	if(data.message == "success"){
	        				vm.setPasswdValue = "";
		        			vm.confirmSetPasswdValue = "";
		               	 	fyAlertMsgSuccess();	
			        	}else{
			        		fyAlertMsgFail();
			        	}
			        	
			        }
		        });
 			}
 		},
 		mounted:function(){
 			if(Page.level == "3"){
 				this.userText = true;
 			}else{
 				this.adminText = true;
 				if(Page.level == "1"){
 					this.superText = true;
 				}
 			}
 		}
 	})
    var rules = {
      	oldPasswd: { required: true },
      	newPasswd: { required: true, rangelength: [5, 20] },
      	setPasswd: { required: true, rangelength: [5, 20] },
      	newPasswd2: { required: true, rangelength: [5, 20]},
      	confirmSetPasswd: { required: true, rangelength: [5, 20]}
    },
    messages = {
    	oldPasswd: { required: CHECK.required.oldPasswd },
    	newPasswd: { required: CHECK.required.newPasswd, rangelength: CHECK.range.passwd },
    	setPasswd: { required: CHECK.required.newPasswd, rangelength: CHECK.range.passwd },
    	confirmSetPasswd: { required: CHECK.required.duplicateNewPasswd, rangelength: CHECK.range.passwd},
    	newPasswd2: { required: CHECK.required.duplicateNewPasswd, rangelength: CHECK.range.passwd}
    };
});

