$(document).ready(function() {
	var fm = ["form1", "child_container", "childFormId"];
    Page.createForm(fm);
    var $btnSave = $('#btnSave');
 	var vm = new Vue({
 		el:"#child_container",
 		data:{
 			oldUsername:DOC.sys.oldUsername,
 			newUsername:DOC.sys.newUsername,
 			colon:DOC.colon,
 			duplicateNewUsername:DOC.sys.duplicateNewUsername,
 			btnSave:DOC.btn.save,
 			userText:false,
 			adminText:false,
 			superText:false,
 			oldNameValue:"",
 			newNameValue:"",
 			newName2Value:"",
 			userLevelValue:"3",
 			setNameValue:"",
 			confirmSetNameValue:"",
 			resetUsername:DOC.sys.resetUsername,
			 resetNewName:DOC.sys.resetNewName,
			 list:[
				{
					name:DOC.sys.adminUser,
					value:"2"
				},
				{
					name:DOC.sys.username,
					value:"3"
				}
			]
 		},
 		methods:{
 			btnSaveClick:function(){
 				var $form = $('#form1');
		    	if(!CheckUtil.checkForm($form, rules, messages)){
		    		return false;
		    	}
		    	if(vm.newNameValue != vm.newName2Value)
 				{
 					fyConfirmMsg2(CHECK.format.passwdNotSame);
 					return false;
 				}
		    	var json = {};
		    	json.cmd = RequestCmd.CHANGE_USERNAME;
		    	json.method = JSONMethod.POST;
		    	json.newUsername = this.newNameValue;
		    	json.oldUsername = this.oldNameValue;
		    	json.subcmd = 0;
		    	fyAlertMsgLoading();
		        Page.postJSON({
			        $id: $btnSave,
		        	json: json,
			        success: function(data) {
			        	if(data.message == "success"){
			        		vm.oldNameValue = "";
				        	vm.newNameValue = "";
				        	vm.newName2Value = "";
			                 fyAlertMsgSuccess();
			        	}else if(data.message == "passwd username"){
			        		fyConfirmMsg2(PROMPT.saving.previousUsername,true);
			        	}else{
			        		fyAlertMsgFail();
			        	}
			        	
			        }
		        });
 			},
 			btnSaveClick2:function(){
 				var $form = $('#form1');
		    	if(!CheckUtil.checkForm($form, rules, messages)){
		    		return false;
		    	}
		    	if(vm.setNameValue != vm.confirmSetNameValue)
 				{
 					fyConfirmMsg2(CHECK.format.usernameNotSame);
 					return false;
 				}
		    	var json = {};
		    	json.cmd = RequestCmd.CHANGE_USERNAME;
		    	json.method = JSONMethod.POST;
		    	json.setUsername = this.setNameValue;
		    	if(Page.level == "2"){
		    		json.subcmd = 1;
		    	}else if(Page.level == "1"){
		    		json.subcmd = 2;
		    		json.tz_account = this.userLevelValue;
		    	}
		    	fyAlertMsgLoading();
		        Page.postJSON({
			        $id: $btnSave,
		        	json: json,
			        success: function(data) {
			        	if(data.message == "success"){
			        		vm.setNameValue = "";
			        		vm.confirmSetNameValue = "";
			        		fyAlertMsgSuccess();
			        	}else{
			        		fyAlertMsgFail();
			        	}
			        }
		        });
 			}
 		},
 		mounted:function(){
 			if(Page.level == "3"){
 				this.userText = true;
 			}else{
 				this.adminText = true;
 				if(Page.level == "1"){
 					this.superText = true;
 				}
 			}
 		}
 	})
     var rules = {
    	oldUsername: { required: true },
    	newUsername: { required: true, rangelength: [2, 20] },
    	newUsername2: { required: true, rangelength: [2, 20]},
    	setName: { required: true, rangelength: [2, 20]},
    	confirmSetName: { required: true, rangelength: [2, 20]}
    },
    messages = {
    	oldUsername: { required: CHECK.required.oldUsername },
    	newUsername: { required: CHECK.required.newUsername, rangelength: CHECK.range.username },
    	newUsername2: { required: CHECK.required.duplicateNewUsername, rangelength: CHECK.range.username},
    	setName: { required: CHECK.required.duplicateNewUsername, rangelength: CHECK.range.username},
    	confirmSetName: { required: CHECK.required.duplicateNewUsername, rangelength: CHECK.range.username},
    };
});
