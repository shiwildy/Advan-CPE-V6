$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            modemLogValue: false,
            enabled: DOC.status.enabled,
            disable: DOC.status.disabled,
            disabled: false,
            modemLogSwitch: DOC.sip.sipServerSwitch,
            save: DOC.btn.save
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.MODEM_LOG_SWITCH
                    },
                    success: function (data) {
                        vm.modemLogValue = data.modemLogSwitch == "1" ? true : false;
                    }

                });
            },
            setData: function () {
                var json = {};
                fyAlertMsgLoading();
                json.modemLogSwitch = this.modemLogValue ? "1" : "0";
                json.cmd = RequestCmd.MODEM_LOG_SWITCH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })
});