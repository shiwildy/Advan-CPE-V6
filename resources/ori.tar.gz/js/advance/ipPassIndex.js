$(document).ready(function () {

    var tabs = TAB.advance;
    var id = "IP_PASSTHROUGH";
    var items = [];

    items.push({ title: "IP Passthrough", url: 'html/advance/ipPass.html' });

    secondMenuClick(items,id);
});