var fm = ['childForm', 'wlform1_template', 'childFormId'];
var vm = new Vue({
    el: '#wlform1_template',
    data: {
        LinkMode: 'linkIP', //链接方式
        IpVersion: 'IPv4', //IP协议版本
        IpMode: 'dhcp', //IP获取方式
        MTU: '', //MTU参数
        MRU: '', //MRU参数
        IpAddr4: '', //IP 地址
        Submask4: '', //子网掩码
        Gateway4: '', //缺省网关
        FirstDns4: '', //首选DNS服务器
        SecDns4: '', //备用DNS服务器
        NatEnable: false, //使能NAT开关
        UserName: '', //用户名
        PassWd: '', //密码
        Dhcpv6Mode: 'N/A', //IPv6 WAN信息获取方式
        IpAddr6: '', //IPv6 地址
        IpAddr6Len: '', //IPv6 地址长度
        Gateway6: '', //IPv6缺省网关
        FirstDns6: '', //IPv6首选DNS服务器
        SecDns6: '',//IPv6备用DNS服务器
        PdEnable: false, //PD使能
        Dhcpv6PD: 'No', //前缀模式
        prefixIpAddr: '', //前缀地址
        preferredLife: '', //首选寿命
        effectiveLife: '', //有效寿命
        MacClone:"",
        helps: [ //帮助信息列表
            { title: DOC.wiredSetting.title1, item: DOC.wiredSetting.item1 },
            { title: DOC.wiredSetting.title2, item: DOC.wiredSetting.item2 },
            { title: DOC.wiredSetting.title3, item: DOC.wiredSetting.item3 },
            { title: DOC.wiredSetting.title4, item: DOC.wiredSetting.item4 },
            { title: DOC.wiredSetting.title5, item: DOC.wiredSetting.item5 }
        ],
    },
    methods: {
        getData: function () {  //获取参数列表
            Page.postJSON({
                json: {
                    cmd: RequestCmd.BROADBAND_SETTING,
                },
                success: function (data) {
                    console.log(data);
                    vm.LinkMode = data.LinkMode;
                    vm.NatEnable = data.NatEnable || "0";
                    // vm.IpVersion = data.IpVersion;
                    vm.MacClone = data.MacClone;
                    vm.IpMode = data.IpMode;
                    vm.MTU = data.MTU;
                    vm.MRU = data.MRU;
                    vm.IpAddr4 = data.IpAddr4;
                    vm.Submask4 = data.Submask4;
                    vm.Gateway4 = data.Gateway4;
                    vm.FirstDns4 = data.FirstDns4;
                    vm.SecDns4 = data.SecDns4;
                    vm.UserName = data.UserName;
                    vm.PassWd = data.PassWd;
                    vm.Dhcpv6Mode = data.Dhcpv6Mode;
                    vm.IpAddr6 = data.IpAddr6;
                    vm.IpAddr6Len = data.IpAddr6Len;
                    vm.Gateway6 = data.Gateway6;
                    vm.FirstDns6 = data.FirstDns6;
                    vm.SecDns6 = data.SecDns6;
                    vm.PdEnable = data.PdEnable || "No";
                    vm.Dhcpv6PD = data.Dhcpv6PD || "Yes";
                    vm.prefixIpAddr = data.prefixIpAddr;
                    vm.preferredLife = data.preferredLife;
                    vm.effectiveLife = data.effectiveLife;
                }
            })
        },
        clickBtnSave: function () { //设置参数列表
            var $form = $('#childForm');
            var rules = {   //Form表达校验规则对象
                MTU: { required: true, digits: true, range: [576, 1500] },
                MRU: { required: true, digits: true, range: [128, 1492] },
                UserName: { required: true },
                PassWd: { required: true },
                MacClone:{mac:true},
                IpAddr4: { required: true, ip: true },
                Submask4: { required: true, subnetmask_check: true },
                Gateway4: { required: true, gateway: true },
                FirstDns4: { required: true, ip: true },
                SecDns4: { ip: true },
                IpAddr6: { required: true, ipv6_ip: true },
                IpAddr6Len: { required: true, range: [1, 128] },
                Gateway6: { ipv6_ip: true },
                FirstDns6: { required: true, ipv6_ip: true },
                SecDns6: { ipv6_ip: true },
                prefixIpAddr: { required: true, ipv6_ip_prefix: true },
                preferredLife: { required: true, range: [600, 4294967295] },
                effectiveLife: { required: true, range: [600, 4294967295] },
            };
            var messages = { //检验不过时错误提示信息
                MTU: { required: CHECK.required.mtu, digits: CHECK.format.digits, range: CHECK.range.MTURange },
                MRU: { required: CHECK.required.mru, digits: CHECK.format.digits, range: CHECK.range.MRURange },
                UserName: { required: CHECK.required.ddnsUsername },
                PassWd: { required: CHECK.required.ddnsPasswd },
                MacClone:{mac:CHECK.format.mac},
                IpAddr4: { required: CHECK.required.ip, ip: CHECK.format.ip },
                Submask4: { required: CHECK.required.netmask, subnetmask_check: CHECK.format.netmask },
                Gateway4: { required: CHECK.required.gateway, gateway: CHECK.format.gateway },
                FirstDns4: { required: CHECK.format.dns2, ip: CHECK.format.dns },
                SecDns4: { ip: CHECK.format.dns },
                IpAddr6: { required: CHECK.required.noEmpty, ipv6_ip: CHECK.format.formatError },
                IpAddr6Len: { required: CHECK.required.noEmpty, range: CHECK.format.formatError },
                Gateway6: { required: CHECK.required.noEmpty,ipv6_ip: CHECK.format.formatError },
                FirstDns6: { required: CHECK.format.dns2, ipv6_ip: CHECK.format.dns },
                SecDns6: { ipv6_ip: CHECK.format.dns },
                prefixIpAddr: { required: CHECK.required.noEmpty, ipv6_ip_prefix: CHECK.format.formatError },
                preferredLife: { required: CHECK.required.noEmpty, range: CHECK.format.formatError },
                effectiveLife: { required: CHECK.required.noEmpty, range: CHECK.format.formatError },
            };
            if (!CheckUtil.checkForm($form, rules, messages)) {  //验证
                return false;
            }
            var json = JSON.parmsToJSON($form);
            if ( json.hasOwnProperty('preferredLife') && Number(this.preferredLife) >= Number(this.effectiveLife) ) {
                AlertUtil.alertMsg(DOC.wiredSetting.compareLife);
                return false;
            }
            if ( json.hasOwnProperty('IpMode') ) {
                json.IpMode = this.IpMode;
            }
            if ( json.hasOwnProperty('Dhcpv6Mode') ) {
                json.Dhcpv6Mode = this.Dhcpv6Mode;
            }
            fyAlertMsgLoading();
            json.method = JSONMethod.POST;
            json.cmd = RequestCmd.BROADBAND_SETTING;
            json.LinkMode = this.LinkMode;
            json.MacClone = this.MacClone&&this.MacClone.match(/[0-9a-f]{2}/ig).join(":").toUpperCase() || "";
            json.IpVersion = "IPv4";
            Page.postJSON({
                json: json,
                success: function (data) {
                    if (data.success) {
                        fyAlertMsgSuccess();
                        vm.getData();
                    } else {
                        fyAlertMsgFail();
                    }
                }
            });
        }
    },
    mounted: function () {
        Page.createForm(fm);
        this.getData();
    },
    watch: {
        Dhcpv6Mode: function(){
            if(this.Dhcpv6Mode == 'N/A'){
                this.Dhcpv6PD = 'No'
            }
        },
        LinkMode: function(){
            if(this.LinkMode == 'linkPPP' && this.Dhcpv6Mode == 'N/A'){
                this.Dhcpv6Mode = 'Yes'
            }
        }
    }
})