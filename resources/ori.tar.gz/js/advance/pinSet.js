$(document).ready(function () {
    var fm = ["pingForm", "child_container", "pingFormId"];
    Page.createForm(fm);
    var $mask = $ ('#mask');
    var vm = new Vue({
        el: "#child_container",
        data: {
            pinVerification: DOC.lbl.pinVerification,
            colon: DOC.colon,
            pinOper: DOC.lbl.pinOper,
            pinOper1: DOC.lbl.pinOper1,
            pinOper2: DOC.lbl.pinOper2,
            pinOper3: DOC.lbl.pinOper3,
            pinCode: DOC.lbl.pinCode,
            pinSetRemind: TAB.basic.pinSetRemind,
            pinchange: DOC.lbl.pinchange,
            puk: CHECK.required.puk,
            newPin: CHECK.required.newPin,
            newPinConfirm: CHECK.required.newPinConfirm,
            save: DOC.btn.save,
            isPinLocked: null,
            isPukLocked: null,
            btnDis: false,
            raDis: false,
            isShowPuk: false,
            isShowPin: false,
            isShowModifyPin: false,
            isShowPinStatus: false,
            pinStatus: '',
            optr: '',
            pinPasswordConfirm: '',
            pinPassword: '',
            pukPassword: '',
            pukPinPassword: '',
            pukPinPasswordConfirm: '',
            pinPasswordChange: '',
            initOptr: null,
            openedShow: false,
            closedShow: false,
            changeShow: false,
            pinStats: "",
            pukStats: "",
            isShowPinFlag: false,
            pinBox:false,
            pinswitch:"",
            btnDis1:"",
            pinTimes:'',
            pukTimes:'',
            simExist: '',
            pinNum:""
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
        },
        methods: {
            checkSimStatus: function (){
                Page.postJSON({
                    json:{
                        cmd:RequestCmd.GET_SYS_STATUS,
                    },
                    success: function (datas){
                        if(datas.sim_status == "0"){
                            vm.simExist = true ;
                        }else{
                            vm.simExist = false;
                        }
                    }
                })
            },
            checkPinPukTimes: function (){
                Page.postJSON({
                    json:{
                        cmd: RequestCmd.QUERY_SIM_STATUS
                    },
                    success:function(datas){
                        if (datas.lock_puk_flag == "1") {
                            if (parseInt(datas.puk_left_times) < 10) {
                                setTimeout(function(){
                                    //次数警告框
                                    AlertUtil.alertMsg(String.format(PROMPT.status.pukTimes, datas.puk_left_times));
                                    // AlertUtil.alertMsg(CHECK.required.newPinConfirm2)
                                }, 500);
                            }
                        }
                         else {
                            if (parseInt(datas.pin_left_times) < 3) {
                                setTimeout(function(){
                                    AlertUtil.alertMsg(String.format(PROMPT.status.pingTimes, datas.pin_left_times));
                                }, 500);
                            }
                        }

                    }   
                })
               
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.QUERY_SIM_STATUS
                    },
                    success: function (datas) {
                        vm.pinStats = datas.lock_pin_flag;
                        vm.pukStats = datas.lock_puk_flag;
                        vm.pinTimes = datas.pin_left_times;
                        vm.pukTimes = datas.puk_left_times;
                        vm.isShowModifyPin = false;
                        vm.pinPassword = "";
                        vm.pinPasswordChange = "";
                        vm.pukPassword = "";
                        vm.pukPinPasswordConfirm = "";
                        vm.pinPasswordConfirm = "";
                        vm.pinNum = datas.pin_left_times;
                        // if (datas.lock_puk_flag == "1") {
                        //     if (parseInt(datas.puk_left_times) < 10) {
                        //         AlertUtil.alertMsg(String.format(PROMPT.status.pukTimes, datas.puk_left_times));
                        //     }
                        // } else {
                        //     if (parseInt(datas.pin_left_times) < 3) {
                        //         AlertUtil.alertMsg(String.format(PROMPT.status.pingTimes, datas.pin_left_times));
                        //     }
                        // }
                        if (datas.lock_puk_flag == "1") {
                            vm.isShowPuk = true;
                            vm.isShowPin = false;
                            vm.isShowPinFlag = false;
                        } else {
                            vm.isShowPin = true;
                            vm.isShowPuk = false;
                            // 处于PIN锁定状态
                            if(datas.lock_pin_flag == "1"){
                                vm.isShowPinFlag = false;
                                vm.isShowPuk = false;
                            }
                            else{
                                // PIN是开启状态
                                if (datas.lock_pin_switch == "1") {
                                    vm.isShowPinFlag = true;
                                    vm.changeShow = true;
                                    vm.closedShow = true;
                                    vm.openedShow = false;
                                    vm.optr = "0";
                                    vm.pinStatus = DOC.status.opened;
                                    vm.pinswitch = true;
                                    vm.btnDis1 = false;
                                }else {
                                    // PIN是关闭状态
                                    vm.isShowPinFlag = true;
                                    vm.optr = "1";
                                    vm.changeShow = false;
                                    vm.closedShow = false;
                                    vm.openedShow = true;
                                    vm.pinStatus = DOC.status.closed;
                                    vm.pinswitch = false;
                                    vm.btnDis1 = true;
                                }
                            }
                        }

                    }
                });
            },
            // changePinOper: function () {
            //     // 如果是修改操作
            //     if (vm.optr == "2") {
            //         vm.isShowModifyPin = true;
            //     } else {
            //         vm.isShowModifyPin = false;
            //     }
            // },
            //点击PIN开关
            changePinOper1: function () {
            //   vm.optr = vm.optr == 1 ? 1 : 2;
            // 如果PIN是开启状态点击后修改开关状态
            vm.getData();
            vm.isShowModifyPin =false;
            if($("#pinSwitch").value == 1){
                vm.pinswitch=false;
                vm.openedShow=false;
            }else{
                vm.openedShow=true;
                vm.closedShow=false;

            };
            if($("#pinSwitch").value == 2){
            }
            vm.pinBox=true;
            $mask.show();
            },
            //PIN开启状态下点击修改PIN
            changePinOper2:function (){
                vm.isShowModifyPin = true;
                vm.optr = "2";
                vm.pinBox = true;
                $mask.show();
                $form=$('#pingForm');
                // console.log($form.serializeArray(),"111");
            },
            // 弹出框上方的关闭按钮
            pinboxbtnClose:function(){
                vm.pinBox = false
                $mask.hide();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.QUERY_SIM_STATUS
                    },
                    success: function (datas) {
                        if (datas.lock_pin_switch == "1") {
                            var pinswitch = true;
                        }else
                        {var pinswitch = false;}
                        vm.pinswitch = pinswitch == true ? true:false;
                    }
                 } );
              
            },
            btnSave: function () {
                // location.reload();
                $("#pinBoxClose").click();
                vm.btnDis = true;
                var json = {};
                var $form = $('#pingForm'),
                // 将表单数据转为JSON字符串格式，在helper.js中
                    json = JSON.parmsToJSON($form);
                    // console.log($form.serializeArray(),"1122");
                //PIN验证规则
                var rules1 = {
                        pin: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        }
                    },
                    messages1 = {
                        pin: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        }
                    };
                //修改PIN表单验证规则
                var rules2 = {
                        pin: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        },
                        passwordChange: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        },
                        passwordConfirm: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        }
                    },
                    messages2 = {
                        pin: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        },
                        passwordChange: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        },
                        passwordConfirm: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        }
                    };
                //PUK表单验证规则
                var rules3 = {
                        pukPassword1: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        },
                        pukPinPassword1: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        },
                        pukPinPasswordConfirm1: {
                            required: true,
                            digits: true,
                            rangelength: [4, 8]
                        }
                    },
                    messages3 = {
                        pukPassword1: {
                            required: CHECK.required.puk,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.puk
                        },
                        pukPinPassword1: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        },
                        pukPinPasswordConfirm1: {
                            required: CHECK.required.pinCode,
                            digits: CHECK.format.digits,
                            rangelength: CHECK.rangeLength.pinCode
                        }
                    };
                // 如果处于puk锁定
                if (vm.pukStats == "1") { 
                    if (vm.pukPinPassword != vm.pukPinPasswordConfirm) {
                        AlertUtil.alertMsg(CHECK.required.newPinConfirm2);
                        vm.btnDis = false;
                        vm.pinBox = true;
                        return;
                    };
                    if (!CheckUtil.checkForm($form, rules3, messages3)) {
                        vm.btnDis = false;
                        vm.pinBox = true;
                        return;
                    };
                    var reg = /^\d{4,8}$/;
                    var reg1 =/^\d{8,8}$/;
                    var reg2 = /[^\d]+/;
                //还是解决表单没能成功验证的问题
                        //验证数字格式
                    if(reg2.test(vm.pukPinPassword) || reg2.test(vm.pukPinPasswordConfirm) || reg2.test(vm.pukPassword) ){
                        // console.log("55")
                        $mask.show();
                        AlertUtil.alertMsg(CHECK.format.digits)
                        $mask.show()
                        vm.pinBox =true;
                        vm.btnDis=false;
                        
                        return;
                    }
                    if(!reg1.test(parseInt(vm.pukPassword))){
                        $mask.show();
                        AlertUtil.alertMsg(CHECK.rangeLength.puk);
                        
                        vm.pinBox =true;
                        vm.btnDis=false;
                        return;
                    }
                    // 两PIN长度验证
                    if(!reg.test(parseInt(vm.pukPinPassword)) || !reg.test(parseInt(vm.pukPinPasswordConfirm))){
                        $mask.show()
                        AlertUtil.alertMsg(CHECK.rangeLength.pinCode)
                        
                        vm.pinBox =true;
                        vm.btnDis=false;
                        return;
                    }
                 //表单验证处理结束
                    json.puk = vm.pukPassword;
                    json.pin = vm.pukPinPasswordConfirm;
                    json.subcmd = "3";
                } else {
                    if (vm.pinStats == "1") {
                        if (!CheckUtil.checkForm($form, rules1, messages1)) {
                            vm.btnDis = false;
                            vm.pinBox = true;
                            return;
                        };
                        //PIN码解锁
                        json.subcmd = "2";  
                    } else {
                        //修改PIN码
                        if (vm.optr == "2") { 
                            // 针对PIN修改未进提交表单情况的正则验证规则
                            var reg = /^\d{4,8}$/;
                            var reg2 = /[^\d]+/;

                            if (!CheckUtil.checkForm($form, rules2, messages2))  {
                                vm.btnDis = false;
                                vm.pinBox = true;
                                $mask.show();
                                return;
                            };
                            //针对修改PIN码时表单验证规则不生效的情况。
                                //验证数字格式
                            if(reg2.test(vm.pinPasswordChange) || reg2.test(vm.pinPasswordConfirm) ){
                                $mask.show();
                                AlertUtil.alertMsg(CHECK.format.digits);
                                
                                vm.pinBox =true;
                                vm.btnDis=false;
                                return;
                            }
                            if(!reg.test(parseInt(vm.pinPasswordChange)) || !reg.test(parseInt(vm.pinPasswordConfirm))){
                                $mask.show()
                                AlertUtil.alertMsg(CHECK.rangeLength.pinCode)
                               
                                vm.pinBox =true;
                                vm.btnDis=false;
                                return;
                            }
                            //针对情况结束
                            // 两次PIN不相等情况
                            if (vm.pinPasswordChange != vm.pinPasswordConfirm) {
                                $mask.show();
                                AlertUtil.alertMsg(CHECK.required.newPinConfirm2);
                                vm.btnDis =false ;
                                vm.pinBox = true;
                                
                                return;
                            }
                        
                            json.pinPasswordChange = vm.pinPasswordChange;
                            json.subcmd = "4";
                            json.enable=vm.optr;
                        } else {
                            // 开启PIN码验证
                            if (!CheckUtil.checkForm($form, rules1, messages1)) {
                                vm.btnDis = false;
                                vm.pinBox = true;
                                $mask.show();
                                return;
                            };
                            if(vm.pinswitch){
                                vm.optr="0";
                            }else{
                                vm.optr="1";
                            }
                            json.enable = vm.optr;
                            json.subcmd = "1";
                        }
                    }
                    json.pin = vm.pinPassword;
                }
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.MODEM_CMD;

                //响应处理
                Page.postJSON({
                    json: json,
                    success: function (datas) {
                        if (datas.message == "0") {
                            setTimeout(function () {
                                fyAlertMsgSuccess();
                                vm.pinBox =false;
                                vm.getData();
                            }, 5000);
                        } else {
                            setTimeout(function () {
                                Page.postJSON({
                                    json: {
                                        cmd: RequestCmd.QUERY_SIM_STATUS
                                    },
                                    success:function(data){
                                        if(parseInt(data.pin_left_times) < 1 && parseInt(data.puk_left_times) == 10 ){
                                            location.reload(); 
                                        }else{
                                            fyAlertMsgFail();
                                            vm.pinBox= true;
                                            $mask.show();
                                            setTimeout(function() {
                                                if(parseInt(data.pin_left_times) < 3 && !(data.pin_left_times < 1)){
                                                // fyAlert.destory();
                                                // fyAlertMsgFail(String.format(PROMPT.status.pingTimes, data.pin_left_times));
                                                AlertUtil.alertMsg(String.format(PROMPT.status.pingTimes, data.pin_left_times))
                                                $mask.show();
                                                vm.pinBox=true;
                                                return;
                                            }
                                            // if(parseInt(data.pin_left_times) == 0 && parseInt(data.puk_left_times) < 10 ){
                                            //     // fyAlertMsgFail(String.format(PROMPT.status.pukTimes, data.puk_left_times));
                                            //     // fyAlert.destory();
                                            //     AlertUtil.alertMsg(String.format(PROMPT.status.pukTimes, data.puk_left_times))
                                            //     vm.pinBox= true;
                                            //     vm.isShowPuk= true;
                                            //     $mask.show();
                                            //     return;
                                            // }
                                            vm.getData();
                                            }, 1000);
                                        }
                                    }
                                });
                                
                            }, 5000);
                        }
                        vm.btnDis = false;
                    },
                    error:function(){
                        fyAlertMsgFail();
                        vm.getData();
                    },

                });               
            }
        },
        mounted: function () {
            this.checkSimStatus();
            this.checkPinPukTimes();
            this.getData();
            
        },
    });
});