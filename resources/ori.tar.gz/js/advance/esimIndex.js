$(document).ready(function () {
    var id = "ESIM_MANAGE";
    var items = [];

    items.push({ title: TAB.basic.esimManage, url: 'html/advance/esimManage.html' });
    secondMenuClick(items,id);
});

