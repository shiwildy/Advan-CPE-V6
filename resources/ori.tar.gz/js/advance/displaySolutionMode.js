/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-21 11:03:03
 * @,@LastEditTime: ,: 2020-12-21 14:50:13
 * @,@LastEditors: ,: your name
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\js\advance\displaySolutionMode.js
 */
$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            value:"",
            save: DOC.btn.save,
            disabled:false,
            displaySolution:TAB.basic.displaySolution,
            tableTitle:[TAB.basic.state,TAB.basic.configA,TAB.basic.configB,TAB.basic.configC,TAB.basic.configD],
            tableContent:[
                {title:TAB.basic.state1,content1:'4G',content2:'4G',content3:'4G',content4:'4G'},
                {title:TAB.basic.state2,content1:'4G',content2:'4G',content3:'4G',content4:'5G'},
                {title:TAB.basic.state3,content1:'4G',content2:'4G',content3:'5G',content4:'5G'},
                {title:TAB.basic.state4,content1:'4G',content2:'5G',content3:'5G',content4:'5G'},
                {title:TAB.basic.state5,content1:'5G',content2:'5G',content3:'5G',content4:'5G'},
                {title:TAB.basic.state6,content1:'5G',content2:'5G',content3:'5G',content4:'5G'},
            ],
            list:[
                {
                    value:"A",
                    name:"A"
                },{
                    value:"B",
                    name:"B"
                },{
                    value:"C",
                    name:"C"
                },{
                    value:"D",
                    name:"D"
                }
            ]
        },
        methods: {
            getData:function(){
                 Page.postJSON({
                    json: {
                        cmd: RequestCmd.DISPLAY_SOLUTION_MODE,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.value = datas.buffer || "A";
                    }
                });
            },
            btnSave: function () {
               vm.disabled = true;
                var json={};
                json.cmd = RequestCmd.DISPLAY_SOLUTION_MODE;
                json.method = JSONMethod.POST;
                json.value = this.value;
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.success == true){
                            fyAlertMsgSuccess();
                        }else{
                            fyAlertMsgFail();
                        } 
                    },
                    complete:function(){
                        vm.disabled = false;
                    }
                });
            }
        },
        mounted:function(){
            this.getData();
        }
    })
});