$(document).ready(function () {
    var $mask = $('#mask');
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            AddroutingTable: TAB.route.AddroutingTable,
            btnSetting: networktoolhtml.form5.btnSetting,
            pinCode: TAB.advance.route,
            close: DOC.btn.close,
            status: DOC.lbl.status,
            destinationIp: DOC.net.destinationIp,
            clearAllRules: DOC.btn.clearAllRules,
            colon: DOC.colon,
            mask: DOC.net.mask,
            gateway: DOC.net.gateway,
            savePinOk: DOC.btn.savePinOk,
            tableHead: [DOC.table.rowNo, DOC.lbl.status, networktoolhtml.form2.th1, DOC.net.destinationIp, DOC.net.mask, DOC.net.gateway, DOC.table.edit, dialconfightml.lnsTable.del],
            edixBox: false,
            tableContent: [],
            invalid: DOC.status.invalid,
            valid: DOC.status.validEntry,
            destination: '',
            maskNet: '',
            gatewayValue: '',
            indexRow: '',
            validStatus: "true",
            intername: DOC.lan.intername,
            internameValue: "WAN",
            validValue: "1",
            applyRules: DOC.btn.applyRules,
            isWork: false,
            showTip: false,
            lanIP:""
        },
        methods: {
            clearAllRulesClick:function(){
                if (this.tableContent.length == 0) {
                    this.$message({
                        message: CHECK.tip.filterRlueEmpty,
                        type: 'warning',
                        showClose: true,
                        offset: 200
                    });
                    return false;
                }
                fyConfirmMsg(PROMPT.confirm.clearRules, function () {
                    var json = {};
                    fyAlertMsgLoading();
                    json.method = JSONMethod.POST;
                    json.datas = [];
                    json.success = true;
                    json.cmd = RequestCmd.ROUTER_TABLE;
                    Page.postJSON({
                        json: json,
                        success: function (data) {
                            vm.showTip = false;
                            if (data.success == true) {
                                Page.applyFilter();
                                vm.getDate();
                            } else {
                                fyAlertMsgFail();
                                vm.getDate();
                            }
                        }
                    });
                })
            },
            getLanIP: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LAN_INFO
                    },
                    success: function (data) {
                        vm.lanIP = data.lan_ip
                    }
                })
            },

            getDate: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ROUTER_TABLE,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        if (datas.datas) {
                            vm.tableContent = datas.datas;
                        }

                    }
                });
            },
            btnAddRoute: function () {
                this.edixBox = true;
                $mask.show();
                this.validValue = "1";
                this.internameValue = "WAN";
                this.maskNet = "";
                this.destination = "";
                this.gatewayValue = "";
            },
            btnSavePin: function () {
                if (this.destination == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (this.maskNet == "") {
                    AlertUtil.alertMsg(CHECK.required.netmask);
                    return false;
                }
                if (this.gatewayValue == "") {
                    AlertUtil.alertMsg(CHECK.required.gateway);
                    return false;
                }
                if (!CheckUtil.checkIp(this.destination)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                if (!CheckUtil.checkMask(this.maskNet)) {
                    AlertUtil.alertMsg(CHECK.format.netmask);
                    return false;
                }
                if (!CheckUtil.checkIp(this.gatewayValue)) {
                    AlertUtil.alertMsg(CHECK.format.gateway);
                    return false;
                }
                var res1 = [], res2 = [];
                addr1 = this.lanIP.split(".");
                addr2 = this.destination.split(".");
                mask  = this.maskNet.split(".");
                for(var i = 0,ilen = addr1.length; i < ilen ; i += 1){
                    res1.push(parseInt(addr1[i]) & parseInt(mask[i]));
                    res2.push(parseInt(addr2[i]) & parseInt(mask[i]));
                }
                if(res1.join(".") == res2.join(".")){
                    AlertUtil.alertMsg(CHECK.format.destination);
                    return false
                }
                var item = {};
                item.valid = this.validValue == "1" ? true : false;
                item.ifName = this.internameValue;
                item.netmask = this.maskNet;
                item.ip = this.destination;
                item.netmaskBits = FormatUtil.formatMaskBit(this.maskNet);
                item.gateway = this.gatewayValue;
                if( typeof this.indexRow === "number"){
                    this.$set(this.tableContent, this.indexRow, item);
                } else {
                    this.tableContent.push(item);
                }
                this.edixBox = false;
                $mask.hide();
                this.showTip = false;
                this.$nextTick(function () {
                    this.showTip = true;
                });
            },
            btnSaveRoute: function () {
                var json = {};
                fyAlertMsgLoading();
                json.method = JSONMethod.POST;
                json.datas = this.tableContent;
                json.success = true;
                json.cmd = RequestCmd.ROUTER_TABLE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.showTip = false;
                        if (data.success == true) {
                            Page.applyFilter();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            btnClose: function () {
                $mask.hide();
                this.edixBox = false;
                this.indexRow = '';
            },
            routeEdit: function (index) {
                $mask.show();
                this.edixBox = true;
                this.validValue = this.tableContent[index].valid ? "1" : "0";
                this.internameValue = this.tableContent[index].ifName;
                this.maskNet = this.tableContent[index].netmask;
                this.destination = this.tableContent[index].ip;
                this.gatewayValue = this.tableContent[index].gateway;
                this.indexRow = index;
            },
            routeDel: function (index) {
                fyConfirmMsg(PROMPT.confirm.deleteContent, function () {
                    vm.tableContent.splice(index, 1);
                    vm.showTip = false;
                    vm.$nextTick(function () {
                        vm.showTip = true;
                    });
                });
            },
            validText: function (event) {
                if (event == true) {
                    return this.valid;
                } else {
                    return this.invalid;
                }
            }
        },
        computed:{
            interList:function(){
                var arr = [];
                if(Page.pageHideCheck(45)&&!Page.pageHideCheck(80)){
                    arr = ["WAN", "LAN", "GRE"]
                }else if(Page.pageHideCheck(80) && !Page.pageHideCheck(45)){
                    arr = ["WAN", "LAN", "PPP"]
                }else if(Page.pageHideCheck(45) && Page.pageHideCheck(80)){
                    arr = ["WAN", "LAN", "PPP","GRE"]
                }else{
                    arr = ["WAN", "LAN"]
                }
                return arr;
            }
        },
        mounted: function(){
            this.getDate();
            this.getLanIP();
        }
    });
});