$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm2(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            onenetSwitch:DOC.tr069.onenetSwitch,
            colon:DOC.colon,
            disabled:false,
            btn_save: DOC.btn.save,
            onenetEnabled:false,
            enable: DOC.status.enable,
            disable: DOC.status.disable
        },
        methods:{
            getData:function(){
                 Page.postJSON({
                    json: { cmd: RequestCmd.ONENET_SETTING,methods:JSONMethod.GET},
                    success:function(data){
                        vm.onenetEnabled = data.onenet == "1" ? true : false;
                    }
                })
           },
           clickBtnSave:function(){
             this.disabled = true;
                
                fyAlertMsgLoading();
                var json = {};
                // json.apn = vm.apn;
                json.onenet = vm.onenetEnabled ? "1" : "0";
               
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.ONENET_SETTING;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.disabled = false;
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                })
           }
        },
        mounted:function(){
            this.getData()
        }
        
    });
});