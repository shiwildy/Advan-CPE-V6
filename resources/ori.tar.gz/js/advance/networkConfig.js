$(document).ready(function () {
    var fm = ["networkForm", "child_container", "networkFormId"];
    var vm = new Vue({
        el: "#child_container",
        data: {
            colon: DOC.colon,
            classOperation: false,
            dataSwitchValue: false,
            roamingEnableVal: false
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORKSET_MODE,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if (data.mode5g == "0" && data.networkMode == "131") {
                            vm.networkModeValue = "333";
                        } else {
                            vm.networkModeValue = data.networkMode;
                        }
                        vm.dataSwitchValue = data.dialMode == "1" ? true : false;
                        vm.roamingEnableVal = data.roamingEnable == "1" ? true : false;
                        vm.classOperation = data.flightMode == "1" ? true : false;
                    }
                });
            },
            dataSwitchClick: function () {
                fyAlertMsgLoading();
                var json = {};
                json.dialMode = this.dataSwitchValue ? "1" : "0";
                json.cmd = RequestCmd.AUTO_DIAL;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            roaminSave: function () {
                var json = {};
                fyAlertMsgLoading();
                json.roamingEnable = this.roamingEnableVal ? "1" : "0";
                json.cmd = RequestCmd.DATA_ROAMING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            flightSave: function () {
                var json = {};
                fyAlertMsgLoading();
                json.flightMode = this.classOperation ? "1" : "0";
                json.cmd = RequestCmd.FLIGHT_MODE_INFO;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
        }
    });
});