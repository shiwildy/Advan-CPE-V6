$(document).ready(function () {
    var id = "NETWORK_SET";
    var items = [];

    // items.push({ title: DOC.lbl.netMode, url: 'html/advance/networkSet.html' });
    items.push({ title: DOC.lbl.netSetting, url: 'html/advance/networkConfig.html' });
    if(Page.pageHideCheck(44)){
        items.push({ title: "PLMN "+ DOC.lbl.plmnscan, url: 'html/advance/sccan_plmn.html' });
    }
    if ( Page.pageHideCheck(50) ){
        items.push({ title: DOC.lbl.wiredWanSetting, url: 'html/advance/wiredSetting.html' });
    }
    if ( Page.pageHideCheck(52) ){
        items.push({ title: DOC.net.networkChange, url: 'html/advance/netChange.html' });
    }
    secondMenuClick(items,id);
});

