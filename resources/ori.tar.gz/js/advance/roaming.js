$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            // roamingEnableVal: "dataSwitchOff",
            roamingEnableVal:false,
            dataRoaming: TAB.advance.dataRoaming,
            colon: DOC.colon,
        },
        methods: {
            btnSave: function () {
                var json = {};
                fyAlertMsgLoading();
                json.roamingEnable = this.roamingEnableVal ? "1" : "0";
                json.cmd = RequestCmd.DATA_ROAMING;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                            vm.getData();
                        } else {
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DATA_ROAMING,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        vm.roamingEnableVal = data.roamingEnable == "1" ? true : false;
                    }
                });
            }
        },
        mounted: function () {
            this.getData();
        }
    })
});