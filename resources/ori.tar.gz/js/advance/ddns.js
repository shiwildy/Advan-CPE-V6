$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
 //在JQ validate插件中为表单添加添加自定义的验证规则
 jQuery.validator.addMethod("checkchar", function(value, element) {
    return this.optional(element) || (CheckUtil.checkAPNName(value));
    }, "");
var rules = {
        username: {
            required: true,
            checkchar:true,
            rangelength:[2,20]
        },
        password: {
            required: true,
            checkchar:true,
            rangelength:[3,63]
        },
        hostname: {
            required: true,
            checkchar:true,
            rangelength:[1,100]
        }
    },
    messages = {
        username: {
            required: CHECK.format.username,
           checkchar:CHECK.format.formatError,
           rangelength:CHECK.range.username
        },
        password: {
            required: CHECK.format.password,
            checkchar:CHECK.format.formatError,
            rangelength:CHECK.range.passwd
        },
        hostname: {
            required: CHECK.format.hostname,
            checkchar:CHECK.format.formatError,
            rangelength: CHECK.format.formatError 
        }
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            ddnsSwitch: false,
            userName: "",
            password: "",
            status: "",
            ddnsDynamicServer: "no-ip",
            ddnsDomain: "",
            ddnsStatus: TAB.advance.ddnsStatus + DOC.colon,
            ddnsDomain1: TAB.advance.ddnsDomain + DOC.colon,
            ddnsIsShowPassword1: TAB.advance.ddnsIsShowPassword,
            ddnsUsername: TAB.advance.ddnsUsername + DOC.colon,
            ddnsPassword: TAB.advance.ddnsPassword + DOC.colon,
            ddnsStart: TAB.advance.ddnsStart,
            ddnsDynamicServer1: TAB.advance.ddnsDynamicServer + DOC.colon,
            ddnsStop: TAB.advance.ddnsStop,
            ddns: TAB.advance.ddns + DOC.colon,
            save: DOC.btn.save,
            disabled: false,
            list: ["no-ip", "changeip", "dyndns", "duckdns"],
            helpInfo: [{
                title: TAB.advance.ddnsDynamicServer,
                item: TAB.advance.ddnsDynamicServerInfo
            },
            {
                title: TAB.advance.ddnsUsername,
                item: TAB.advance.ddnsUsernameInfo
            },
            {
                title: TAB.advance.ddnsPassword,
                item: TAB.advance.ddnsPasswordInfo
            },
            {
                title: TAB.advance.ddnsDomain,
                item: TAB.advance.ddnsDomainInfo
            }
        ]
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.DDNS_DATA,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.userName = datas.username;
                        vm.password = datas.password;
                        vm.ddnsDynamicServer = datas.service || "noip";
                        vm.ddnsSwitch = datas.enable == "1" ? true : false;
                        vm.ddnsDomain = datas.hostname;
                        switch (datas.status) {
                            case 'Connected': 
                                vm.status = DOC.status.connected;
                                break;
                            case 'Connecting': 
                                vm.status = DOC.status.connecting;
                                break;
                            default:
                                vm.status = DOC.status.disconnected;
                        }
                    }
                });
            },
            btnSave: function () {
                this.disabled = true;
                var $form = $('#childForm');
                var json = {};
                json.cmd = RequestCmd.DDNS_DATA;
                json.method = JSONMethod.POST;
                if (this.ddnsSwitch) {
                    if (!CheckUtil.checkForm($form, rules, messages)) {
                        this.disabled = false;
                        return false;
                    }
                    json.enable = "1";
                    json.service = this.ddnsDynamicServer;
                    json.username = this.userName;
                    json.password = this.password;
                    json.hostname = this.ddnsDomain
                } else {
                    json.enable = "0";
                }
                fyAlertMsgLoading();
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            fyAlertMsgSuccess();
                        } else {
                            fyAlertMsgFail();
                        }
                        vm.disabled = false;
                    }
                });
            }
        },
        mounted: function () {
            Page.createForm(fm);
            this.getData();
        }
    })
});