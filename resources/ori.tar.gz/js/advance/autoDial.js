$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var vm = new Vue({
        el: "#child_container",
        data: {
            // dataSwitchValue: '0',
            dataSwitchValue:false,
            save: DOC.btn.save,
            autoMode: TAB.advance.autoMode,
            disabled: false,
            dataSwitch:TAB.advance.dataSwitch,
            connect:false,
            disconnect:false,
            isShowConnect:false,
            operation:TAB.advance.manualDataSwitch,
            connect2:TAB.advance.connect,
            disconnect2:TAB.advance.disconnect,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            colon: DOC.colon,
            classOperation:"",
            classDataSwitchValue:"dataSwitchOff",
            flag:"0"
        },
        methods: {
            btnSave: function () {
                this.disabled = true;
                fyAlertMsgLoading();
                var json = new Object();
                json.dialMode = this.dataSwitchValue
                json.cmd = RequestCmd.AUTO_DIAL;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            fyAlertMsgSuccess();
                            vm.getData();
                        }else{
                            fyAlertMsgFail();
                        }
                        vm.disabled = false;
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.AUTO_DIAL,
                        method:JSONMethod.GET
                    },
                    success: function (data) {
                        vm.dataSwitchValue = data.dialMode == "1" ? true : false;
                        vm.connect = data.data_switch == "0" ? false : true;
                        vm.disconnect = data.data_switch == "1" ? false : true;
                        vm.classOperation = data.data_switch == "1" ? "dataSwitchOn" : "dataSwitchOff";
                        vm.classDataSwitchValue = data.dialMode == "1" ? "dataSwitchOn" : "dataSwitchOff";
                        vm.flag = data.data_switch == "1" ? "1" :"0";
                        if(data.dialMode == "1" || !data.data_switch){
                            vm.isShowConnect = false;
                        }else{
                            vm.isShowConnect = true;
                        }
                        
                    }
                });
            },
            getData2: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.AUTO_DIAL,
                        method:JSONMethod.GET
                    },
                    success: function (data) {
                        vm.connect = data.data_switch == "0" ? false : true;
                        vm.disconnect = data.data_switch == "1" ? false : true;
                        vm.classOperation = data.data_switch == "1" ? "dataSwitchOn" : "dataSwitchOff";
                        vm.flag = data.data_switch == "1" ? "1" :"0";
                    }
                });
            },
            clickConnect:function(){
                vm.connect = true;
                _clearInterval();
                fyAlertMsgLoading();
                var json = new Object();
                json.apn_num = "1";
                json.cmdtype = "1";
                json.cmd = RequestCmd.DATA_SWITCH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            Page.timer = setInterval(function(){
                                vm.getData2();
                            },1000);
                            
                            fyAlertMsgSuccess();
                        }else{
                             vm.connect = false;
                            fyAlertMsgFail();
                        }
                    }
                });
            },
            clickOperation:function(){
                vm.disconnect = true;
                 _clearInterval();
                 fyAlertMsgLoading();
                var json = new Object();
                json.apn_num = "1";
                json.cmdtype = this.flag == "1" ? "0" : "1";
                json.cmd = RequestCmd.DATA_SWITCH;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            Page.timer = setInterval(function(){
                                vm.getData2();
                            },1000);
                            fyAlertMsgSuccess();
                           
                        }else{
                            vm.disconnect = false;
                           fyAlertMsgFail();
                        }
                    }
                });
            },
            dataSwitchClick:function(){
                this.disabled = true;
                fyAlertMsgLoading();
                var json = new Object();
                json.dialMode = this.dataSwitchValue ? "1" : "0";
                json.cmd = RequestCmd.AUTO_DIAL;
                json.method = JSONMethod.POST;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            fyAlertMsgSuccess();
                            vm.getData();
                        }else{
                            fyAlertMsgFail();
                        }
                        vm.disabled = false;
                    }
                });
            }
        },
        mounted:function(){
            this.getData();
             Page.timer = setInterval(function(){
                vm.getData2();
            },3000);
        }
    })
});