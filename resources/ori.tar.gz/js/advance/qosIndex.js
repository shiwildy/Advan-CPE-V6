$(document).ready(function () {
    var id = "QoS_CONFIG";
    var items = [];

    items.push({ title: DOC.lbl.globalSetting, url: 'html/advance/globalSetting.html' });
    items.push({ title: DOC.lbl.rulesSetting, url: 'html/advance/rulesSetting.html' });
    secondMenuClick(items,id);
});

