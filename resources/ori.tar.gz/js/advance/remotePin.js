$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
    Page.createForm(fm);
    var $mask = $('#mask');
    var vm = new Vue({
        el: "#reContent",
        data: {
            pingRemote: DOC.lbl.pingRemote,
            colon: DOC.colon,
            pingRemoteIp: DOC.lbl.pingRemoteIp,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            addRemoteIp: DOC.lbl.addRemoteIp,
            save: DOC.btn.save,
            close: DOC.btn.close,
            example: DOC.lbl.example,
            remoteIp: DOC.lbl.remoteIp,
            btnDis: false,
            enableRemoteLogin: false,
            edit: dialconfightml.lnsTable.edit,
            del: dialconfightml.lnsTable.del,
            ipList: [],
            editBox: false,
            btnSaveDis: false,
            btnEditDis: false,
            edit_title: '',
            ipItem: '',
            rowFlag: 0
        },
        methods: {
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.GET_PING_LIST,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.enableRemoteLogin = datas.pingFlag == "1" ? true : false;
                        var list = datas.datas;
                        for (var i = 0; i < list.length; i++) {
                            if (list[i] != "") {
                                vm.ipList.push(list[i]);
                            }
                        }
                    }
                })
            },
            btnSave: function () {
                this.btnDis = true;
                var json = {};
                if (this.ipList.length > 0) {
                    json.datas = this.ipList;
                } else json.datas = [];
                json.pingFlag = this.enableRemoteLogin ? "1" : "0";
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.GET_PING_LIST;
                json.success = true;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.success==true){
                            Page.postJSON({
                                json: {
                                    cmd: RequestCmd.APPLY_FILTER,
                                    method: JSONMethod.POST
                                },
                                success: function (data) {
                                    if (data.success == true) {
                                        AlertUtil.alertMsg(PROMPT.saving.success);
                                    } else {
                                        fyAlertMsgFail();
                                    }
                                }
                            });
                        } else {
                            fyAlertMsgFail();
                        }
                    },
                    complete: function () {
                        vm.btnDis = false;
                    }
                });
            },
            btnAdd: function () {
                $mask.show();
                this.editBox = true;
                this.btnSaveDis = true;
                this.btnEditDis = false;
                this.ipItem = '';
                this.edit_title = DOC.table.add + DOC.lbl.remoteIp;
                // SysUtil.setBoxStyle1($("#edit_box"));
            },
            btnClose: function () {
                this.editBox = false;
                $mask.hide();
                this.ipItem = '';
            },
            ipDel: function (index) {
                this.ipList.splice(index, 1);
            },
            ipEdit: function (index) {
                $mask.show();
                this.editBox = true;
                this.btnSaveDis = false;
                this.btnEditDis = true;
                this.edit_title = DOC.table.edit + DOC.lbl.remoteIp;
                // SysUtil.setBoxStyle1($("#edit_box"));
                this.ipItem = this.ipList[index].ip;
                this.rowFlag = index;
            },
            btnSaveIp: function () {
                if (this.ipItem == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.ipItem)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                this.ipList.push({ip:this.ipItem})
                this.editBox = false;
                $mask.hide();
                this.ipItem = '';
            },
            btnEditIp: function () {
                if (this.ipItem == "") {
                    AlertUtil.alertMsg(CHECK.required.ip);
                    return false;
                }
                if (!CheckUtil.checkIp(this.ipItem)) {
                    AlertUtil.alertMsg(CHECK.format.ip);
                    return false;
                }
                this.$set(this.ipList, this.rowFlag, {ip:this.ipItem});
                this.editBox = false;
                $mask.hide();
                this.ipItem = '';
            }
        },
        mounted: function(){
            Page.createForm2(fm);
        }
    });
    vm.getData();
});