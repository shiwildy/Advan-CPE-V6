$(document).ready(function () {
    var fm = ["childForm", "child_container", "childFormId"];
   //在JQ validate插件中为表单添加添加自定义的验证规则  
   jQuery.validator.addMethod("checkchar", function(value, element) {
    return this.optional(element) || ( CheckUtil.checkAPNName(value));
    }, "");
    var rules = {
        url: { required: true, url: true },
        noticeInterval: { required: true, number: true, min: 30,digits: true },
        connectionRequestPort: {required: true,  digits: true, range: [1025, 65535] },
        userName:{required: true, checkchar:true, rangelength:[2,20]},
        passwd:{required: true, checkchar:true, rangelength:[3,63]},
        linkUserName:{required: true, checkchar:true, rangelength:[2,20]},
        linkPasswd:{required: true, checkchar:true, rangelength:[3,63]}
    }, messages = {
        url: { required: CHECK.required.url, url: CHECK.format.url },
        noticeInterval: { required:CHECK.required.noticeInterval,number: CHECK.format.inputNumber, min: CHECK.min.noticeInterval, digits: CHECK.format.digits },
        connectionRequestPort: {required: CHECK.format.formatError,  digits: CHECK.format.digits, range: CHECK.range.connectionRequestPort },
        userName:{required: CHECK.format.formatError, checkchar:CHECK.format.formatError, rangelength:CHECK.range.username},
        passwd:{required: CHECK.format.formatError, checkchar:CHECK.format.formatError, rangelength:CHECK.range.passwd},
        linkUserName:{required: CHECK.format.formatError, checkchar:CHECK.format.formatError, rangelength:CHECK.range.username},
        linkPasswd:{required: CHECK.format.formatError, checkchar:CHECK.format.formatError, rangelength:CHECK.range.passwd}
    };
    var vm = new Vue({
        el: "#child_container",
        data: {
            tr069_connection: DOC.tr069.connectionStatus,
            connected_ok: DOC.tr069.connected,
            connected_fail: DOC.tr069.disconnect,
            tr069_enable: DOC.tr069.enable,
            colon: DOC.colon,
            enable: DOC.status.enable,
            disable: DOC.status.disable,
            tr069_apn: DOC.tr069.apn,
            apn_option: [
                { name: DOC.tr069.mainApn, value: "apn" }
                // { name: DOC.tr069.apn1, value: "apn1" },
                // { name: DOC.tr069.apn2, value: "apn2" },
                // { name: DOC.tr069.apn3, value: "apn3" },
            ],
            tr069_url: DOC.tr069.url,
            enableNotice: DOC.tr069.enableNotice,
            tr069_noticeInterval: DOC.tr069.noticeInterval,
            second: DOC.unit.second,
            tr069_connectionRequestPort: DOC.tr069.connectionRequestPort,
            connectionRequestPportortRange: DOC.tr069.connectionRequestPortRange,
            tr069_connectionRequestAuth: DOC.tr069.connectionRequestAuth,
            digest: DOC.tr069.digest,
            configuration:DOC.tr069.configuration,
            enableAcsAuth: DOC.tr069.enableAcsAuth,
            tr069_acsUsername: DOC.tr069.acsUsername,
            tr069_acsPasswd: DOC.tr069.acsPasswd,
            enableCpeAuth: DOC.tr069.enableCpeAuth,
            cpeUsername: DOC.tr069.cpeUsername,
            cpePasswd: DOC.tr069.cpePasswd,
            btn_save: DOC.btn.save,
            tr069_status:DOC.tr069.status,
            tr069_auth_type:DOC.tr069.authType,
            help_text: [
                { title: DOC.tr069helper.title11, name: DOC.tr069helper.name11 },
                { title: DOC.tr069helper.title1, name: DOC.tr069helper.name1 },
                { title: DOC.tr069helper.title2, name: DOC.tr069helper.name2 },
                { title: DOC.tr069helper.title3, name: DOC.tr069helper.name3 },
                { title: DOC.tr069helper.title4, name: DOC.tr069helper.name4 },
                { title: DOC.tr069helper.title5, name: DOC.tr069helper.name5 },
                { title: DOC.tr069helper.title6, name: DOC.tr069helper.name6 },
                { title: DOC.tr069helper.title7, name: DOC.tr069helper.name7 },
                { title: DOC.tr069helper.title8, name: DOC.tr069helper.name8 },
                { title: DOC.tr069helper.title9, name: DOC.tr069helper.name9 },
                { title: DOC.tr069helper.title10, name: DOC.tr069helper.name10 }
            ],
            connectedEnabled: '',
            apn: '',
            url: '',
            noticeEnabled: false,
            noticeInterval: '',
            connectionRequestPort: '',
            acsAuthEnabled: false,
            userName: '',
            passwd: '',
            cpeAuthEnabled: false,
            linkUserName: '',
            linkPasswd: '',
            disabled: false,
            ConfigurationDefault:"Production",
            select_switch:"y",
            tr069_object:{},
            configuration_default:false,
            tr069_slab_object:{},
            isShowTR069:false,
            oldDatas: {},
            apnSetting:DOC.apn.setting,
            apn:"apn",
            tr069Status:DOC.status.disconnected,
            tr069AuthType:"None",
            enabled :false
        },
        methods:{
            getData:function(){
                 Page.postJSON({
                    json: { cmd: RequestCmd.TR069_CONFIG,methods:JSONMethod.GET},
                    success:function(data){
                        vm.enabled = data.enabled == "1" ? true : false;
                        vm.url = data.url;
                        vm.noticeEnabled = data.noticeEnabled == "1" ? true : false;
                        vm.noticeInterval = data.noticeInterval;
                        vm.acsAuthEnabled = data.acsAuthEnabled == "1" ? true : false;
                        vm.userName = data.userName;
                        vm.passwd = data.passwd;
                        vm.cpeAuthEnabled = data.cpeAuthEnabled == "1" ? true : false;
                        vm.linkUserName = data.linkUserName;
                        vm.linkPasswd = data.linkPasswd;
                        if(!vm.enabled)
                        {
                            vm.tr069Status = DOC.status.disconnected;
                        }else
                        {
                            vm.tr069Status = data.tr069_connect_status == "connected" ? DOC.status.connected : DOC.status.disconnected;
                        }
                        vm.tr069AuthType = data.tr069_auth_type == "" ? "None" :  data.tr069_auth_type;
                        // vm.apn = data.apn;
                        vm.connectionRequestPort = data.connectionRequestPort;
                    }
                })
           },
           clickBtnSave:function(){
             this.butAble = true;
                var $form = $("#childForm");
                if (!CheckUtil.checkForm($form, rules, messages)) {
                    this.butAble = false;
                    return;
                }
                fyAlertMsgLoading();
                var json = {};
                json.enabled = vm.enabled ? "1" : "0";
                json.url = vm.url;
                // json.apn = vm.apn;
                json.noticeEnabled = vm.noticeEnabled ? "1" : "0";
                json.noticeInterval = vm.noticeInterval;
                json.acsAuthEnabled = vm.acsAuthEnabled ? "1" : "0";
                json.userName = vm.userName;
                json.passwd = vm.passwd;
                json.cpeAuthEnabled = vm.cpeAuthEnabled ? "1" : "0";
                json.linkUserName = vm.linkUserName;
                json.linkPasswd = vm.linkPasswd;
                json.connectionRequestPort = vm.connectionRequestPort;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.TR069_CONFIG;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.butAble = false;
                        if (data.success == true) {
                            vm.getData();
                            fyAlertMsgSuccess();
                        }else{
                            fyAlertMsgFail();
                        }
                    }
                })
           }
        },
        mounted:function(){
            Page.createForm2(fm);
            this.getData();
        }
        
    });
});