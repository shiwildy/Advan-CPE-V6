/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-09 19:08:48
 * @,@LastEditTime: ,: 2021-03-04 15:49:05
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\loginIndex.js
 */
$(function () {
    // if(IsPC()){
    //     window.location.href = Page.getUrl("/login.html");
    // }
  
    var vm = new Vue({
        el:"#login-index",
        data:{
                title:DOC.title.lteInfoBasic,
                title11:DOC.device.imsi,
                title12:DOC.device.imei,
                title13:DOC.lte.phyCellId,
                title14:DOC.lte.sinr,
                title15:DOC.lte.rsrp,
                title16:DOC.lte.rssi,
                title17:DOC.lbl.freqPoint,
                title18:DOC.lte.rsrq,

                title2:DOC.title.wan,
                title21:DOC.net.ip,
                title22:DOC.device.wanMac,
                title23:DOC.net.dns1,
                title24:DOC.net.dns2,
                title25:DOC.net.ipv6,
                title26:DOC.net.gatewayv6,
                title27:DOC.net.dns3,
                title28:DOC.net.dns4,

                title3:DOC.title.router,
                title31:DOC.info.runningTime,
                title32:DOC.device.firmwareVersion,
                selecLanguage:DOC.login.language,
                loginLang:DOC.btn.login,
                user:DOC.apn.user,
                passwordLang:DOC.apn.password,
                usernameCheck:CHECK.format.username,
                passwordCheck:CHECK.format.password,
                attempts:CHECK.format.attempts,
                accountLock:CHECK.format.accountLock1,
                showLogin:false,
                username: '',
                password: '',
                value:1,
                language:"中文",
                activeName: ['1','2','3'],
                wanInfo:{},
                wanInternet:{},
                systenInfo:{},
                show:false,
                languageSelectList:[],
                languageSelectValue:"",
                flag:false,
                selectIndex:"",
                checkbox:false,
                isPass:true,
                type:"password",
                logo:"",
                token:""
        },
        methods:{
            showPass(){
                vm.isPass = !vm.isPass;
                vm.type = vm.isPass?"password":"text";
            },
            selectLang(){
                this.show = false
            },
            openLang(){
                this.show = true;
                this.selectIndex = this.getIndex;
            },
            getNextText: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
                        method: JSONMethod.GET,
                        sessionId: ""
                    },
                    success: function (data) {
                        vm.token = data.token;
                    }
                })
            },
            changeLanguageSelect: function (item) {
                vm.show = false
				Page.postJSON({
					json: {
						cmd: RequestCmd.CHANGE_LANGUAGE,
						method: JSONMethod.POST,
						sessionId: "",
						languageSelect: item.value
					},
					success: function (data) {
                        var href = location.href;
						if (href.indexOf('#') > -1) {
							href = href.substring(0, href.indexOf('#'));
						}
						if (href.indexOf('?') > -1) {
							href = href.substring(0, href.indexOf('?'));
                        }
                        location.href = Page.getUrl(href);
                        // getCurrentLanguage()
                    },
					complete: function () {
						
                        // location.href = Page.getUrl(href);
                       
					}
				});
            },
           
            getLanguageList(){
                this.languageSelectList = []
                Page.postJSON({
                json: {
                    cmd: RequestCmd.INIT_PAGE
                },
                success: function (data) {
                    var language = data.language.toUpperCase();
                    vm.logo = "../../images/"+data.web_logo_path
                    var supportLanguage = []
                    if (data.language_support) {
                        supportLanguage = parseInt(data.language_support, 16).toString(2).split("").reverse();
                        for (var i = 0; i < supportLanguage.length; i++) {
                            if (supportLanguage[i] == "1") {
                                vm.languageSelectList.push(Page.getSupportlanguageList[i])
                            }
                        }
                    } else {
                        vm.languageSelectList = Page.getSupportlanguageList;
                    }
                    
                    vm.languageSelectList.forEach(function (item) {
                        item.text = item.name
                        delete item.name
                    })
                }
            });
            },
            getRouterInfo() {
                Page.postJSON({
                    json: { cmd: RequestCmd.ROUTER_INFO },
                    success: function(routerInfo) {
                        var loading = "-"
                        var PCI = (routerInfo.PCI || loading)+"/"+(routerInfo.PCI_5G || loading),
                        SINR = (routerInfo.SINR? (routerInfo.SINR+'dB') : loading)+"/"+(routerInfo.SINR_5G? (routerInfo.SINR_5G+'dB') : loading),
                        RSRP = (routerInfo.RSRP ? (routerInfo.RSRP+'dBm') : loading)+"/"+(routerInfo.RSRP_5G ? (routerInfo.RSRP_5G+'dBm') : loading),
                        RSSI = (routerInfo.RSSI ? FormatUtil.formatField(routerInfo.RSSI,'dBm') : loading) + "/" + (routerInfo.RSSI_5G ? FormatUtil.formatField(routerInfo.RSSI_5G, 'dBm') : loading),
                        FREQ = (routerInfo.FREQ ? routerInfo.FREQ : loading) +"/"+(routerInfo.FREQ_5G ? routerInfo.FREQ_5G : loading),
                        RSRQ = (routerInfo.RSRQ ? (routerInfo.RSRQ+'dB') : loading)+"/"+(routerInfo.RSRQ_5G ? (routerInfo.RSRQ_5G+'dB') : loading),
                        IP = FormatUtil.formatField(routerInfo.wan_ip || loading),
                        MAC = FormatUtil.formatField(routerInfo.wan_mac || loading),
                        DNS1 = FormatUtil.formatField(routerInfo.wan_dns || loading),
                        DNS2 = FormatUtil.formatField(routerInfo.wan_dns2 || loading),
                        IPV6 = FormatUtil.formatField(routerInfo.wan_ipv6_ip || loading),
                        IPV6WG = FormatUtil.formatField(routerInfo.wan_ipv6_gateway || loading),
                        IPV6DNS1 = FormatUtil.formatField(routerInfo.wan_ipv6_dns || loading),
                        IPV6DNS2 = FormatUtil.formatField(routerInfo.wan_ipv6_dns2 || loading),
                        RUNTIME,
                        VERSION
                        if(routerInfo.uptime){
                            RUNTIME = ConvertUtil.parseUptime2(routerInfo.uptime) || loading;
                        }else{
                            RUNTIME = loading;
                        }
                        if(routerInfo.fake_version){
                            VERSION = FormatUtil.formatField(routerInfo.fake_version) || loading;
                        }else{
                            VERSION = FormatUtil.formatField(loading);
                        }
                        
                        vm.$set(vm.wanInfo,vm.title11,routerInfo.IMSI || loading)
                        vm.$set(vm.wanInfo,vm.title12,routerInfo.module_imei || loading)
                        vm.$set(vm.wanInfo,vm.title13,PCI)
                        vm.$set(vm.wanInfo,vm.title14,SINR)
                        vm.$set(vm.wanInfo,vm.title15,RSRP)
                        vm.$set(vm.wanInfo,vm.title16,RSSI)
                        vm.$set(vm.wanInfo,vm.title17,FREQ)
                        vm.$set(vm.wanInfo,vm.title18,RSRQ)

                        vm.$set(vm.wanInternet,vm.title21,IP)
                        vm.$set(vm.wanInternet,vm.title22,MAC)
                        vm.$set(vm.wanInternet,vm.title23,DNS1)
                        vm.$set(vm.wanInternet,vm.title24,DNS2)
                        vm.$set(vm.wanInternet,vm.title25,IPV6)
                        vm.$set(vm.wanInternet,vm.title27,IPV6DNS1)
                        vm.$set(vm.wanInternet,vm.title28,IPV6DNS2)

                        vm.$set(vm.systenInfo,vm.title31,RUNTIME)
                        vm.$set(vm.systenInfo,vm.title32,VERSION)

                        
                    },
                    fail: function() {
                        // getLteInfo(theRouterInfo);
                    },
                    error: function() {
                        // getLteInfo(theRouterInfo);
                    }
                });
                // sessionStorage['canLogin'] = "";
            },
            toLogin(){
                this.showLogin = true
            },
            onSubmit(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.LOGIN,
                        method: JSONMethod.POST,
                        sessionId: vm.getSessionId(),
                        username: this.username,
                        passwd: sha256_digest(this.token+this.password),
                        isAutoUpgrade: vm.autoUpgrade ? "1" : "0"
                    },
                    success: function (data) {
                        if (data.login_fail == "fail") {
                            vm.flag = true //登录失败标记
                            sessionStorage.setItem("login_times",data.login_times)
                            vm.showLogin = false
                            var mes = vm.attempts+data.login_times.toString()
                            vant.Dialog.alert({
                                message: mes,
                              }).then(() => {
                                if (parseInt(data.login_times, 10) < 1) {
                                    loginTimer = setInterval(function () {
                                        Page.postJSON({
                                            json: {
                                                cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
                                                method: JSONMethod.GET,
                                                sessionId: ""
                                            },
                                            success: function (data) {
                                                
                                                const mes = vm.accountLock+'180s'
                                                const toast = vant.Toast.loading({
                                                    duration: 0, // 持续展示 toast
                                                    forbidClick: true,
                                                    message: mes,
                                                  });
                                                  
                                                  let second = 180  - data.netx_login_time;
                                                    if (second>0) {
                                                      toast.message = vm.accountLock+second+'s';
                                                    } else {
                                                      clearInterval(loginTimer);
                                                      // 手动清除 Toast
                                                      vant.Toast.clear();
                                                    }
                                            }
                                        })
                                    }, 1000)
                                }
                                return
                                // on close
                              });
                            
                        } else {
                            sessionStorage.setItem("login_times",3)
                            loginSuccess = data.success;
                            sessionStorage['sessionId'] = data.sessionId;
                            sessionStorage['canLogin'] = data.AUTH;
                            sessionStorage["level"] = data.user_level;
                            sessionStorage.setItem("pageUrl","html/index.html")
                            location.href = Page.getUrl("app.html");
                            if(vm.checkbox){
                                localStorage.setItem("usernameValue",vm.username);
                                localStorage.setItem("passwordValue",Base64.encode(vm.password))
                            }else{
                                localStorage.setItem("usernameValue","");
                                localStorage.setItem("passwordValue","")
                            }
                            
                        }

                    },
                    complete: function () {
                        // $btnLogin.enable();
                    }
                });
            },
            getSessionId() {
                return Md5.md5(Math.random().toString()) + Md5.md5(Math.random().toString());
            }
        },
        mounted(){
            this.getNextText();
            this.username = localStorage.getItem("usernameValue");
            if(localStorage.getItem("passwordValue")){
                this.password = Base64.decode(localStorage.getItem("passwordValue"));
            }else{
                this.password = "";
            }
            
            if(this.username&&this.password){
				this.checkbox = true;
			}else{
				this.checkbox = false;
			}
            this.getRouterInfo();
            sessionStorage['canLogin'] = "";
            window.history.pushState(null, null, document.URL);
            const login_times = sessionStorage.getItem("login_times") || 3
            if (parseInt(login_times, 10) < 1 || parseInt(login_times, 10)==3) {
                loginTimer = setInterval(function () {
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
                            method: JSONMethod.GET,
                            sessionId: ""
                        },
                        success: function (data) {
                            
                            const mes = vm.accountLock+'180s'
                            const toast = vant.Toast.loading({
                                duration: 0, // 持续展示 toast
                                forbidClick: true,
                                message: mes,
                                });
                                
                                let second = 180  - data.netx_login_time;
                                if (second>0) {
                                    toast.message = vm.accountLock+second+'s';
                                } else {
                                    clearInterval(loginTimer);
                                    // 手动清除 Toast
                                    vant.Toast.clear();
                                }
                        }
                    })
                }, 1000)
            }else if(login_times == null && this.flag){ //人为刷新页面
                loginTimer = setInterval(function () {
                    Page.postJSON({
                        json: {
                            cmd: RequestCmd.GET_NEXT_LOGIN_TIME,
                            method: JSONMethod.GET,
                            sessionId: ""
                        },
                        success: function (data) {
                            
                            const mes = vm.accountLock+'180s'
                            const toast = vant.Toast.loading({
                                duration: 0, // 持续展示 toast
                                forbidClick: true,
                                message: mes,
                                });
                                
                                let second = 180  - data.netx_login_time;
                                if (second>0) {
                                    toast.message = vm.accountLock+second+'s';
                                } else {
                                    clearInterval(loginTimer);
                                    // 手动清除 Toast
                                    vant.Toast.clear();
                                }
                        }
                    })
                }, 1000)
            }
            this.getLanguageList();
        },
        computed:{
            getIndex(){
                switch (Page.language) {
                    case "CN":
                        return 0
                    case "EN":
                        return 1
                    default:
                        break;
                }
            }
        }
    })
})