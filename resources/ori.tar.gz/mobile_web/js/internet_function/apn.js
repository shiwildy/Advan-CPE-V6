/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-02 09:42:08
 * @,@LastEditTime: ,: 2021-03-18 10:26:32
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\apn.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#mobile-apn",
        data(){
            return{
                title:DOC.apn.setting,
                title2:DOC.apnHelper.title4,
                MTU:DOC.apnHelper.title8,
                NAT:DOC.apnHelper.title1,
                save:DOC.btn.save,
                apnReset:DOC.apn.apnReset,
                title3:DOC.apn.apnList,
                title4:DOC.apn.addAPN,
                tipTitle:CHECK.tip.apnTip,
                defaultTitle:CHECK.tip.deafualt,
                checked:false,
                apnNat:false,
                apnMTU:"",
                show:false,
                selectType:"",
                selectIndex:"",
                apn_list:[],
                select_type:["IPV4","IPV6","IPV4&V6"],
                mtuValidator:""
            }
        },
        methods:{
            openList(){
                this.show = true;
                this.selectIndex = this.getIndex;
            },
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            showPopup(){
                var num = 0;
                for(var i=0;i<this.apn_list.length;i++){
                    if(this.apn_list[i].edit_flag=="1"){
                        num++;
                    }
                    if(num>=4){
                        failLoad(DOC.apn.fullAPN);
                        return
                    }
                }
                sessionStorage.setItem("index",-1)
                $("#app").load("html/internet_function/APN/addApn.html")
                pageUrl = "html/internet_function/APN/addApn.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onSelect(value){
                this.show = false;
                this.selectType = value
            },
            changeNAT(){
                
            },
            edit(item,index){
                if(item.edit_flag=='0'){
                    failLoad(vm.tipTitle)
                    return
                }
                sessionStorage.setItem("index",index)
                $("#app").load("html/internet_function/APN/addApn.html")
                pageUrl = "html/internet_function/APN/addApn.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            setDefault(){
                vant.Dialog.confirm({
                    message: vm.defaultTitle,
                    confirmButtonText:DOC.btn.confirm,
                    cancelButtonText:PROMPT.tips.cancel
                  })
                    .then(() => {
                        var json = {};
                        loading();
                        json.method = JSONMethod.POST;
                        json.cmd = RequestCmd.APN_INFO_PROCESS;
                        json.apn_reset = "1";
                        Page.postJSON({
                            json: json,
                            success: function (data) {
                                if (data.message == "0") {
                                    clearToast();
                                    successLoad()
                                } else {
                                    failLoad()
                                }
                            },
                            complete:function(){
                                vm.getData()
                            }
                        });
                    })
                    .catch(() => {
                      vm.getData();
                    });
            },
            getData() {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_CONFIG,
                        methods: JSONMethod.GET,
                        subcmd: 3
                    },
                    success: function (data) {
                        vm.apnNat = data.apnNatName == "1" ? true : false;
                        vm.apnMTU = data.apnMTU;
                        vm.selectType = data.selectType=="IP"?"IPV4":data.selectType=="IPV4V6"?"IPV4&V6":data.selectType;
                    }
                });
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APN_INFO_PROCESS,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        vm.apn_list = datas.apn_list;
                        for (var i = 0; i < datas.apn_list.length; i++) {
                            if (datas.apn_list[i].default_flag == "1") {
                                vm.$set(vm.apn_list[i],"checked",true)
                            }else{
                                vm.$set(vm.apn_list[i],"checked",false)
                            }
                            if (datas.apn_list[i].edit_flag == "1") {
                                vm.editNum += 1;
                            }
                        }
                    }
                });
            },
            submit(index){
                for (var i = 0; i < this.apn_list.length; i++) {
                    if (index == i) {
                        this.apn_list[i].checked = true
                        this.apn_list[i].default_flag = "1";
                    } else {
                        this.apn_list[i].checked = false
                        this.apn_list[i].default_flag = "0";
                    }
                }
                var json = {};
                loading();
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.APN_INFO_PROCESS;
                json.apn_list = this.apn_list;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            setTimeout(() => {
                                clearToast();
                                successLoad();
                            }, 1000);
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            submitOne(){
                var reg =/^[1-9]\d*$/;
                if((this.apnMTU<600||this.apnMTU>1500) || !reg.test(this.apnMTU)){
                    this.mtuValidator = CHECK.range.MTURange1
                    return false;
                }
                this.mtuValidator = "";
                loading();
                var json = {};
                json.selectType = this.selectType=="IPV4"?"IP":this.selectType=="IPV4&V6"?"IPV4V6":this.selectType;;
                json.apnMTU = this.apnMTU;
                json.apnNatName = this.apnNat ? "1" : "0";
                json.method = JSONMethod.POST;
                json.subcmd = 3;
                json.cmd = RequestCmd.APN_CONFIG;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.butAble = false;
                        if (data.message == "0") {
                            clearToast();
                            successLoad();
                        } else {
                            failLoad();
                        }
                    },
                    complete:function(){
                        vm.getData();
                    }
                })
            },
            delete(){

            }
        },
        mounted(){
            this.getData()
            // setTimeout(() => {
            //     vm.getData()
            // }, 2000);
        },
        computed:{
            getIndex(){
                switch(vm.selectType){
                    case "IPV4":
                        return 0
                    case "IPV6":
                        return 1
                    case "IPV4&V6":
                        return 2
                    default:
                        break;

                }
            }
        }
    })
})