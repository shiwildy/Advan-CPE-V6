/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-01 11:59:03
 * @,@LastEditTime: ,: 2020-12-08 14:42:24
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\internet_function\mobile\net.js
 */
$(document).ready(function () {
    var vm = new Vue({
        el:"#net-model",
        data(){
            return{
                title1:fourgInfohtml.helper.title1,
                show:false,
                value:"",
                networkModeValue: "1",
                list: [
                    { index: "9", "name": "TD-LTE/LTE FDD/W/TD/GSM" },
                    { index: "6", "name": "TD-LTE/LTE FDD/W/GSM" },
                    { index: "4", "name": "LTE FDD/W/GSM"},
                    { index: "5", "name": "TD-LTE/W/TD/GSM" },
                    { index: "1", "name": "TD-LTE" },
                    { index: "2", "name": "LTE FDD" },
                    { index: "3", "name": "4G Only" },//TD-LTE/LTE FDD
                    { index: "7", "name": "TD-LTE/TD/GSM" },
                    { index: "8", "name": "TD-LTE/LTE FDD/TD/GSM" },
                    { index: "15", "name": "GSM" },
                    { index: "11", "name": "W" },
                    { index: "14", "name": "WG" },
                    { index: "12", "name": "TD" },
                    { index: "13", "name": "TG" },
                    { index: "131", "name": "5G SA+NSA/4G"},//TD-LTE/LTE FDD
                    { index: "333", "name": "5G NSA Only" },//TD-LTE/LTE FDD
                    { index: "128", "name": "5G SA Only" },//5G
                    { index: "134", "name": "5G/TD-LTE/LTE FDD/W/GSM" },
                    { index: "135", "name": "5G/TD-LTE/TD/GSM" },
                    { index: "137", "name": "5G/TD-LTE/LTE FDD/TD/W/GSM" }
                ],
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/internet_function/mobile.html")
                pageUrl = "html/internet_function/mobile.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onSelect(item) {
                this.show = false;
                this.networkModeValue = item.index
                loading()
                var json = {}
                if(this.networkModeValue == "131" || this.networkModeValue == "128" || 
                   this.networkModeValue == "134" || this.networkModeValue == "135" ||
                   this.networkModeValue == "137"){
                    json.mode5g = "1";
                }else if(this.networkModeValue == "333"){
                    json.mode5g="0";
                    json.networkMode = "131"
                }else{
                    json.mode5g="0";
                }
                json.networkMode = this.networkModeValue
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.NETWORKSET_MODE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if(data.message == "0"){
                            clearToast()
                            successLoad();
                        }else{
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.getData();
                    }
                });
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.NETWORKSET_MODE,
                        method: JSONMethod.GET
                    },
                    success: function (data) {
                        if(data.mode5g == "0" && data.networkMode== "131"){
                            vm.networkModeValue = "333";
                        }else{
                            vm.networkModeValue = data.networkMode;
                        }
                        
                    }
                });
            },
            isShowMode:function(event){
                if(Page.level != "1"){
                    if(event == "3" || event == "131" || event == "128" || event == "333" ){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                     return true;
                }
                
            }
        },
        computed:{
            listName(){
                switch (this.networkModeValue) {
                    case "9":
                        return "TD-LTE/LTE FDD/W/TD/GSM"
                    case "6":
                        return "TD-LTE/LTE FDD/W/GSM"
                    case "4":
                        return "LTE FDD/W/GSM"
                    case "5":
                        return "TD-LTE/W/TD/GSM"
                    case "1":
                        return "TD-LTE"
                    case "2":
                        return "LTE FDD"
                    case "3":
                        return "4G Only"
                    case "7":
                        return "TD-LTE/TD/GSM"
                    case "8":
                        return "TD-LTE/LTE FDD/TD/GSM"
                    case "15":
                        return "GSM"
                    case "11":
                        return "W"
                    case "14":
                        return "WG"
                    case "12":
                        return "TD"
                    case "13":
                        return "TG"
                    case "131":
                        return "5G SA+NSA/4G"
                    case "333":
                        return "5G NSA Only"
                    case "128":
                        return "5G SA Only"
                    case "134":
                        return "5G/TD-LTE/LTE FDD/W/GSM"
                    case "135":
                        return "5G/TD-LTE/TD/GSM"
                    case "137":
                        return "5G/TD-LTE/LTE FDD/TD/W/GSM"
                    default:
                        break;
                }
            }
        },
        mounted:function(){
            this.getData();
        }
    })
})