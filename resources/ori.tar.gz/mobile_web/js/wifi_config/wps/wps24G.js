/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-03 17:45:04
 * @,@LastEditTime: ,: 2021-01-28 11:37:17
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\wifi_config\wps\wps24G.js
 */
$(document).ready(function () {
    
    var vm = new Vue({
        el:"#wps-24g",
        data(){
            return{
                wps: DOC.lbl.wpsEnable,
                lbl_wpsPin: DOC.lbl.wpsPin,
                lbl_wpsCreatePin: DOC.lbl.wpsCreatePin,
                lbl_wps_pcb: DOC.lbl.wpsPBC,
                title: wirelessconfightml.tab_menu.wps_24,
                wpsPinInputPROMPT: PROMPT.input.wpsPin,
                net_mobilePhone: DOC.net.mobilePhone,
                btn_apply: DOC.btn.apply,
                dataSwitch:false,
                wpsEnable :false,
                wpsPin:"",
                pattern: /\d{8}/,
                message:CHECK.format.wpsPin,
                valid:CHECK.format.valid,
                timmer:"",
                wifiOpen:false,
                broadcast:false,
                disabled:false
            }
        },
        methods:{
            getWifiData(){
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.wifiOpen = data.wifiOpen == "1" ? true : false;
                        vm.broadcast = data.broadcast == "1" ? true : false;
                        if(!vm.wifiOpen){
                            vm.wpsEnable = false;
                            vm.disabled = true;
                            vant.Notify({ type: 'warning', message: DOC.lbl.wpsDisable,duration: 2000,});
                        }
                        else if(!vm.broadcast){
                            vm.disabled = true;
                            vant.Notify({ type: 'warning', message: DOC.lbl.wpsopen4G,duration: 2000,});
                        }else{
                            vm.disabled = false;
                        }
                        
                    }
                })
            },
            onClickLeft(){
                $("#app").load("html/wifi_config/wps.html")
                pageUrl = "html/wifi_config/wps.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onFailed(){

            },
            wpsRandomPin: function () {
                var json = {};
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.OPEN_RANDOM_PIN;
                vant.Toast.loading({
                    message: '加载中...',
                    forbidClick: true,
                  });
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (!!data.random_ping) {
                            var time = 120;
                            vm.timmer = setInterval(() => {
                                time--;
                                vant.Notify({ type: 'success', message: vm.net_mobilePhone+data.random_ping+String.format(vm.valid,time),duration:0,background: '#4b88d3', });
                                if(time==0){
                                    clearInterval(vm.timmer)
                                    vant.Notify.clear()
                                }
                            }, 1000);
                            
                            
                        } else {
                            failLoad();
                        }
                    },
                    complete: function () {
                        vm.btnAbl1 = false;
                    }
                });
            },
            
            pinCheck: function (code) {
                var accum = 0;
                accum += 3 * (parseInt(code / 10000000) % 10);
                accum += 1 * (parseInt(code / 1000000) % 10);
                accum += 3 * (parseInt(code / 100000) % 10);
                accum += 1 * (parseInt(code / 10000) % 10);
                accum += 3 * (parseInt(code / 1000) % 10);
                accum += 1 * (parseInt(code / 100) % 10);
                accum += 3 * (parseInt(code / 10) % 10);
                accum += 1 * (parseInt(code / 1) % 10);
                return (0 == (accum % 10));
            },
            btnClick: function () {
                loading();
                var json = {};
                json.wlan2g_wps_switch = this.wpsEnable ? "1" : "0";
                json.cmd = RequestCmd.WPS_CONFIG;
                json.method = JSONMethod.POST;
                json.subcmd = 0;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            setTimeout(function () {
                                clearToast();
                                successLoad();
                            }, 6000);
                        } else {
                            setTimeout(function () {
                                clearToast();
                                failLoad();
                            }, 6000);
                        }
                    },
                    complete: function() {
                        vm.getData()
                    },
                    error: function() {
                        clearToast();
                        failLoad();
                    }
                })
            },
            btnClick2: function () {
                var json = {};
                if (!this.pinCheck(this.wpsPin)||this.wpsPin=="") {
                    failLoad(CHECK.format.wpsPin)
                    return;
                }
                json.wpsPin = this.wpsPin;
                loading();
                json.cmd = RequestCmd.WPS_PIN_CODE;
                json.subcmd = 0;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.success == true) {
                            clearToast();
                            successLoad();
                        } else {
                            failLoad();
                        }
                    }
                })
            },
            wpsPCB: function () {
                var json = {};
                json.subcmd = 2;
                loading()
                json.cmd = RequestCmd.WPS_PIN_CODE;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        if (data.message == "0") {
                            clearToast();
                            successLoad();
                        } else {
                            failLoad();
                        }
                    }
                })
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WPS_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.wpsEnable = data.wlan2g_wps_switch == "1" ? true : false;
                    }
                })

            },
            submit(){
                
            },
            clear(){
                vant.Notify.clear();
                clearInterval(vm.timmer)
            }
        },
        mounted(){
            this.getData();
            this.getWifiData();
        }
    })
})