/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-03 15:54:20
 * @,@LastEditTime: ,: 2021-01-25 09:33:21
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\wifi_config\wifi5G.js
 */
$(document).ready(function () {
    var form1 = wirelessconfightml.form1;
    var vm = new Vue({
        el:"#wifi5",
        data(){
            return{
                title:MENU.settingWifi.wifi5g,
                title1:wirelessconfightml.form1.ssid,
                title2:wirelessconfightml.form1.wepMode,
                title3:wirelessconfightml.helper.title7,
                title4:wlan5ghtml.form1.btnSave,
                errorTip1:wirelessconfightml.prompt.ssidCheckMsg2,
                errorTip2:wirelessconfightml.prompt.keyCkeckMsg,
                ssid:"",
                authentication: "none",
                show:false,
                wifiOpen: false,
                broadcast: false,
                wifiWmmVal: false,
                key: "",
                showPass:false,
                disabled:false,
                is5G:false,
                wifiSames:false,
                authenticationOption: [{
                    value: "0",
                    text: form1.openSys
                },
                {
                    value: "2",
                    text: "WPA2-PSK"
                },
                {
                    value: "3",
                    text: "WPA/WPA2-PSK"
                },
                {
                    value: "4",
                    text: "WPA3-PSK"
                },
                {
                    value: "5",
                    text: "WPA2/WPA3-PSK"
                }
            ],
            wifiFunction: form1.wifiFunction,
            wifissidBd: wirelessconfightml.form1.ssidBd,
            wifiSamesTile: form1.wifiSames,
            wifiwmm: form1.wmm,
            authValue:"",
            selectIndex:""
            }
        },
        methods:{
            formatter(value) {
                // 过滤输入的空格
                return value.replace(/\s/g, '');
              },
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            onSelect(item){
                this.show = false
                this.authentication = item.text
                this.authValue = item.value
            },
            showPopup(){
                this.selectIndex = this.getIndex;
                if(this.disabled==true){
                    return false
                }else{
                    this.show = true
                }
               
            },
            getData: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.WIRELESS5G_CONFIG,
                        subcmd: 0
                    },
                    success: function (data) {
                        vm.wifiSames = data.wifiSames == "1" ? true : false;
                        vm.wifiOpen = data.wifiOpen == "1" ? true : false;
                        vm.broadcast = data.broadcast == "1" ? true : false;
                        vm.wifiWmmVal = data.wifiwmm == "1" ? true : false;
                        vm.ssid = Base64.decode(data.ssid);
                        vm.key = data.key;
                        vm.authentication = data.authenticationType=="0"?form1.openSys:data.authenticationType=="2"?"WPA2-PSK":data.authenticationType=="3"?"WPA/WPA2-PSK":data.authenticationType=="4"?"WPA3-PSK":"WPA2/WPA3-PSK";
                        vm.authValue = data.authenticationType;
                    }
                })
            },
            save(){
                loading();
                var json = {};
                json.wifiOpen = vm.wifiOpen ? "1" : "0";
                json.broadcast = vm.broadcast ? "1" : "0";
                json.wifiwmm = vm.wifiWmmVal ? "1" : "0";
                json.ssid = Base64.encode(vm.ssid);
                json.key = vm.key;
                json.authenticationType = vm.authValue;
                json.method = JSONMethod.POST;
                json.cmd = RequestCmd.WIRELESS5G_CONFIG;
                json.wifiSames = vm.wifiSames ? "1" : "0";
                if (vm.wifiSames) {
                    json.wifiOpen_24 = vm.wifiOpen? "1" : "0";
                    json.broadcast_24 = vm.broadcast? "1" : "0";
                    json.wifiwmm_24 = vm.wifiWmmVal? "1" : "0";
                }
                json.subcmd = 0;
                Page.postJSON({
                    json: json,
                    success: function (data) {
                        vm.butAble = false;
                        if (data.message == "0") {
                            setTimeout(function () {
                                clearToast();
                                successLoad();
                            }, 6000);
                            wifiConnect();
                        } else {
                            setTimeout(function () {
                                failLoad()
                            }, 6000);
                        }
                    },
                    complete: function() {
                        vm.getData();
                    }
                });
            },
        },
        mounted(){
            this.getData();
        },
        computed:{
            getIndex(){
                switch(vm.authValue){
                    case "0":
                        return 0
                    case "2":
                        return 1
                    case "3":
                        return 2
                    case "4":
                        return 3
                    case "5":
                        return 4
                    default:
                        break;
                }
            }
        }
    })
})