/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-04 17:07:48
 * @,@LastEditTime: ,: 2020-12-08 15:15:39
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\device_config\route.js
 */
$(document).ready(function(){
    var vm = new Vue({
        el:"#device-route",
        data(){
            return{
                tableContent:[],
                valid: DOC.status.validEntry,
                invalid: DOC.status.invalid,
                title:MENU.setting.route,
                title2:TAB.route.routingTable,
                title3:DOC.btn.applyRule,
                title4:TAB.route.AddroutingTable
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/index.html")
                pageUrl = "html/index.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            showPopup(){
                sessionStorage.setItem("key",-1)
                $("#app").load("html/device_config/route/addRoute.html")
                pageUrl = "html/device_config/route/addRoute.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            getDate: function () {
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.ROUTER_TABLE,
                        method: JSONMethod.GET
                    },
                    success: function (datas) {
                        if (datas.datas) {
                            vm.tableContent = datas.datas;
                        }

                    }
                });
            },
            edit(item,key){
                sessionStorage.setItem("key",key)
                $("#app").load("html/device_config/route/addRoute.html")
                pageUrl = "html/device_config/route/addRoute.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            applyRulesClick: function () {
                loading();
                Page.postJSON({
                    json: {
                        cmd: RequestCmd.APPLY_FILTER,
                        method: JSONMethod.POST
                    },
                    success: function (data) {
                        if (data.message == "") {
                            clearToast();
                            successLoad();
                        } else {
                            failLoad();
                        }
                    }
                });
            },
        },
        mounted(){
            this.getDate();
        }
    })
})