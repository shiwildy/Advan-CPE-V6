/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-12-07 09:51:29
 * @,@LastEditTime: ,: 2020-12-08 15:24:17
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\js\system_manage\set\changeName.js
 */
$(document).ready(function () {
    var index = sessionStorage.getItem("index")
    var vm = new Vue({
        el:"#set-name",
        data(){
            return{
                title:TAB.sys.changeUsername,
                title2:CHECK.required.oldUsername,
                title3:CHECK.required.newUsername,
                title4:CHECK.required.duplicateNewUsername,
                oldUsername:DOC.sys.oldUsername,
                newUsername:DOC.sys.newUsername,
                duplicateNewUsername:DOC.sys.duplicateNewUsername,
                btnSave:DOC.btn.save,
                oldNameValue:"",
                newNameValue:"",
                newName2Value:"",
            }
        },
        methods:{
            onClickLeft(){
                $("#app").load("html/system_manage/setting.html")
                pageUrl = "html/system_manage/setting.html"
                sessionStorage.setItem("pageUrl",pageUrl)
            },
            btnSaveClick:function(){
               var json = {};
               if(vm.newNameValue != vm.newName2Value)
 				{
                    failLoad(CHECK.format.passwdNotSame)
 					return false;
 				}
		    	json.cmd = RequestCmd.CHANGE_USERNAME;
		    	json.method = JSONMethod.POST;
		    	json.newUsername = this.newNameValue;
		    	json.oldUsername = this.oldNameValue;
		    	json.subcmd = 0;
		    	loading();
		        Page.postJSON({
		        	json: json,
			        success: function(data) {
			        	if(data.message == "success"){
			        		vm.oldNameValue = "";
				        	vm.newNameValue = "";
				        	vm.newName2Value = "";
                            clearToast();
                            successLoad();
			        	}else if(data.message == "passwd username"){
                            failLoad(PROMPT.saving.previousUsername)
			        	}else{
			        		failLoad()
			        	}
			        	
			        }
		        });
            },
        },
        mounted(){
            this.$nextTick(()=>{
                this.$refs.name.focus()
            })
        }
    })
})