/*
 * @,@Author: ,: your name
 * @,@Date: ,: 2020-11-27 16:25:56
 * @,@LastEditTime: ,: 2020-12-18 14:37:01
 * @,@LastEditors: ,: Please set LastEditors
 * @,@Description: ,: In User Settings Edit
 * @,@FilePath: ,: \war\mobile_web\app.js
 */
$(document).ready(function () {
    var web_browser_title = ""
    function init() {
        document.title = web_browser_title || DOC.head
        $.ajax({
            url: "/mobile_web/html/index.html",
            dataType: "html",
            type: "GET",
            async: false,
            success: function (data) {
                if (sessionStorage['canLogin'] == "AUTH"&&sessionStorage.getItem("pageUrl") =="html/index.html") {
                    $('#app').html(data);
                } else {
                    var pageUrl = sessionStorage.getItem("pageUrl")
                    $("#app").load(pageUrl)
                }
            }
        });
    }
    Page.postJSON({
        json: {
            cmd: RequestCmd.INIT_PAGE
        },
        success: function (data) {
            var styleTag = document.createElement("link");
            Page.webPageFlag = Page.parseHexPageHide(data.web_page_hide);
            var themeWeb = "";
            if (!data.user_web_theme) {
                themeWeb = "css/main.css";
            } else {
                themeWeb = data.user_web_theme;
            }
            if (!!data.web_browser_title) {
                web_browser_title = data.web_browser_title;
            }
            styleTag.setAttribute('href', 'css/' + themeWeb+"?t="+Math.random());
            styleTag.setAttribute('type', 'text/css');
            styleTag.setAttribute('rel', 'stylesheet');
            $("head")[0].appendChild(styleTag);
            Page.current_card_type = data.current_card_type == "1" ? "1" : "0";
            Page.iad_ready_status = data.iad_ready_status == "0" ? "0" : "1";
            Page.esim_show = data.esim_show == "1" ? "1" : "0";
            Page.onenet = data.onenet == "1" ? "1":"0";
            Page.dm_platform = data.dm_platform == "1" ? "1":"0";
            Page.level = data.account_level || "3";
            var language = data.language.toUpperCase();
            Page.language = language;
                $("script[src^='/js/language/']").remove();
                $.getScript('/js/language/' + language.toLowerCase() + '.js',init);
        }
    });
    if(IsPC()){
        window.location.href = Page.getUrl("/index.html");
    }
    // var pageUrl = sessionStorage.getItem("pageUrl")
    //     if(pageUrl){
    //         $("#app").load(pageUrl)
    //     }
    //     else{
    //         $("#app").load("html/index.html")
    //     }
    var vm = new Vue({
        el:"#app",
        data(){
            return{
                
            }
        },
        methods:{
           
        },
        mounted(){
            // const pageUrl = sessionStorage.getItem("pageUrl")
            // if(pageUrl){
            //     console.log(pageUrl);
            //     $("#app").load(pageUrl)
            // }else{
            //     console.log(8888888);
            //     $("#app").load("html/index.html")
            // }
            //账号在其他设备登录
            setInterval(Page.getDeviceName, 7000);
            
        }
    })
})